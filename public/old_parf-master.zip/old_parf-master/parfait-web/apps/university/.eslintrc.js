module.exports = {
  ...require('config/eslint-preset'),
  rules: {
    '@typescript-eslint/no-non-null-assertion': 'off',
    'react/react-in-jsx-scope': 'off',
  },
};
