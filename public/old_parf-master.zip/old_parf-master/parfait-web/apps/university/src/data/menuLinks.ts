import { NavLinkType } from 'ui/src/components/NavigationMenu/types';

export const menuLinks: Array<NavLinkType> = [
  { title: 'Recruits', to: '/recruits' },
  { title: 'Messages', to: '/messages' },
  { title: 'App Management', to: '/app-management/images', role: 'Admin' },
  { title: 'College Fairs', to: '/college-fairs' },
  { title: 'Invites', to: '/invites' },
];
