import { RouteObject } from 'react-router-dom';
import { SignIn } from '../views';
import { NoMatchView } from '../views';

const routes: RouteObject[] = [
  {
    path: '/',
    element: <SignIn />,
  },
  { path: '*', element: <NoMatchView /> },
];

export default routes;
