import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { SignIn } from '../../views';
import { SignUp } from '../../views';
import { PasswordReset } from '../../views';
import { PasswordResetSubmit } from '../../views';
import ConfirmEmail from '../../views/ConfirmEmail';
import ConfirmCollege from '../../views/ConfirmCollege';
import { CompleteNewPassword } from '../../views/CompleteNewPassword';

const UnAuthorizedRoutes = () => {
  return (
    <div>
      <Routes>
        <Route path="/sign-in" element={<SignIn />} />
        <Route path="/sign-up" element={<SignUp />} />
        <Route path="/reset-password" element={<PasswordReset />} />
        <Route path="/reset-password-submit" element={<PasswordResetSubmit />} />
        <Route path="/complete-new-password" element={<CompleteNewPassword />} />
        <Route path="/confirm-email" element={<ConfirmEmail />} />
        <Route path="/confirm-college-profile" element={<ConfirmCollege />} />
        <Route path="*" element={<Navigate to="sign-in" />} />
      </Routes>
    </div>
  );
};

export default UnAuthorizedRoutes;
