import { Routes, Route, Navigate } from 'react-router-dom';
import {
  AdminManagementView,
  AppManagementView,
  CollegeFairsView,
  InvitesView,
  MessagesView,
  NoMatchView,
  RecruitsView,
} from '../../views';

const AuthorizedRoutes = () => {
  return (
    <Routes>
      <Route path="/*" element={<Navigate to="recruits" replace />}></Route>
      <Route path="/recruits" element={<RecruitsView />} />
      <Route path="/messages" element={<MessagesView />} />
      <Route path="/app-management/*" element={<AppManagementView />} />
      <Route path="/college-fairs" element={<CollegeFairsView />} />
      <Route path="/invites" element={<InvitesView />} />
      <Route path="/manage-account" element={<AdminManagementView />} />
      <Route path="*" element={<NoMatchView />} />
    </Routes>
  );
};

export default AuthorizedRoutes;
