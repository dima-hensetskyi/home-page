import { createContext } from 'react';
import { RecruitsContextType } from '../types';

export const RecruitsContext = createContext<RecruitsContextType | null>(null);
