export const recruitsStatuses = [
  'PROSPECT',
  'INQUIRY',
  'APPLICATION_STARTED',
  'COMPLETED_APPLICATION',
  'APPLICANT',
  'ADMIT',
  'DECLINE',
];
