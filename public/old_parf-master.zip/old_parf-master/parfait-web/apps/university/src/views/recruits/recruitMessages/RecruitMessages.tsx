import { Box, Typography } from '@mui/material';
import React from 'react';
import { useQueryClient } from 'react-query';
import { Chat } from 'ui/components';
import WarningIcon from '@mui/icons-material/Warning';
import { GetChatForRecruitResponse } from '../types';

type PropsType = {
  userId: string;
};

export const RecruitMessages: React.FC<PropsType> = ({ userId }: PropsType) => {
  const queryClient = useQueryClient();
  const data = queryClient.getQueryData<GetChatForRecruitResponse>(['getRecruitChat', userId]);
  return (
    <Box>
      <Typography variant="h6" sx={{ mb: '16px' }}>
        Messages
      </Typography>
      {data ? (
        <Chat chatId={data?.getChatForUser.id || ''} height={620} />
      ) : (
        <Box sx={{ display: 'flex', gap: '16px', justifyContent: 'center' }}>
          <WarningIcon
            sx={{
              color: '#ED6C02',
            }}
          />
          <Typography variant="body1">No active chat found</Typography>
        </Box>
      )}
    </Box>
  );
};
