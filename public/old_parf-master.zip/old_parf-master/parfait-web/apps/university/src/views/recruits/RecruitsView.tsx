import { SmallDialog, useAuthContext } from 'ui/components';
import { Box } from '@mui/material';
import { useState } from 'react';

import { GetRecruitsVariablesType, RecruitResponseType, RecruitType } from './types';
import { RecruitProfile } from './recruitProfile';
import { RecruitTable } from './RecruitTable';
import { RecruitActivitiesNotes } from './recruitActivitiesNotes';
import { useQuery, useQueryClient } from 'react-query';
import { fetchRecruitsNotesActivityList } from './recruitActivitiesNotes/utils';
import { RecruitActivityNotesLimit } from './recruitActivitiesNotes/utils';
import { fetchRecruitsCohorts, getQuestions, getRecruitsListItem } from './utils/utils';
import { RecruitMessages } from './recruitMessages';

export const initialRecruitsRequestVariables = { limit: 10 };

export const RecruitsView: React.FC = () => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [activeRecruit, setActiveRecruit] = useState<RecruitType | null>(null);
  const [requestVariables, setRequestVariables] = useState<GetRecruitsVariablesType>(initialRecruitsRequestVariables);

  const queryClient = useQueryClient();
  const { tenant } = useAuthContext();

  useQuery('GetRecruitsCohorts', fetchRecruitsCohorts);
  const questions = useQuery('UsersQuestions', getQuestions);
  const onRecruitUpdate = (updatedRecruit: RecruitResponseType) => {
    const newRecruit = getRecruitsListItem(updatedRecruit, tenant?.name || '');
    setActiveRecruit(() => ({ ...newRecruit }));
    queryClient.invalidateQueries(['GetRecruits', requestVariables]);
    queryClient.invalidateQueries(['getRecruitActivities', newRecruit.id]);
  };

  return (
    <Box sx={{ display: 'flex', flex: '1', flexDirection: 'column' }}>
      <RecruitTable
        requestVariables={requestVariables}
        setRequestVariables={setRequestVariables}
        studentProps={{ setActiveRecruit, setIsDialogOpen }}
      />
      <SmallDialog
        content={
          <RecruitProfile
            questions={questions.data?.items}
            onRecruitsUpdate={onRecruitUpdate}
            recruit={activeRecruit}
          />
        }
        onShowMoreMouseEnter={() => {
          if (activeRecruit?.id && !queryClient.getQueryData(['getRecruitActivities', activeRecruit.id])) {
            queryClient.prefetchInfiniteQuery(['getRecruitActivities', activeRecruit.id], () =>
              fetchRecruitsNotesActivityList({ limit: RecruitActivityNotesLimit, recruitId: activeRecruit.id }),
            );
          }
        }}
        additionalContent={
          <Box
            sx={{
              display: 'grid',
              flex: 1,
              gridTemplateColumns: `repeat(2, minmax(0, 1fr))`,
              gap: '32px',
            }}
          >
            <RecruitActivitiesNotes recruitId={activeRecruit?.id || ''}></RecruitActivitiesNotes>
            <RecruitMessages userId={activeRecruit?.detail.user.id || ''} />
          </Box>
        }
        open={isDialogOpen}
        close={() => setIsDialogOpen(false)}
      />
    </Box>
  );
};
