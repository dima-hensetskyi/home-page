import { InvitesContainer } from 'ui/components';

export const InvitesView: React.FC = () => <InvitesContainer />;
