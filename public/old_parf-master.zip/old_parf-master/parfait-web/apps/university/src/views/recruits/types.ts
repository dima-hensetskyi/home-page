export type RecruitResponseType = {
  id: string;
  status: string;
  recruitCohortId: string;
  assignedTenantUser: {
    name: string;
    id: string;
  } | null;
  institution: {
    name: string;
    address: {
      city: string;
      stateProvince: string;
    };
  };
  user: {
    name: string;
    familyName: string;
    givenName: string;
    id: string;
    userQuestions: UserAnswers;
    avatar: S3Object;
    userInstitutions: [userInstitution];
  };
  recruitCohort: {
    name: string;
    classYear: string;
    status: string;
  } | null;
};

type userInstitution = {
  id: string;
  name: string;
  status: string;
};

export type RecruitType = {
  userName: string;
  year: string;
  cohort: string;
  highSchool: string;
  location: string;
  status: string;
  id: string;
  recruitCohortId: string;
  interest: string;
  assignedTenantUserId: string | null;
  assignedTenantUser: {
    name: string;
    id: string;
  } | null;
  detail: RecruitResponseType;
};

export type RecruitCohortType = {
  id: string;
  name: string;
  classYear: string;
  status: string;
};

export interface GetRecruitsResponseType {
  getRecruits: {
    items: [RecruitResponseType] | [];
    nextToken: string | null;
  };
}
export interface GetRecruitsCohortsResponseType {
  getRecruitCohorts: {
    items: [RecruitCohortType];
    nextToken: string;
  };
}

export interface UpdateRecruitResponseType {
  updateRecruit: RecruitResponseType;
}
export type UpdateRecruitInputType = {
  input: {
    id: string;
    status?: string;
    recruitCohortId?: string;
    assignedTenantUserId?: string;
  };
};

export type RecruitInitialStateType = {
  isFiltering: boolean;
  recruitCohortIds?: [] | Array<string>;
  statuses?: [] | Array<string>;
  requestVariables: RecruitsFilterInput | null;
};

export type RecruitsContextType = {
  onChangeRequestVariables: (newVars: GetRecruitsVariablesType) => void;
  getRecruitsVars: GetRecruitsVariablesType;
};

export type GetRecruitsVariablesType = {
  filter?: RecruitsFilterInput;
  limit: number;
  nextToken?: string;
};

export type RecruitsFilterInput = {
  statuses?: Array<string>;
  recruitCohortIds?: Array<string>;
  searchTerms?: Array<string>;
};

export type RecruitsFilterState = { isFiltering: boolean; filter?: RecruitsFilterInput };

export type VariablesType = 'filters' | 'search';

export type QuestionCategory = 'ACADEMICS' | 'GENERAL' | 'INTEREST' | 'MAJORS';

export type Questions = Array<{
  category: QuestionCategory;
  id: string;
  name: string;
  question: string;
  type: 'SINGLE_INPUT' | 'MULTIPLE_CHOICE' | 'REGIONS';
}>;

export type GetQuestionsResponse = {
  questions: {
    items: Questions;
  };
};

export type UserAnswers = Array<{
  answers: string[];
  question: {
    id: string;
    name: string;
  };
}>;

export type AttributesData = Array<{
  label: string;
  value: string;
}>;

export type GetChatForRecruitResponse = {
  getChatForUser: {
    id: string;
  };
};

export type S3AccessLevel = 'PUBLIC' | 'PROTECTED' | 'PRIVATE';

export type S3Object = {
  bucket: string;
  region: string;
  key: string;
  accessLevel: S3AccessLevel;
  identityId: string;
};
