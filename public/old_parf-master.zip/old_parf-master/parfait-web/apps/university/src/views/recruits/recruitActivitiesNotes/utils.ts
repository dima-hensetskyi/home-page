import { API, graphqlOperation } from 'aws-amplify';
import { GraphQLResult } from '@aws-amplify/api';
import { getRecruitActivities } from 'graphql/recruits';
import { GetRecruitActivitiesResponse } from './types';

export const RecruitActivityNotesLimit = 10;

export const fetchRecruitsNotesActivityList = async (variables: {
  limit: number;
  nextToken?: string | null;
  recruitId: string;
}) => {
  const result = (await API.graphql(
    graphqlOperation(getRecruitActivities, variables),
  )) as GraphQLResult<GetRecruitActivitiesResponse>;
  const data = result.data?.getRecruitActivities;
  return data;
};
