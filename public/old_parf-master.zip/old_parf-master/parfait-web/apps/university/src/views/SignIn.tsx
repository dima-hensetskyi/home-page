import { LoginLayout, LoginForm } from 'ui/components';

const SignIn = () => {
  return (
    <LoginLayout title="Sign in" type="university">
      <LoginForm />
    </LoginLayout>
  );
};

export default SignIn;
