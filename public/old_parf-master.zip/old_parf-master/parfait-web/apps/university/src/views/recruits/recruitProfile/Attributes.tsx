import React from 'react';
import { AttributesData } from '../types';
import {
  ControllerItem,
  ListItemBody,
  ListItemTitle,
  ProfileDetail,
  ProfileDetailTitle,
} from './RecruitProfile.styled';

type PropsType = {
  title: string;
  data: AttributesData;
};

export const RecruitAttributes: React.FC<PropsType> = ({ title, data }: PropsType) => {
  return (
    <ProfileDetail>
      <ProfileDetailTitle variant="overline">{title}</ProfileDetailTitle>
      {data.map((item, idx) => (
        <ControllerItem key={idx}>
          <ListItemTitle variant="body2">{item.label}</ListItemTitle>
          <ListItemBody variant="body2">{item.value}</ListItemBody>
        </ControllerItem>
      ))}
    </ProfileDetail>
  );
};
