import { Link } from 'react-router-dom';

export const NoMatchView: React.FC = () => {
  return (
    <div>
      <h1>404: No Match (University)</h1>
      <Link to="/">Go home</Link>
    </div>
  );
};
