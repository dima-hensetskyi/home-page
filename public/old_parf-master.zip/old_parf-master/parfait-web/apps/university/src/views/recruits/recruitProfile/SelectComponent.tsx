import { MenuProps, Select, SelectChangeEvent, Typography } from '@mui/material';
import React from 'react';

import { ControllerItem, ListItemTitle } from './RecruitProfile.styled';

type PropsType = {
  title: string;
  value: string | undefined | null;
  onChange: (evt: SelectChangeEvent<string>) => void;
  children: React.ReactNode;
  MenuProps?: Partial<MenuProps>;
};

interface additionalPropsType {
  renderValue: (value: string) => React.ReactNode | undefined;
}

export const SelectComponent: React.FC<PropsType> = ({ value, title, children, onChange, MenuProps }: PropsType) => {
  const additionalProps = {} as additionalPropsType;
  if (!value) {
    const val = title === 'Assigned' ? 'Not assigned' : 'Not selected';
    additionalProps['renderValue'] = () => <Typography sx={{ color: 'rgba(0, 0, 0, 0.6)' }}>{val}</Typography>;
  }
  return (
    <ControllerItem>
      <ListItemTitle variant="body2">{`${title}:`}</ListItemTitle>
      <Select
        value={value || ''}
        displayEmpty
        {...additionalProps}
        size="small"
        sx={{ width: '200px', maxHeight: '40px' }}
        onChange={onChange}
        MenuProps={MenuProps}
      >
        {children}
      </Select>
    </ControllerItem>
  );
};
