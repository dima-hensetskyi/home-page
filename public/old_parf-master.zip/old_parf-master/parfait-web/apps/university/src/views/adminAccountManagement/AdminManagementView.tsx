import { AdminUserManagement, useAuthContext } from 'ui/components';
import { Navigate } from 'react-router-dom';
import React from 'react';

export const AdminManagementView: React.FC = () => {
  const { userRole } = useAuthContext();
  if (userRole !== 'Admin') return <Navigate to="recruits" replace />;

  return <AdminUserManagement />;
};
