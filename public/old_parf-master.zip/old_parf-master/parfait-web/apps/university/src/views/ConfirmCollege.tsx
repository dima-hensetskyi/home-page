import React from 'react';
import { ConfirmCollegeForm, LoginLayout } from 'ui/components';

const ConfirmCollege = () => {
  return (
    <LoginLayout title="Confirm college affiliation" type="university">
      <ConfirmCollegeForm />
    </LoginLayout>
  );
};

export default ConfirmCollege;
