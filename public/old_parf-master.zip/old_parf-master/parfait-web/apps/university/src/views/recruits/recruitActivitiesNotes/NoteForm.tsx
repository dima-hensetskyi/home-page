import { API, graphqlOperation } from 'aws-amplify';
import { Box, Button, Typography } from '@mui/material';
import { createRecruitNote, updateRecruitNote } from 'graphql/recruits';
import { GraphQLResult } from '@aws-amplify/api';
import { useMutation, useQueryClient } from 'react-query';
import produce from 'immer';
import React, { useEffect, useState } from 'react';

import { AuthenticatedUser, GetRecruitActivitiesQuarry, RecruitActivity } from './types';
import { AvatarComponent } from 'ui/components';
import { EditingProps, EditVariables } from './recruitActivitiesNotes';
import { NoteTextFiled } from './RecruitActivitiesNotes.styled';

type PropsType = {
  user: AuthenticatedUser;
  recruitId: string;
  editingData: EditingProps;
  isNewNote: React.MutableRefObject<boolean>;
  toggleEditing: (val: boolean, data: EditVariables | null) => void;
};

export const NotesForm: React.FC<PropsType> = ({
  user,
  recruitId,
  editingData,
  toggleEditing,
  isNewNote,
}: PropsType) => {
  const { getAuthenticatedTenantUser } = user;
  const { familyName, givenName, id, avatar } = getAuthenticatedTenantUser;
  const { isEditing } = editingData;
  const userFullName = `${givenName} ${familyName}`;
  const [newNote, setNewNote] = useState('');
  const [editedNote, setEditedNote] = useState('');
  const queryClient = useQueryClient();
  const queryId = ['getRecruitActivities', recruitId];

  useEffect(() => {
    if (editingData.isEditing) {
      setEditedNote(() => editingData.data?.note || '');
    }
  }, [editingData]);

  const createNewNote = useMutation(
    async () => {
      const result = (await API.graphql(
        graphqlOperation(createRecruitNote, {
          input: {
            recruitId,
            note: newNote,
            userId: id,
          },
        }),
      )) as GraphQLResult<RecruitActivity>;
      return result.data;
    },
    {
      onMutate: async (newVal: string) => {
        setNewNote('');
        await queryClient.cancelQueries(queryId);
        const oldNotes = queryClient.getQueryData<GetRecruitActivitiesQuarry>(queryId);
        if (oldNotes) {
          isNewNote.current = true;
          const newNote = {
            __typename: 'RecruitNote' as const,
            id: newVal + id,
            createdAt: new Date().toISOString(),
            note: newVal,
            recruitId,
            updatedAt: '',
            tenantUser: getAuthenticatedTenantUser,
            userId: id,
            pageIdx: 0,
          };

          const updatedData = produce(oldNotes, (draft) => {
            draft.pages.map((page, i) => i === 0 && page.items.unshift(newNote));
          });
          queryClient.setQueryData<GetRecruitActivitiesQuarry>(queryId, updatedData);
        }

        return { oldNotes };
      },
      onError: (_err, _variables, context) => {
        if (context?.oldNotes) {
          const oldData = context?.oldNotes;
          queryClient.setQueryData<GetRecruitActivitiesQuarry>(queryId, oldData);
        }
      },
      onSettled: () => {
        queryClient.invalidateQueries(queryId);
        isNewNote.current = false;
      },
    },
  );

  const updateNote = useMutation(
    async () => {
      const result = (await API.graphql(
        graphqlOperation(updateRecruitNote, {
          input: {
            note: editedNote,
            id: editingData.data?.id,
          },
        }),
      )) as GraphQLResult<RecruitActivity>;
      return result.data;
    },
    {
      onMutate: async (vars: { editedNote: string; page: number }) => {
        setEditedNote('');
        toggleEditing(false, null);
        await queryClient.cancelQueries(queryId);
        const oldNotes = queryClient.getQueryData<GetRecruitActivitiesQuarry>(queryId);

        if (oldNotes) {
          const newNotes = { ...oldNotes };
          const noteIdx = newNotes.pages[vars.page].items.findIndex((item) => item.id === editingData.data?.id);
          const newNote = newNotes.pages[vars.page].items[noteIdx];
          newNotes.pages[vars.page].items.splice(noteIdx, 1, {
            ...newNote,
            note: editedNote,
            updatedAt: new Date().toISOString(),
          });
          queryClient.setQueryData<GetRecruitActivitiesQuarry>(queryId, newNotes);
        }

        return { oldNotes };
      },
      onError: (_err, _variables, context) => {
        if (context?.oldNotes) {
          const oldData = context?.oldNotes;
          queryClient.setQueryData<GetRecruitActivitiesQuarry>(queryId, oldData);
        }
      },
      onSettled: () => {
        queryClient.invalidateQueries(queryId);
      },
    },
  );

  return (
    <Box sx={{ display: 'grid' }}>
      <Box sx={{ display: 'flex', gap: '8px', alignItems: 'center', mt: '24px', mb: '16px' }}>
        <AvatarComponent name={userFullName} avatar={avatar} />
        <Typography variant="subtitle2">{userFullName}</Typography>
      </Box>
      <NoteTextFiled
        sx={{ mb: '8px' }}
        rows="4"
        label="Note"
        inputProps={{ maxLength: 500 }}
        inputRef={(input) => input && isEditing && input.focus()}
        value={isEditing ? editedNote : newNote}
        multiline={true}
        onChange={(evt) => (isEditing ? setEditedNote(evt.target.value) : setNewNote(evt.target.value))}
      />
      <Box sx={{ display: 'flex', gap: '12px' }}>
        <Button
          disabled={isEditing ? editedNote.length < 2 : newNote.length < 2}
          size="small"
          variant="contained"
          onClick={() => {
            if (isEditing) {
              editedNote !== editingData.data?.note
                ? updateNote.mutateAsync({ editedNote, page: editingData.data?.pageIdx || 0 })
                : toggleEditing(false, null);
            } else {
              createNewNote.mutateAsync(newNote);
            }
          }}
          sx={{ backgroundColor: (theme) => theme.palette.primary.main, width: 'fit-content' }}
        >
          {isEditing ? 'Edit' : 'Add note'}
        </Button>
        {isEditing && (
          <Button
            size="small"
            variant="outlined"
            onClick={() => toggleEditing(false, null)}
            sx={{ width: 'fit-content' }}
          >
            CANCEL
          </Button>
        )}
      </Box>
    </Box>
  );
};
