import { Messages } from 'ui/components';

export const MessagesView: React.FC = () => {
  return <Messages />;
};
