import { recruitsStatuses } from './data';
export { recruitsStatuses };
