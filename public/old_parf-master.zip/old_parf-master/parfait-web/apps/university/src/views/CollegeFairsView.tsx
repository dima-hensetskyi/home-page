import { FairsAttendingContainer } from 'ui/components';
export const CollegeFairsView: React.FC = () => <FairsAttendingContainer />;
