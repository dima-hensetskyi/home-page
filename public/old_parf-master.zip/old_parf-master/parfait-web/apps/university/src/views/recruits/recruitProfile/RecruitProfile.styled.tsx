import { Box, styled, Typography } from '@mui/material';

export const ListItemTitle = styled(Typography)(() => ({
  color: 'rgba(0, 0, 0, 0.6)',
  flex: 1,
}));

export const ListItemBody = styled(Typography)(() => ({
  width: '200px',
}));

export const ProfileDetail = styled(Box)(() => ({
  gap: '4px',
  display: 'flex',
  flexDirection: 'column',
}));

export const ProfileDetailTitle = styled(Typography)(() => ({
  background: '#EEF2FA',
  display: 'block',
  padding: '0 5px',
}));

export const Controller = styled(Box)(() => ({
  display: 'flex',
  gap: '10px',
  flexDirection: 'column',
  margin: '20px 0',
}));

export const ControllerItem = styled(Box)(() => ({
  display: 'flex',
  width: '100%',
  alignItems: 'center',
}));
