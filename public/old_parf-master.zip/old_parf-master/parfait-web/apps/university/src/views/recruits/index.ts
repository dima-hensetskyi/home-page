import { RecruitsView } from './RecruitsView';

export { RecruitsView };
