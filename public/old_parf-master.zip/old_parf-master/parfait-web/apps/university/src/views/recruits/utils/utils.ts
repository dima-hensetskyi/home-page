import { getChatForUser } from 'graphql/chat';
import { GetQuestions } from 'graphql/users';
import { GetRecruits, GetRecruitsCohorts, UpdateRecruit } from 'graphql/recruits';
import { graphqlOperation, API } from 'aws-amplify';
import { GraphQLResult } from '@aws-amplify/api';
import {
  AttributesData,
  GetChatForRecruitResponse,
  GetQuestionsResponse,
  GetRecruitsCohortsResponseType,
  GetRecruitsResponseType,
  GetRecruitsVariablesType,
  QuestionCategory,
  Questions,
  RecruitResponseType,
  RecruitsFilterInput,
  RecruitType,
  UpdateRecruitInputType,
  UpdateRecruitResponseType,
  UserAnswers,
  VariablesType,
} from '../types';

export const getRecruitsListItem = (recruit: RecruitResponseType, tenant: string) => {
  const { user, institution, id, status, recruitCohort, recruitCohortId, assignedTenantUser } = recruit;
  const { name } = user;
  const { address } = institution;
  const userInstitution = user.userInstitutions.find((item) => item.name === tenant);
  const interest = userInstitution?.status || '';
  const assignedTenantUserId = assignedTenantUser?.id || null;
  return {
    userName: name,
    year: recruitCohort ? recruitCohort.classYear : '',
    cohort: recruitCohort ? recruitCohort.name : '',
    highSchool: institution.name,
    location: `${address.city} ${address.stateProvince}`,
    status,
    interest,
    id,
    assignedTenantUserId,
    assignedTenantUser,
    recruitCohortId: recruitCohortId,
    detail: recruit,
  };
};

export const getRecruitsList = (
  resp: RecruitResponseType[] | [],
  institution: string | undefined,
): Array<RecruitType> | [] => resp.map((recruit) => getRecruitsListItem(recruit, institution || ''));

export const getSearchingRecruitsList = (recruitsSearchResponse: RecruitResponseType[] | []) =>
  recruitsSearchResponse.map((item) => {
    const { user } = item;
    const { name } = user;
    return `${name}`;
  });

export const fetchRecruits = async (variables: GetRecruitsVariablesType) => {
  const result = (await API.graphql(
    graphqlOperation(GetRecruits, variables),
  )) as GraphQLResult<GetRecruitsResponseType>;
  const data = result.data?.getRecruits;
  return data;
};

export const fetchRecruitsCohorts = async () => {
  const result = (await API.graphql(
    graphqlOperation(GetRecruitsCohorts),
  )) as GraphQLResult<GetRecruitsCohortsResponseType>;
  const data = result.data?.getRecruitCohorts.items;
  return data;
};

export const updateRecruit = async (newRecruit: UpdateRecruitInputType) => {
  const result = (await API.graphql(
    graphqlOperation(UpdateRecruit, newRecruit),
  )) as GraphQLResult<UpdateRecruitResponseType>;
  const data = result.data?.updateRecruit;
  return data;
};

export const getQuestions = async () => {
  const result = (await API.graphql(graphqlOperation(GetQuestions))) as GraphQLResult<GetQuestionsResponse>;
  return result.data?.questions;
};

export const filterVariables = (deleteKeys: VariablesType, variables: RecruitsFilterInput) =>
  Object.fromEntries(
    Object.entries(variables).filter(([k]) =>
      deleteKeys === 'search' ? k !== 'searchTerms' : k !== 'statuses' && k !== 'recruitCohortIds',
    ),
  );

export const getAnswersByCategory = (
  category: QuestionCategory,
  data?: {
    questions: Questions;
    answers: UserAnswers;
  },
): Array<{
  label: string;
  value: string;
}> => {
  const result: Array<{
    label: string;
    value: string;
  }> = [];

  if (!data) return result;

  const { questions, answers } = data;

  const questionsByCategory = questions.filter((question) => {
    return question.category === category;
  });

  return questionsByCategory.reduce((acc: AttributesData, question) => {
    const res = answers.find((answers) => {
      return answers.question.id === question.id;
    });

    acc.push({
      label: question.name,
      value: res ? res!.answers.join(', ') : '-',
    });

    return acc;
  }, []);
};

export const GetChatForRecruit = async (userId: string) => {
  const result = (await API.graphql(
    graphqlOperation(getChatForUser, { userId }),
  )) as GraphQLResult<GetChatForRecruitResponse>;
  const data = result.data;
  return data;
};
