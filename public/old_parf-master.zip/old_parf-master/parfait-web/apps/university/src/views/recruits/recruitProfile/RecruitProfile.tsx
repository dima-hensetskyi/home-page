import { Box, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react';

import { AvatarComponent } from 'ui/components';
import {
  Controller,
  ControllerItem,
  ListItemBody,
  ListItemTitle,
  ProfileDetail,
  ProfileDetailTitle,
} from './RecruitProfile.styled';
import { getCorrectString } from '../utils';
import { ProfileInput } from './ProfileInput';
import { Questions, RecruitResponseType, RecruitType } from '../types';
import { RecruitUpdateStateType } from './types';
import { getAnswersByCategory, GetChatForRecruit, updateRecruit } from '../utils/utils';
import { useMutation, useQuery } from 'react-query';
import { RecruitAttributes } from './Attributes';

type PropsType = {
  recruit: RecruitType | null;
  questions?: Questions;
  onRecruitsUpdate: (updatedRecruit: RecruitResponseType) => void;
};

const initialState = {
  variables: null,
  isUpdating: false,
  updateId: null,
};

const NoData = '-';

export const RecruitProfile: React.FC<PropsType> = ({ recruit, onRecruitsUpdate, questions }: PropsType) => {
  if (!recruit) return null;
  const { userName, interest, highSchool, location, detail } = recruit;
  const { userQuestions, id, avatar } = detail.user;
  const correctLocation = location.split(' ').join(', ');

  const [state, setState] = useState<RecruitUpdateStateType>(initialState);

  const recruitMutation = useMutation(updateRecruit, {
    onSettled: (data) => {
      if (data) {
        onRecruitsUpdate(data);
        setState(() => initialState);
      }
    },
  });

  useQuery(['getRecruitChat', id], () => GetChatForRecruit(id), { retry: false });

  useEffect(() => {
    if (state.variables && state.isUpdating) {
      recruitMutation.mutateAsync({ input: state.variables });
    }
  }, [state.variables]);

  const graduationQuestion = questions && questions.find((question) => question.name === 'Graduation Year');
  const graduationYear =
    graduationQuestion && userQuestions.find((answer) => answer.question.id === graduationQuestion?.id);

  return (
    <Box sx={{ maxWidth: '500px' }}>
      <Box display="flex" alignItems="center">
        <AvatarComponent avatar={avatar} name={userName} sx={{ mr: '16px' }} />
        <Typography variant="body1">{userName}</Typography>
      </Box>
      <Controller>
        <ProfileInput setRecruitState={setState} recruit={recruit} state={state} />
        <ControllerItem>
          <ListItemTitle variant="body2">School interest:</ListItemTitle>
          <ListItemBody variant="body2">{getCorrectString(interest)}</ListItemBody>
        </ControllerItem>
      </Controller>
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
        <ProfileDetail>
          <ProfileDetailTitle variant="overline">Profile</ProfileDetailTitle>
          <ControllerItem>
            <ListItemTitle variant="body2">Graduation year:</ListItemTitle>
            <ListItemBody variant="body2">{graduationYear?.answers.join(',') || NoData}</ListItemBody>
          </ControllerItem>
          <ControllerItem>
            <ListItemTitle variant="body2">Current school:</ListItemTitle>
            <ListItemBody variant="body2">{highSchool}</ListItemBody>
          </ControllerItem>
          <ControllerItem>
            <ListItemTitle variant="body2">Location:</ListItemTitle>
            <ListItemBody variant="body2">{correctLocation}</ListItemBody>
          </ControllerItem>
        </ProfileDetail>
        {questions && (
          <>
            <RecruitAttributes
              title="Academics"
              data={getAnswersByCategory('ACADEMICS', { answers: userQuestions, questions })}
            />
            <RecruitAttributes
              title="Interests"
              data={getAnswersByCategory('INTEREST', { answers: userQuestions, questions })}
            />
          </>
        )}
      </Box>
    </Box>
  );
};
