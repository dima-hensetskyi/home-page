import { useContext } from 'react';
import { RecruitsContext } from './RecruitsContext';

import { RecruitsContextType } from '../types';

export const useRecruitsContext = (): RecruitsContextType => useContext(RecruitsContext)!;
