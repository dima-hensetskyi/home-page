import { AppManagement } from 'ui/components';

export const AppManagementView = () => {
  return <AppManagement />;
};
