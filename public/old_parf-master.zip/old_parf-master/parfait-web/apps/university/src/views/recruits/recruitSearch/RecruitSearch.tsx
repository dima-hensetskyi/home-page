import { SearchComponent } from 'ui/components';
import { useInfiniteQuery } from 'react-query';
import React, { useState } from 'react';

import { fetchRecruits } from '../utils/utils';
import { GetRecruitsVariablesType, VariablesType } from '../types';
import { getSearchingRecruitsList } from '../utils';
import { useRecruitsContext } from '../context';

type PropsType = {
  onClearReqVars: (vars: GetRecruitsVariablesType, deleteVariables: VariablesType) => void;
};

export const RecruitSearch: React.FC<PropsType> = ({ onClearReqVars }: PropsType) => {
  const { onChangeRequestVariables, getRecruitsVars } = useRecruitsContext();
  const [searchVariables, setSearchVariables] = useState<GetRecruitsVariablesType | undefined>(undefined);

  const { data, isFetching } = useInfiniteQuery(
    ['GetRecruits', searchVariables],
    () => {
      if (searchVariables) {
        const vars = { ...searchVariables };
        delete vars.nextToken;
        return fetchRecruits(vars);
      }
    },
    {
      enabled: !!searchVariables,
      retry: false,
      keepPreviousData: true,
    },
  );

  const onFetchAutoCompleteData = (searchTerms: string[]) =>
    setSearchVariables({ ...getRecruitsVars, filter: { ...getRecruitsVars.filter, searchTerms } });

  const onSearch = (searchTerms: string[]) => {
    const vars = { ...getRecruitsVars };
    delete vars.nextToken;

    onChangeRequestVariables({
      ...vars,
      filter: { ...getRecruitsVars.filter, searchTerms },
    });
  };

  const onClearSearch = () => {
    if (getRecruitsVars?.filter?.searchTerms) {
      onClearReqVars(getRecruitsVars, 'search');
    }
  };

  const pages = data?.pages || [];
  const pageList = pages[pages.length - 1]?.items || [];

  return (
    <SearchComponent
      autoCompleteData={getSearchingRecruitsList(pageList || [])}
      onFetchAutoCompleteData={onFetchAutoCompleteData}
      isAutoCompleteLoading={isFetching}
      onEnterDown={onSearch}
      onClearSearch={onClearSearch}
    />
  );
};
