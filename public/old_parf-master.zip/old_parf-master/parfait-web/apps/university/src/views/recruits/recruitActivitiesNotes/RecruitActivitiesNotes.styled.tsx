import { Button, styled, TextField } from '@mui/material';

export const ActionButton = styled(Button)(() => ({
  color: 'rgba(0, 0, 0, 0.3)',
  textTransform: 'none',

  svg: {
    width: '12px',
    height: '12px',
  },
}));

export const NoteTextFiled = styled(TextField)(() => ({
  [`.MuiOutlinedInput-root`]: {
    paddingTop: '8px',
    paddingBottom: '8px',
    minHeight: '112px',
  },
}));
