import { Box, CircularProgress } from '@mui/material';
import { Loader, TableComponent, TableTopControlPanel, useAuthContext } from 'ui/components';
import LoadingButton from '@mui/lab/LoadingButton';
import React from 'react';

import { fetchRecruits, filterVariables, getRecruitsList } from './utils/utils';
import { getCorrectString } from './utils';
import { GetRecruitsVariablesType, RecruitType, VariablesType } from './types';
import { initialRecruitsRequestVariables } from './RecruitsView';
import { RecruitsContext } from './context';
import { RecruitSearch } from './recruitSearch/RecruitSearch';
import { RecruitsFilterContainer } from './recruitsFilter/RecruitsFilterContainer';
import { Student } from './Student';
import { useInfiniteQuery, useQueryClient } from 'react-query';

type PropsType = {
  studentProps: {
    setIsDialogOpen: React.Dispatch<React.SetStateAction<boolean>>;
    setActiveRecruit: React.Dispatch<React.SetStateAction<RecruitType | null>>;
  };
  setRequestVariables: React.Dispatch<React.SetStateAction<GetRecruitsVariablesType>>;
  requestVariables: GetRecruitsVariablesType;
};

export const RecruitTable: React.FC<PropsType> = ({
  studentProps,
  requestVariables,
  setRequestVariables,
}: PropsType) => {
  const { tenant } = useAuthContext();

  const queryClient = useQueryClient();
  const queryId = ['GetRecruits', requestVariables];

  const { data, isFetching, isLoading, hasNextPage, fetchNextPage } = useInfiniteQuery(
    queryId,
    (data) => {
      return fetchRecruits(data.pageParam ? { ...requestVariables, nextToken: data.pageParam } : requestVariables);
    },
    {
      keepPreviousData: true,
      retry: false,
      getNextPageParam: (lastPage) => lastPage?.nextToken,
    },
  );

  const onChangeRequestVariables = (newVars: GetRecruitsVariablesType) => setRequestVariables(newVars);

  const onClearReqVars = async (vars: GetRecruitsVariablesType, deleteVariables: VariablesType) => {
    const initialData = queryClient.getQueryData(['GetRecruits', initialRecruitsRequestVariables]);

    if (vars && vars.filter) {
      const { filter } = vars;
      const newVars = filterVariables(deleteVariables, filter);
      const isEmpty = !Object.keys(newVars).length;
      if (!isEmpty) {
        setRequestVariables({ ...vars, filter: { ...newVars } });
      } else {
        queryClient.setQueryData(['GetRecruits', requestVariables], initialData);
        setRequestVariables(initialRecruitsRequestVariables);
      }
    } else {
      queryClient.setQueryData(['GetRecruits', requestVariables], initialData);
      setRequestVariables(initialRecruitsRequestVariables);
    }
  };

  const pages = data?.pages || [];
  const recruitsList = getRecruitsList(pages.map((page) => page?.items || []).flat(1), tenant?.name);

  return (
    <RecruitsContext.Provider value={{ onChangeRequestVariables, getRecruitsVars: requestVariables }}>
      <TableTopControlPanel title="Recruits">
        <CircularProgress
          size={30}
          sx={{ visibility: isFetching && !isLoading && requestVariables?.filter ? 'visible' : 'hidden' }}
        />
        <RecruitsFilterContainer onClearReqVars={onClearReqVars}></RecruitsFilterContainer>
        <RecruitSearch onClearReqVars={onClearReqVars} />
      </TableTopControlPanel>
      {isLoading ? (
        <Loader />
      ) : (
        <>
          <TableComponent
            tableHeaders={{
              userName: 'Student',
              year: 'Year',
              cohort: 'Cohort',
              highSchool: 'High School',
              location: 'Location',
              status: 'Status',
              interest: 'Interest',
            }}
            tableDataItems={recruitsList}
            tableCustomRenderers={{
              status: (recruit) => getCorrectString(recruit.status),
              interest: (recruit) => getCorrectString(recruit.interest),
              userName: (recruit) => <Student {...{ ...studentProps, recruit, recruitsList }} />,
            }}
          />
          <Box sx={{ display: 'flex', visibility: hasNextPage ? 'visible' : 'hidden', justifyContent: 'flex-end' }}>
            <LoadingButton
              loading={isFetching}
              sx={{
                fontSize: '15px',
                lineHeight: '26px',
                letterSpacing: '0.46px',
              }}
              variant="contained"
              onClick={() => fetchNextPage()}
            >
              SHOW MORE
            </LoadingButton>
          </Box>
        </>
      )}
    </RecruitsContext.Provider>
  );
};
