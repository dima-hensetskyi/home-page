import { RecruitResponseType } from './../types';
import { S3Object } from '../types';

export type RecruitActivity = {
  __typename: 'RecruitNote' | 'RecruitStatusChange' | 'RecruitFair';
  id: string;
  recruitId: string;
  userId: string;
  tenantUser: {
    familyName: string;
    name: string;
    id: string;
    givenName: string;
    avatar: S3Object;
  };
  recruit?: RecruitResponseType;
  event?: {
    name: string;
  };
  createdAt: string;
  updatedAt: string;
  note: string;
  connectType?: string;
  previousStatus?: string;
  status?: string;
  pageIdx: number;
};

export type GetRecruitActivitiesResponse = {
  getRecruitActivities: {
    items: RecruitActivity[];
    nextToken: string;
  };
};

export type GetRecruitActivitiesQuarry = {
  pageParams: [];
  pages: Array<{ items: RecruitActivity[]; nextToken: string }>;
};

export type AuthenticatedUser = {
  getAuthenticatedTenantUser: {
    familyName: string;
    givenName: string;
    name: string;
    id: string;
    avatar: S3Object;
  };
};
