import { Box, Typography } from '@mui/material';
import { useInfiniteQuery, useQueryClient } from 'react-query';
import { Virtuoso } from 'react-virtuoso';
import React, { useState } from 'react';

import { ActivityNotesItem } from './ActivityNotesItem';
import { AuthenticatedUser, RecruitActivity } from './types';
import { CustomScrollbar, Loader } from 'ui/components';
import { fetchRecruitsNotesActivityList, RecruitActivityNotesLimit } from './utils';
import { NotesForm } from './NoteForm';

type PropsType = {
  recruitId: string;
};

export interface EditVariables extends RecruitActivity {
  pageIdx: number;
}

export type EditingProps = {
  isEditing: boolean;
  data: null | EditVariables;
};

const scrollerHeight = 432;

export const RecruitActivitiesNotes = ({ recruitId }: PropsType) => {
  const queryClient = useQueryClient();
  const authenticatedUser = queryClient.getQueryData('AuthenticatedTenantUser') as AuthenticatedUser;

  const [isEditing, setIsEditing] = useState<EditingProps>({
    isEditing: false,
    data: null,
  });
  const requestVariables = { recruitId, limit: RecruitActivityNotesLimit };
  const initialTopMostItemIndex = 10000;
  const [firstItemIndex, setFirstItemIndex] = useState(initialTopMostItemIndex);

  const { data, hasNextPage, isFetching, isLoading, fetchNextPage } = useInfiniteQuery(
    ['getRecruitActivities', recruitId],
    (data) => {
      return fetchRecruitsNotesActivityList(
        data.pageParam ? { ...requestVariables, nextToken: data.pageParam } : requestVariables,
      );
    },
    {
      retry: false,
      getNextPageParam: (lastPage) => lastPage?.nextToken,
      select: (data) => ({
        pages: data.pages.map((page, pageIdx) => ({
          ...page,
          items: page?.items.map((item) => ({ ...item, pageIdx })),
        })),
        pageParams: data.pageParams,
      }),
    },
  );

  const toggleEditing = (isEditing: boolean, data: EditVariables | null) => {
    setIsEditing({ isEditing, data });
  };

  const ListRef = React.useRef(null);
  const isNewNote = React.useRef(false);

  const onStartReached = async () => {
    if (hasNextPage && !isFetching) {
      const newDate = await fetchNextPage();
      const newCount = newDate?.data?.pages[newDate?.data?.pages.length - 1].items?.length || 0;
      setFirstItemIndex((prev) => prev - newCount);
    }
  };

  const list =
    data?.pages
      .map((page) => page?.items)
      .flat(1)
      .reverse() || [];

  return (
    <Box>
      <Typography variant="h6" mb="12px">
        Activity and Notes
      </Typography>
      <Box style={{ height: scrollerHeight, position: 'relative' }}>
        {isLoading ? (
          <Loader />
        ) : (
          <Virtuoso
            ref={ListRef}
            components={{
              // eslint-disable-next-line @typescript-eslint/ban-ts-comment
              // @ts-ignore
              Scroller: CustomScrollbar,
            }}
            data={list}
            initialTopMostItemIndex={initialTopMostItemIndex}
            startReached={onStartReached}
            firstItemIndex={firstItemIndex}
            itemContent={(index, dataItem) =>
              dataItem && (
                <ActivityNotesItem
                  authenticatedUser={authenticatedUser}
                  toggleEditing={toggleEditing}
                  key={dataItem?.id}
                  data={dataItem}
                />
              )
            }
            followOutput={(isAtBottom) => {
              if (isNewNote.current) {
                return isAtBottom ? 'smooth' : 'auto';
              } else {
                return isAtBottom ? 'smooth' : false;
              }
            }}
          />
        )}
      </Box>
      {authenticatedUser && (
        <NotesForm
          isNewNote={isNewNote}
          toggleEditing={toggleEditing}
          editingData={isEditing}
          recruitId={recruitId}
          user={authenticatedUser}
        />
      )}
    </Box>
  );
};
