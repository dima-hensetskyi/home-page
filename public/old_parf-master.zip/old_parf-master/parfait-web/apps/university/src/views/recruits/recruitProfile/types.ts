export type RecruitUpdateStateType = {
  variables: {
    id: string;
    recruitCohortId?: string;
    status?: string;
    assignedTenantUserId?: string;
  } | null;
  isUpdating: boolean;
  updateId: string | null;
};

export type TenantUsersRequestVariablesType = {
  limit?: number;
  sortDirection: 'ASC' | 'DESC';
  nextToken?: string | null;
};
