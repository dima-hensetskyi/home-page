import { FilterMenu } from 'ui/components';
import React, { useEffect, useState } from 'react';

import { GetRecruitsVariablesType, RecruitInitialStateType, VariablesType } from '../types';
import { RecruitsFilter } from './RecruitsFilter';
import { useRecruitsContext } from '../context';

export const recruitInitialState: RecruitInitialStateType = {
  isFiltering: false,
  recruitCohortIds: [],
  statuses: [],
  requestVariables: null,
};

type PropsType = {
  onClearReqVars: (vars: GetRecruitsVariablesType, deleteVariables: VariablesType) => void;
};

export const RecruitsFilterContainer: React.FC<PropsType> = ({ onClearReqVars }: PropsType) => {
  const { onChangeRequestVariables, getRecruitsVars } = useRecruitsContext();
  const [state, setState] = useState<RecruitInitialStateType>(recruitInitialState);
  const [isMenuOpen, setMenuOpen] = useState(false);
  const { isFiltering, requestVariables } = state;

  useEffect(() => {
    if (requestVariables) {
      const vars = { ...getRecruitsVars };
      delete vars.nextToken;
      onChangeRequestVariables({
        ...vars,
        filter: { ...getRecruitsVars.filter, ...requestVariables },
      });
    }
  }, [requestVariables]);

  const recruitsFilterProps = {
    state,
    setState,
    setMenuOpen,
    onClearReqVars,
  };

  const menuProps = {
    isMenuOpen,
    setMenuOpen,
    isApplyFilter: isFiltering,
  };

  return (
    <>
      <FilterMenu {...menuProps}>
        <RecruitsFilter {...recruitsFilterProps}></RecruitsFilter>
      </FilterMenu>
    </>
  );
};
