import { API, graphqlOperation } from 'aws-amplify';
import { Box, Button, DialogActions, Popover, Typography } from '@mui/material';
import { GraphQLResult } from '@aws-amplify/api';
import React from 'react';

import { ActionButton } from './RecruitActivitiesNotes.styled';
import { CustomIcon } from 'ui/components';
import { deleteRecruitActivity } from 'graphql/recruits';
import { GetRecruitActivitiesQuarry, RecruitActivity } from './types';
import { useMutation, useQueryClient } from 'react-query';

type PropsType = {
  id: string;
  recruitId: string;
  pageIdx: number;
};

export const DeleteNoteButton: React.FC<PropsType> = ({ id, recruitId, pageIdx }: PropsType) => {
  const [anchorEl, setAnchorEl] = React.useState<HTMLButtonElement | null>(null);
  const queryClient = useQueryClient();
  const queryId = ['getRecruitActivities', recruitId];

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);

  const removeNote = useMutation(
    async () => {
      const result = (await API.graphql(
        graphqlOperation(deleteRecruitActivity, { id: id }),
      )) as GraphQLResult<RecruitActivity>;
      return result.data;
    },
    {
      onMutate: async (vars: { id: string; pageIdx: number }) => {
        await queryClient.cancelQueries(queryId);
        const oldNotes = queryClient.getQueryData<GetRecruitActivitiesQuarry>(queryId);
        if (oldNotes) {
          const newNotes = { ...oldNotes };
          const noteIdx = newNotes.pages[vars.pageIdx].items.findIndex((item) => item.id === vars.id);
          newNotes.pages[vars.pageIdx].items.splice(noteIdx, 1);
          queryClient.setQueryData<GetRecruitActivitiesQuarry>(queryId, newNotes);
        }
        return { oldNotes };
      },
      onError: (_err, _variables, context) => {
        if (context?.oldNotes) {
          const oldData = context?.oldNotes;
          queryClient.setQueryData<GetRecruitActivitiesQuarry>(queryId, oldData);
        }
      },
      onSettled: () => {
        queryClient.invalidateQueries(queryId);
      },
    },
  );

  return (
    <>
      <ActionButton size="small" variant="text" startIcon={<CustomIcon />} onClick={handleClick}>
        <Typography variant="caption">Delete</Typography>
      </ActionButton>
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'center',
          horizontal: 'left',
        }}
      >
        <Box sx={{ p: 2 }}>
          <Typography>Delete note? This is a permanent action.</Typography>
          <DialogActions sx={{ p: 0 }}>
            <Button autoFocus onClick={handleClose}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                removeNote.mutateAsync({ id, pageIdx });
                handleClose();
              }}
            >
              CONFIRM
            </Button>
          </DialogActions>
        </Box>
      </Popover>
    </>
  );
};
