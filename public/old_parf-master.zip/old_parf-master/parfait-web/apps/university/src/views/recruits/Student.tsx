import { Typography } from '@mui/material';
import React from 'react';

import { RecruitType } from './types';

type PropsType = {
  recruit?: RecruitType;
  setIsDialogOpen: React.Dispatch<React.SetStateAction<boolean>>;
  recruitsList: [] | RecruitType[];
  setActiveRecruit: React.Dispatch<React.SetStateAction<RecruitType | null>>;
};

export const Student: React.FC<PropsType> = ({ recruit, setIsDialogOpen, recruitsList, setActiveRecruit }: PropsType) =>
  recruit ? (
    <Typography
      sx={{ color: (theme) => theme.palette.primary.main, ':hover': { cursor: 'pointer' } }}
      onClick={() => {
        const currentRecruit = recruitsList.find((item) => item.id === recruit.id);
        if (currentRecruit) {
          setActiveRecruit(currentRecruit);
          setIsDialogOpen(true);
        }
      }}
      variant="body2"
    >
      {recruit['userName']}
    </Typography>
  ) : null;
