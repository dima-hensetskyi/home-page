import { Box, CircularProgress, MenuItem } from '@mui/material';
import { useQueryClient } from 'react-query';
import React from 'react';

import { getCorrectString } from '../utils';
import { getScrollBottom, useTenantUsers } from 'ui/components';
import { RecruitCohortType, RecruitType } from '../types';
import { recruitsStatuses } from '../data';
import { RecruitUpdateStateType } from './types';
import { SelectComponent } from './SelectComponent';

type PropsType = {
  recruit: RecruitType;
  state: RecruitUpdateStateType;
  setRecruitState: React.Dispatch<React.SetStateAction<RecruitUpdateStateType>>;
};

type recruitsKeys = 'assignedTenantUserId' | 'recruitCohortId' | 'status';

export const ProfileInput: React.FC<PropsType> = ({ recruit, state, setRecruitState }: PropsType) => {
  const { id, assignedTenantUser } = recruit;
  const { isUpdating, variables, updateId } = state;

  const queryClient = useQueryClient();
  const recruitsCohorts = queryClient.getQueryData<Array<RecruitCohortType>>('GetRecruitsCohorts') || [];

  const onRecruitUpdate = (key: recruitsKeys, value: string) => {
    setRecruitState({
      ...state,
      isUpdating: true,
      updateId: id,
      variables: { id: recruit.id, [key]: value },
    });
  };

  const getValue = (key: recruitsKeys) =>
    variables && isUpdating && variables[key] && updateId === id ? variables[key] : recruit[key];

  const tenantUsers = useTenantUsers({ sortDirection: 'ASC', limit: 10 });
  const tenantUsersList = tenantUsers.data?.pages.map((page) => page?.items || []).flat(1) || [];

  return (
    <>
      <SelectComponent
        onChange={(evt) => onRecruitUpdate('recruitCohortId', evt.target.value as string)}
        value={getValue('recruitCohortId')}
        title="Cohort"
      >
        {recruitsCohorts.map((cohort) => (
          <MenuItem key={cohort.id} value={cohort.id}>
            {cohort.name}
          </MenuItem>
        ))}
      </SelectComponent>
      <SelectComponent
        onChange={(evt) => onRecruitUpdate('status', evt.target.value as string)}
        value={getValue('status')}
        title="Status"
      >
        {recruitsStatuses.map((status) => (
          <MenuItem key={status} value={status}>
            {getCorrectString(status)}
          </MenuItem>
        ))}
      </SelectComponent>
      <SelectComponent
        onChange={(evt) => onRecruitUpdate('assignedTenantUserId', evt.target.value as string)}
        value={getValue('assignedTenantUserId') || ''}
        title="Assigned"
        MenuProps={{
          PaperProps: {
            onScroll: (evt: React.UIEvent<HTMLDivElement>) => {
              const isFetchMore = getScrollBottom(evt);
              if (isFetchMore && tenantUsers.hasNextPage && !tenantUsers.isFetching) {
                //user is at the end of the list so load more items
                tenantUsers.fetchNextPage();
              }
            },
          },
          style: {
            maxHeight: 250,
          },
        }}
      >
        {assignedTenantUser && (
          <MenuItem sx={{ display: 'none' }} key={assignedTenantUser.id} value={assignedTenantUser.id}>
            {assignedTenantUser.name}
          </MenuItem>
        )}
        {tenantUsersList.map((user) => (
          <MenuItem key={user.id} value={user.id}>
            {user.name}
          </MenuItem>
        ))}
        {tenantUsers.isFetching && (
          <Box sx={{ display: 'flex', justifyContent: 'center', width: '100%' }}>
            <CircularProgress sx={{ width: '20px !important', height: '20px !important' }} />
          </Box>
        )}
      </SelectComponent>
    </>
  );
};
