import { Box, Typography } from '@mui/material';
import { Edit } from '@mui/icons-material';
import React from 'react';

import { ActionButton } from './RecruitActivitiesNotes.styled';
import { AvatarComponent } from 'ui/components';
import { DeleteNoteButton } from './DeleteNoteButton';
import { EditVariables } from './recruitActivitiesNotes';
import { AuthenticatedUser, RecruitActivity } from './types';
import { getCorrectString } from '../utils';
import dayjs from 'dayjs';

type PropsType = {
  data: RecruitActivity;
  onDelete?: () => void;
  toggleEditing: (val: boolean, data: EditVariables | null) => void;
  authenticatedUser: AuthenticatedUser;
};

export const ActivityNotesItem: React.FC<PropsType> = ({ data, toggleEditing, authenticatedUser }: PropsType) => {
  const { tenantUser, note, updatedAt, createdAt, __typename } = data;
  const { id } = authenticatedUser.getAuthenticatedTenantUser;
  const isActions = __typename === 'RecruitNote' && id === data.tenantUser.id;
  const isNote = __typename === 'RecruitNote';
  const message = {
    RecruitNote: note,
    RecruitStatusChange: `${tenantUser.givenName} changed recruit status from ${getCorrectString(
      data?.previousStatus || '',
    )} to ${getCorrectString(data?.status || '')}.`,
    RecruitFair: `${data?.recruit?.user?.givenName} scanned at ${data?.event?.name}`,
  };

  return (
    <Box sx={{ display: 'flex', gap: '8px', pt: '16px' }}>
      <AvatarComponent sx={{ width: '32px', height: '32px' }} avatar={tenantUser.avatar} name={tenantUser.name} />
      <Box sx={{ display: 'grid', gap: '4px', width: '100%', pr: '14px' }}>
        {isNote && <Typography variant="body2">{tenantUser.name}</Typography>}
        <Typography variant="body2">{message[__typename as keyof typeof message]}</Typography>
        <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
          <Typography variant="caption" sx={{ color: 'rgba(0, 0, 0, 0.6)' }}>
            {dayjs(updatedAt || createdAt).format('MMMM, DD, YYYY')}
          </Typography>
          {/* {updatedAt && (
            <Typography sx={{ color: 'rgba(0, 0, 0, 0.6)' }} variant="caption">
              edited
            </Typography>
          )} */}
        </Box>
        {isActions && (
          <Box sx={{ display: 'flex', gap: '10px', maxHeight: '20px' }}>
            <ActionButton size="small" variant="text" onClick={() => toggleEditing(true, data)} startIcon={<Edit />}>
              <Typography variant="caption">Edit</Typography>
            </ActionButton>
            <DeleteNoteButton pageIdx={data.pageIdx} id={data.id} recruitId={data.recruitId} />
          </Box>
        )}
      </Box>
    </Box>
  );
};
