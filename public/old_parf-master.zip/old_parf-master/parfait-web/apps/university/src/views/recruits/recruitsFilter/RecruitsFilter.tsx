import { Button, FormControl, InputLabel, MenuItem, Select, SelectChangeEvent } from '@mui/material';
import React, { memo, useState } from 'react';

import { getCorrectString } from '../utils';
import {
  GetRecruitsVariablesType,
  RecruitCohortType,
  RecruitInitialStateType,
  RecruitsFilterInput,
  VariablesType,
} from '../types';
import { recruitInitialState } from './RecruitsFilterContainer';
import { recruitsStatuses } from '../data';
import { useQueryClient } from 'react-query';
import { useRecruitsContext } from '../context';

type PropsType = {
  setMenuOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setState: React.Dispatch<React.SetStateAction<RecruitInitialStateType>>;
  state: RecruitInitialStateType;
  onClearReqVars: (vars: GetRecruitsVariablesType, deleteVariables: VariablesType) => void;
};

const RecruitsFilterComponent: React.FC<PropsType> = ({ state, setState, setMenuOpen, onClearReqVars }: PropsType) => {
  const [filters, setFilters] = useState({
    recruitCohortIds: state.recruitCohortIds || [],
    statuses: state.statuses || [],
    isFiltering: false,
  });
  const queryClient = useQueryClient();
  const recruitsCohorts = queryClient.getQueryData<Array<RecruitCohortType>>('GetRecruitsCohorts') || [];
  const { getRecruitsVars } = useRecruitsContext();

  const { recruitCohortIds, statuses } = filters;
  const isFiltering = state.isFiltering || filters.isFiltering;

  const onClear = () => {
    if (isFiltering) {
      setState(recruitInitialState);
      setMenuOpen(false);
      onClearReqVars(getRecruitsVars, 'filters');
    }
  };

  const onSubmit = () => {
    if (isFiltering) {
      const variables: RecruitsFilterInput = state.requestVariables ? state.requestVariables : {};

      if (recruitCohortIds && recruitCohortIds.length) {
        variables['recruitCohortIds'] = recruitCohortIds;
      }

      if (statuses && statuses.length) {
        variables['statuses'] = statuses;
      }

      setState({
        ...filters,
        isFiltering: true,
        requestVariables: { ...variables },
      });
      setMenuOpen(false);
    }
  };

  const onChange = (key: 'recruitCohortIds' | 'statuses', evt: SelectChangeEvent<string[]>) => {
    const {
      target: { value },
    } = evt;
    setFilters({
      ...filters,
      [key]: typeof value === 'string' ? value.split(',') : value,
      isFiltering: true,
    });
  };

  return (
    <>
      <FormControl fullWidth size="small" sx={{ marginBottom: '15px' }}>
        <InputLabel id="Cohort">Cohort</InputLabel>
        <Select
          multiple
          labelId="Cohort"
          label="Cohort"
          value={recruitCohortIds}
          onChange={(evt) => {
            onChange('recruitCohortIds', evt);
          }}
        >
          {recruitsCohorts.map((cohort) => (
            <MenuItem key={cohort.id} value={cohort.id}>
              {cohort.name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <FormControl fullWidth size="small" sx={{ marginBottom: '15px' }}>
        <InputLabel id="Status">Status</InputLabel>
        <Select multiple labelId="Status" label="Status" value={statuses} onChange={(evt) => onChange('statuses', evt)}>
          {recruitsStatuses.map((status) => (
            <MenuItem key={status} value={status}>
              {getCorrectString(status)}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <Button
        variant="contained"
        fullWidth
        disabled={!isFiltering}
        sx={{
          background: '#1976D2',
          marginBottom: '15px',
          fontSize: '13px',
          lineHeight: '22px',
          letterSpacing: '0.46px',
        }}
        onClick={onSubmit}
      >
        apply filter
      </Button>
      <Button
        variant="outlined"
        fullWidth
        onClick={onClear}
        sx={{
          color: '#1976D2',
          fontSize: '13px',
          lineHeight: '22px',
          letterSpacing: '0.46px',
        }}
      >
        Clear all
      </Button>
    </>
  );
};

export const RecruitsFilter = memo(
  RecruitsFilterComponent,
  (prevProps, currentProps) => JSON.stringify(prevProps) === JSON.stringify(currentProps),
);
