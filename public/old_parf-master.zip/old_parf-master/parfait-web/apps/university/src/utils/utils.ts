export const getCorrectString = (str: string) => {
  return str.slice(0, 1) + str.slice(1).toLowerCase().replace('_', ' ');
};
