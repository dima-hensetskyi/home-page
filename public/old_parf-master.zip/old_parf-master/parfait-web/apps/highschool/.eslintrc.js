module.exports = {
  ...require('config/eslint-preset'),
};
