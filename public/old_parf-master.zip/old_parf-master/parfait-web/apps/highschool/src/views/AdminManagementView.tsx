import { Navigate } from 'react-router-dom';
import React from 'react';

import { useAuthContext, UsersView } from 'ui/components';

export const AdminManagementView: React.FC = () => {
  const { userRole } = useAuthContext();
  if (userRole !== 'Admin') return <Navigate to="students" replace />;

  return <UsersView />;
};
