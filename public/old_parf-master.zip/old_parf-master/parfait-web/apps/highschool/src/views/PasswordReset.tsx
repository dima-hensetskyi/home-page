import { PasswordResetForm, LoginLayout } from 'ui/components';

const PasswordReset = () => {
  return (
    <LoginLayout title="Forgot Password?" type="highSchool">
      <PasswordResetForm />
    </LoginLayout>
  );
};

export default PasswordReset;
