import React from 'react';
import { Students } from 'ui/components';

const StudentsView = () => {
  return (
    <div>
      <Students />
    </div>
  );
};

export default StudentsView;
