import React from 'react';
import { InvitesContainer } from 'ui/components';

const Invites = () => {
  return <InvitesContainer />;
};

export default Invites;
