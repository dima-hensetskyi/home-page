import { PasswordResetSubmitForm, LoginLayout } from 'ui/components';

const PasswordResetSubmit = () => {
  return (
    <LoginLayout title="Forgot Password?" type="highSchool">
      <PasswordResetSubmitForm />
    </LoginLayout>
  );
};

export default PasswordResetSubmit;
