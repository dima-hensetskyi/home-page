const HomeView = () => {
  return <h1>Highschool Home Page</h1>;
};

export default HomeView;
