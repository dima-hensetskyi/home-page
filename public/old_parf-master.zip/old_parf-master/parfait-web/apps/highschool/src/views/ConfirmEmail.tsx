import React from 'react';
import { ConfirmEmailForm, LoginLayout } from 'ui/components';

const ConfirmEmail = () => {
  return (
    <LoginLayout title="Confirm your account" type="highSchool">
      <ConfirmEmailForm />
    </LoginLayout>
  );
};

export default ConfirmEmail;
