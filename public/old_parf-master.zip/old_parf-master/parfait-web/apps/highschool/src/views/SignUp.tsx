import React from 'react';
import { RegistrationForm, LoginLayout } from 'ui/components';

const SignUp: React.FC = () => {
  return (
    <LoginLayout title="Sign up" type="highSchool">
      <RegistrationForm />
    </LoginLayout>
  );
};

export default SignUp;
