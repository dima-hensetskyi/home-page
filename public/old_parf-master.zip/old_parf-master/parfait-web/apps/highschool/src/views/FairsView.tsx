import React from 'react';
import { FairsContainer } from 'ui/components';

export const FairsView = () => <FairsContainer />;
// export const FairsView = () => 'Hello';
