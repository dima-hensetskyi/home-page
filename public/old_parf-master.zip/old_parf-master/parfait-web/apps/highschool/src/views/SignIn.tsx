import { LoginLayout, LoginForm } from 'ui/components';

const SignIn = () => {
  return (
    <LoginLayout title="Sign in" type="highSchool">
      <LoginForm />
    </LoginLayout>
  );
};

export default SignIn;
