import { Link } from 'react-router-dom';

const NoMatchView = () => {
  return (
    <div>
      <h1>404: No Match (Highschool)</h1>
      <Link to="/">Go home</Link>
    </div>
  );
};

export default NoMatchView;
