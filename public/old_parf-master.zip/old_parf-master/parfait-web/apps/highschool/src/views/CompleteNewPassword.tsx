import React from 'react';
import { LoginLayout } from 'ui/components';
import { CompletePasswordForm } from 'ui/components';

export const CompleteNewPassword = () => (
  <LoginLayout title="Forgot Password?" type="university">
    <CompletePasswordForm />
  </LoginLayout>
);
