import { menuLinks } from './menuLinks';

export { menuLinks };
