import { NavLinkType } from 'ui/src/components/NavigationMenu/types';

export const menuLinks: Array<NavLinkType> = [
  { title: 'Students', to: '/students' },
  { title: 'College Fairs', to: '/college-fairs' },
  { title: 'Invites', to: '/invites' },
];
