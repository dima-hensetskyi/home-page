import { RouteObject } from 'react-router-dom';
import HomeView from '../views/HomeView';
import NoMatchView from '../views/NoMatchView';

const routes: RouteObject[] = [
  {
    path: '/',
    element: <HomeView />,
  },
  { path: '*', element: <NoMatchView /> },
];

export default routes;
