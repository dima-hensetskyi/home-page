import AuthorizedRoutes from './AuthorizedRoutes';

export default AuthorizedRoutes;
