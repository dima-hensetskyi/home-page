import UnAuthorizedRoutes from './UnAuthorizedRoutes';

export default UnAuthorizedRoutes;
