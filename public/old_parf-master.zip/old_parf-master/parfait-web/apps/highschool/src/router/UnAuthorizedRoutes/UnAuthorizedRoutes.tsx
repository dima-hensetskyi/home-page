import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import SignIn from '../../views/SignIn';
import SignUp from '../../views/SignUp';
import PasswordReset from '../../views/PasswordReset';
import PasswordResetSubmit from '../../views/PasswordResetSubmit';
import ConfirmEmail from '../../views/ConfirmEmail';
import { CompleteNewPassword } from '../../views/CompleteNewPassword';

const UnAuthorizedRoutes = () => {
  return (
    <div>
      <Routes>
        <Route path="/sign-in" element={<SignIn />} />
        <Route path="/sign-up" element={<SignUp />} />
        <Route path="/reset-password" element={<PasswordReset />} />
        <Route path="/reset-password-submit" element={<PasswordResetSubmit />} />
        <Route path="/complete-new-password" element={<CompleteNewPassword />} />
        <Route path="/confirm-email" element={<ConfirmEmail />} />
        <Route path="*" element={<Navigate to="sign-in" />} />
      </Routes>
    </div>
  );
};

export default UnAuthorizedRoutes;
