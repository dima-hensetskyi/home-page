import React from 'react';
import { AdminManagementView } from '../../views/AdminManagementView';
import { FairsView } from '../../views/FairsView';
import { Routes, Route, Navigate } from 'react-router-dom';
import Invites from '../../views/Invites';
import NoMatchView from '../../views/NoMatchView';
import Students from '../../views/Students';

const AuthorizedRoutes = () => {
  return (
    <Routes>
      <Route path="/*" element={<Navigate to="students" replace />}></Route>
      <Route path="/students" element={<Students />} />
      <Route path="/college-fairs" element={<FairsView />} />
      <Route path="/invites" element={<Invites />} />
      <Route path="/manage-account" element={<AdminManagementView />} />
      <Route path="*" element={<NoMatchView />} />
    </Routes>
  );
};

export default AuthorizedRoutes;
