import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { CssBaseline, ThemeProvider } from '@mui/material';
import { theme } from 'ui';
import { QueryClient, QueryClientProvider } from 'react-query';
import { GlobalStyle } from 'ui/components';
import Amplify, { Storage } from 'aws-amplify';
import awsExport from 'config/aws-exports';
import awsConfig from 'config/aws-config';
import { SnackbarProvider } from 'notistack';

Amplify.configure(awsExport);

Storage.configure({
  customPrefix: {
    public: awsConfig.s3.PUBLIC_BUCKET_PREFIX,
  },
});

// Create a client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
    },
  },
});

ReactDOM.render(
  <React.StrictMode>
    <GlobalStyle />
    <CssBaseline />
    <QueryClientProvider client={queryClient}>
      <ThemeProvider theme={theme}>
        <BrowserRouter>
          <SnackbarProvider
            maxSnack={1}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'center',
            }}
            autoHideDuration={2000}
          >
            <App />
          </SnackbarProvider>
        </BrowserRouter>
      </ThemeProvider>
    </QueryClientProvider>
  </React.StrictMode>,
  document.getElementById('root'),
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
