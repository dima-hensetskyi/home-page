import React from 'react';
import { AuthContainer, DashboardLayout, TermsAndConditions } from 'ui/components';
import { menuLinks } from './data';
import AuthorizedRoutes from './router/AuthorizedRoutes';
import UnAuthorizedRoutes from './router/UnAuthorizedRoutes';
import { Route, Routes } from 'react-router-dom';
import { PublicRegistration, PrivateRegistration } from 'ui/components';

const App = () => {
  return (
    <main>
      <AuthContainer appType="highSchool">
        {({ authorized }) => (
          <Routes>
            <Route path="/event-registration/:id" element={<PublicRegistration />}></Route>
            <Route path="/event-invite-registration/:id" element={<PrivateRegistration />}></Route>
            <Route path="/terms-and-conditions" element={<TermsAndConditions />}></Route>

            <Route
              path="/*"
              element={
                <>
                  {authorized ? (
                    <DashboardLayout menuLinks={menuLinks}>
                      <AuthorizedRoutes />
                    </DashboardLayout>
                  ) : (
                    <UnAuthorizedRoutes />
                  )}
                </>
              }
            ></Route>
          </Routes>
        )}
      </AuthContainer>
    </main>
  );
};

export default App;
