export default {
  customColors: {
    darkGrey: '#2B2D42' as const,
    darkGreyLight: '#3C3F5C' as const,
    tuna: '#1976d298' as const,
    primaryLight: '#1976D2' as const,
    aqua: '#EEF2FA' as const,
  },
};
