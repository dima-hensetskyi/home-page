export default {
  STRIPE_KEY: 'pk_test_v1amvR35uoCNduJfkqGB8RLD',
  s3: {
    BUCKET: 'parfait-files-dev',
    REGION: 'us-east-2',
    PUBLIC_BUCKET_PREFIX: '',
  },
  cognito: {
    REGION: 'us-east-2',
    USER_POOL_ID: 'us-east-2_w5THjNLMg',
    APP_CLIENT_ID: '7cbendftin1jf082nqhb8q63g1',
    IDENTITY_POOL_ID: 'us-east-2:660885f8-4d8d-4bb6-a201-1f7dabad203f',
  },
};
