import { S3Object } from './general';

export const getTenantAvailable = `query GetTenantAvailable($account: String!, $username: String!) {
  getTenantAvailable(account: $account) {
    available
  }
}
`;

export const createTenantAndAccountOwner = /* GraphQL */ `
  mutation CreateTenantAndAccountOwner($input: CreateTenantAndAccountOwnerInput!) {
    createTenantAndAccountOwner(input: $input) {
      id
    }
  }
`;

export const getTenantUserConnectionInfo = `query GetTenantUserConnectionInfo($account: String!, $username: String!) {
  getTenantUserConnectionInfo(account: $account, username: $username) {
    userSub
    userPool
    identityPool
    appClient
  }
}
`;

export const TenantUser = /* GraphQL */ `
  fragment TenantUser on TenantUser {
    name
    role
    username
    status
    createdAt
    lastAuthentication
    phoneNumber
    id
    updatedAt
    givenName
    displayName
    familyName
    email
    avatar {
      ...S3Object
    }
    preferences {
      subscribeNews
      eventNotification
      newChatMessage
      onlyChatMessageThread
    }
  }
  ${S3Object}
`;

export const updateTenantUser = `mutation UpdateTenantUser($input: UpdateTenantUserInput!) {
  updateTenantUser(input: $input) {
    __typename
    id
    role
    givenName
    familyName
    updatedAt
    positionReferenceLinks
    name
    username
    status
    createdAt
    lastAuthentication
    phoneNumber
    displayName
    email
    avatar {
      bucket
      region
      key
    }
  }
}`;

export const getAuthenticatedTenant = `query GetAuthenticatedTenant {
    tenant:getAuthenticatedTenant {
      id
      account
      status
      tier
      name
      institutionId
      createdAt
      updatedAt
    }
}
`;

export const getTenantAvatar = /* GraphQL */ `
  query GetTenantUser($id: ID!) {
    getTenantUser(id: $id) {
      id
      name
      avatar {
        bucket
        region
        key
      }
    }
  }
`;

export const GetTenantUsers = /* GraphQL */ `
  query getTenantUsers($sortDirection: ModelSortDirection, $limit: Int, $nextToken: String) {
    getTenantUsers(sortDirection: $sortDirection, limit: $limit, nextToken: $nextToken) {
      items {
        ...TenantUser
      }
      nextToken
    }
  }
  ${TenantUser}
`;

export const CreateTenantUser = /* GraphQL */ `
  mutation createTenantUser($input: CreateTenantUserInput!) {
    createTenantUser(input: $input) {
      ...TenantUser
    }
  }
  ${TenantUser}
`;

export const reinviteTenantUser = /* GraphQL */ `
  mutation reinviteTenantUser($input: ReinviteTenantUserInput!) {
    reinviteTenantUser(input: $input) {
      ...TenantUser
    }
  }
  ${TenantUser}
`;

export const updateTenantUserPreferences = /* GraphQL */ `
  mutation updateTenantUserPreferences($input: UpdateTenantUserPreferencesInput!) {
    updateTenantUserPreferences(input: $input) {
      ...TenantUser
    }
  }
  ${TenantUser}
`;

export const GetAuthenticatedTenantUser = /* GraphQL */ `
  query getAuthenticatedTenantUser {
    getAuthenticatedTenantUser {
      ...TenantUser
    }
  }
  ${TenantUser}
`;

export const GetTenantUserAvailable = /* GraphQL */ `
  query getTenantUserAvailable($username: String!, $email: AWSEmail!) {
    getTenantUserAvailable(username: $username, email: $email)
  }
`;
