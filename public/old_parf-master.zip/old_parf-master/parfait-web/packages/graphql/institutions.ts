import { S3Object } from './general';

export const getInstitutionsSearch = /* GraphQL */ `
  query GetInstitutionsSearch($name: String!, $limit: Int!) {
    getInstitutionsSearch(name: $name, limit: $limit) {
      items {
        ... on College {
          id
          name
          reservedAccount
        }
      }
    }
  }
`;

const institutionImage = /* GraphQL */ `
  fragment InstitutionImage on InstitutionImage {
    id
    institutionId
    image {
      ...S3Object
    }
    imageAltText
    message
    order
    alignment
    published
    createdAt
    updatedAt
  }
  ${S3Object}
`;

export const getInstitutionImages = /* GraphQL */ `
  query GetInstitutionImages($institutionId: ID!, $limit: Int, $nextToken: String) {
    institutionImages: getInstitutionImages(institutionId: $institutionId, limit: $limit, nextToken: $nextToken) {
      nextToken
      items {
        ...InstitutionImage
      }
    }
  }
  ${institutionImage}
`;

export const getInstitution = `query GetInstitution($id: ID!) {
  getInstitution(id: $id) {
    id
    name
    tenantId
  }
}
`;

export const createInstitutionImage = /* GraphQL */ `
  mutation CreateInstitutionImage($input: CreateInstitutionImageInput!) {
    createInstitutionImageResult: createInstitutionImage(input: $input) {
      ...InstitutionImage
    }
  }
  ${institutionImage}
`;

export const updateInstitutionImage = /* GraphQL */ `
  mutation UpdateInstitutionImage($input: UpdateInstitutionImageInput!) {
    updateInstitutionImage: updateInstitutionImage(input: $input) {
      ...InstitutionImage
    }
  }
  ${institutionImage}
`;

export const deleteInstitutionImage = /* GraphQL */ `
  mutation DeleteInstitutionImage($input: DeleteInstitutionImageInput!) {
    deleteInstitutionImage: deleteInstitutionImage(input: $input) {
      ...InstitutionImage
    }
  }
  ${institutionImage}
`;

export const updateCollege = /* GraphQL */ `
  mutation UpdateCollege($input: UpdateCollegeInput!) {
    updateCollege: updateCollege(input: $input) {
      id
      primaryImage {
        ...S3Object
      }
      ... on College {
        primaryImageAltText
      }
    }
  }
  ${S3Object}
`;

export const getCollege = /* GraphQL */ `
  query GetInstitution($id: ID!) {
    institutionPrimaryImage: getInstitution(id: $id) {
      id
      primaryImage {
        ...S3Object
      }
      ... on College {
        primaryImageAltText
      }
    }
  }
  ${S3Object}
`;

export const fetchCollegeInfo = /* GraphQL */ `
  query getInstitution($id: ID!) {
    collegeInfo: getInstitution(id: $id) {
      ... on College {
        id
        name
        info {
          ... on CollegeInfoCost {
            category
            tuition
            tuitionOutOfState
            averageNetPrice
            averageScholarship
            percentScholarship
            roomAndBoard
          }
          ... on CollegeInfoCrime {
            category
            incidents
            yearReported
            majorCrimeArrest
            spotCrimeURL
            violenceAgainstWomen
          }
          ... on CollegeInfoValue {
            category
            averageStartingSalary
            loansAfterGraduation
            category
            salaryAfter10Years
            yearsToBreakEven
            yearlyEstimatedEarnings {
              xLabel
              xValue
              yLabel
              yValue
            }
          }
          ... on CollegeInfoGeneral {
            category
            control
            cityState
            classification
            undergraduateEnrollment
            sizeClassification
            residentialClassification
            religiousAffiliation
            percentWomen
            percentMen
            minorityServing
            locale
            gender
            established
          }
          ... on CollegeInfoAcceptanceRate {
            category
            generalRate
          }
          ... on CollegeInfoLocation {
            category
            campusLocationSetting
            population
          }
        }
      }
    }
  }
`;

export const fetchCollegeFormInfo = /* GraphQL */ `
  query getInstitution($id: ID!) {
    collegeInfo: getInstitution(id: $id) {
      ... on College {
        name
        schoolURL
        primaryIcon {
          accessLevel
          bucket
          key
          region
        }
        address {
          address1
          address2
          alphaTwoCode
          city
          country
          postalCode
          stateProvince
        }
      }
    }
  }
`;

export const updateCollegeFormInfo = /* GraphQL */ `
  mutation UpdateCollege($input: UpdateCollegeInput!) {
    collegeInfo: updateCollege(input: $input) {
      ... on College {
        name
        schoolURL
        primaryIcon {
          accessLevel
          bucket
          key
          region
        }
        address {
          address1
          address2
          alphaTwoCode
          city
          country
          postalCode
          stateProvince
        }
      }
    }
  }
`;

export const getStudents = /* GraphQL */ `
  query getStudents($filter: StudentsFilterInput, $sortDirection: ModelSortDirection, $limit: Int, $nextToken: String) {
    students: getStudents(filter: $filter, sortDirection: $sortDirection, limit: $limit, nextToken: $nextToken) {
      items {
        type: __typename
        id
        createdAt
        updatedAt
        graduationYear
        startDate
        endDate
        ... on StudentPending {
          id
          phoneNumber
          givenName
          familyName
          emailAddress
          lastInvite
        }
        ... on StudentActive {
          userId
          access
          phoneNumber
          emailAddress
          graduationYear
          familyName
          givenName
          stats: userInstitutionStats {
            bookmarks
            favorites
            shortLists
            scans
          }
        }
      }
      nextToken
    }
  }
`;

export const reinviteStudentPendingQuery = /* GraphQL */ `
  mutation reinviteStudentPending($input: ReinviteStudentPendingInput!) {
    reinviteStudentPending(input: $input) {
      id
    }
  }
`;

export const updateStudentActive = /* GraphQL */ `
  mutation updateStudentActive($input: UpdateStudentActiveInput!) {
    updateStudentActive(input: $input) {
      id
    }
  }
`;

export const updateStudentPending = /* GraphQL */ `
  mutation updateStudentPending($input: UpdateStudentPendingInput!) {
    updateStudentPending(input: $input) {
      id
    }
  }
`;

export const createStudentPending = `
  mutation createStudentPending($input: CreateStudentPendingInput!){
    createStudentPending(input: $input){
      id
    }
  }
`;

export const getSearchInstitutions = /* GraphQL */ `
  query GetSearchInstitutions($filter: InstitutionSearchFilterInput!, $limit: Int) {
    getSearchInstitutions(filter: $filter, limit: $limit) {
      items {
        type: __typename
        ... on College {
          id
          name
          reservedAccount
        }
        ... on HighSchool {
          id
          name
        }
      }
    }
  }
`;
