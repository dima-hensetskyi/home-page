import { S3Object } from './general';

export const chatMsg = /* GraphQL */ `
  fragment ChatMessage on ChatMessage {
    id
    type
    chatId
    tenantId
    tenantUserId
    status
    content
    contentType
    createdAt
    updatedAt
    user {
      id
      name
      familyName
      givenName
      displayName
      avatar {
        ...S3Object
      }
    }
    tenantUser {
      id
      displayName
      name
      avatar {
        ...S3Object
      }
    }
  }
  ${S3Object}
`;

export const messageSubscription = `
subscription OnMessageChanged($chatId: ID!) {
  changedMessage:onAddOrUpdatedChatMessage(chatId: $chatId) {
    ...ChatMessage
  }
}
${chatMsg}
`;
