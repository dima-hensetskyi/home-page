export const getInstitutionWithEmailAddress = /* GraphQL */ `
  query GetInstitutionWithEmailAddress($emailAddress: String!) {
    getInstitutionWithEmailAddress(emailAddress: $emailAddress) {
      id
      name
      ... on College {
        reservedAccount
      }
    }
  }
`;

export const getUserAvatar = /* GraphQL */ `
  query GetUser($id: ID!) {
    getUser(id: $id) {
      id
      name
      avatar {
        bucket
        region
        key
      }
    }
  }
`;

export const getUserName = /* GraphQL */ `
  query GetUser($id: ID!) {
    getUser(id: $id) {
      id
      name
      familyName
      givenName
      displayName
    }
  }
`;

export const getUser = /* GraphQL */ `
  query GetUser($id: ID!) {
    getUser(id: $id) {
      id
      sub
      name
      familyName
      givenName
      displayName
      pronoun
      phoneNumber
      email
      qrCode
      headline
      id
      sub
      name
      familyName
      givenName
      displayName
      pronoun
      phoneNumber
      email
      avatar {
        bucket
        region
        key
      }
      qrCode
      headline
      userInstitutions {
        id
      }
      userInstitutionAlmaMaters {
        id
        institutionId
        institution {
          id
          name
          tenantId
          address {
            city
            address1
            stateProvince
          }
        }
        status
        name
        startDate
        endDate
        createdAt
        updatedAt
      }
    }
  }
`;

export const GetQuestions = /* GraphQL */ `
  query GetQuestions {
    questions: getQuestions {
      items {
        category
        id
        name
        question
        type
      }
    }
  }
`;

export const fetchInterestSchools = /* GraphQL */ `
  query GetUser($id: ID!) {
    user: getUser(id: $id) {
      institutions: userInstitutions {
        id
        institutionId
        status
        name
        createdAt
      }
    }
  }
`;
