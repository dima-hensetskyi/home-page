import { TenantUser } from './tenants';

export const Fair = `  
    fragment Fair on Fair {
        id
        tenant {
          id
        }
        tenantId
        institutionId
        institution {
          id
        }
        name
        status
        startDateAndTime
        endDateAndTime
        description
        locationName
        organizer {
          id
          givenName
          displayName
          email
          name
        }
        address {
          address1
          address2
          city
          stateProvince
          country
          postalCode
          alphaTwoCode
        }

        emailInviteMessage
        createdAt
        updatedAt

        ... on Fair {
          inviteType
          note
          organizerTenantUserId
          expectedAttendees
          fee
        }
    }
`;

export const EventRegistrationAssignment = `  
    fragment EventRegistrationAssignment on EventRegistrationAssignment {
      eventRegistrationId
      tenantUserId
      tenantUser {
        ...TenantUser
      }
      createdAt
    }
    ${TenantUser}
`;

export const editFair = /* GraphQL */ `
  mutation UpdateFair($input: UpdateFairInput!) {
    event: updateFair(input: $input) {
      ...Fair
    }
  }
  ${Fair}
`;

export const createFair = /* GraphQL */ `
  mutation CreateFair($input: CreateFairInput!) {
    event: createFair(input: $input) {
      ...Fair
    }
  }
  ${Fair}
`;

export const getEvents = /* GraphQL */ `
  query getEvents($limit: Int, $nextToken: String) {
    events: getEvents(limit: $limit, nextToken: $nextToken) {
      items {
        ...Fair
      }
      nextToken
    }
  }
  ${Fair}
`;

export const getEvent = /* GraphQL */ `
  query getEvent($id: ID!) {
    event: getEvent(id: $id) {
      ...Fair
    }
  }
  ${Fair}
`;

export const getEventRegistrationsByTenant = /* GraphQL */ `
  query getEventRegistrationsByTenant(
    $limit: Int
    $nextToken: String
    $filter: EventRegistrationsByTenantFilterInput
    $sortDirection: ModelSortDirection
  ) {
    events: getEventRegistrationsByTenant(
      limit: $limit
      nextToken: $nextToken
      sortDirection: $sortDirection
      filter: $filter
    ) {
      items {
        id
        eventInviteId
        status
        createdAt
        event {
          ...Fair
        }
        eventRegistrationAssignments(sortDirection: ASC) {
          items {
            ...EventRegistrationAssignment
          }
        }
      }
      nextToken
    }
  }
  ${Fair}
  ${EventRegistrationAssignment}
`;

export const getEventRegistrationAssignments = /* GraphQL */ `
  query getEventRegistrationAssignments(
    $eventRegistrationId: ID!
    $sortDirection: ModelSortDirection
    $nextToken: String
  ) {
    getEventRegistrationAssignments(
      eventRegistrationId: $eventRegistrationId
      sortDirection: $sortDirection
      nextToken: $nextToken
    ) {
      items {
        ...EventRegistrationAssignment
      }
      nextToken
    }
  }
  ${EventRegistrationAssignment}
`;

export const createEventRegistrationByForm = `
    mutation CreateEventRegistrationByForm($input: CreateEventRegistrationByFormInput!){
        createEventRegistrationByForm(input: $input){
            id
        }
    }
`;


export const updateEventInviteByEmail = `
    mutation updateEventInviteByEmail($input: UpdateEventInviteByEmailInput!){
        updateEventInviteByEmail(input: $input){
            id
        }
    }
`;

export const getEventInvites = /* GraphQL */ `
  query getEventInvites($eventId: ID!, $sortDirection: ModelSortDirection, $limit: Int, $nextToken: String) {
    invites: getEventInvites(eventId: $eventId, sortDirection: $sortDirection, limit: $limit, nextToken: $nextToken) {
      items {
        id
        eventId
        status
        createdAt
        updatedAt
        ... on EventInviteByEmail {
          email
        }
        registration {
          id
          ... on EventRegistrationByForm {
            registeredInstitutionName
            registeredName
            status
          }
        }
      }
      nextToken
    }
  }
`;

export const updateEventRegistrationByForm = `
    mutation UpdateEventRegistrationByForm($input: UpdateEventRegistrationByFormInput!){
        updateEventRegistrationByForm(input: $input){
            id
        }
    }
`;

export const getEventInvite = `
  query GetEventInvite($id: ID!, $eventId: ID!) {
    getEventInvite(id: $id, eventId: $eventId) {
      id
      ... on EventInviteByEmail {
        eventInviteByEmail: id
        email
        registration {
          status
          id
        }
      }
    }
  }
`;

export const createEventRegistrationAssignment = `
    mutation createEventRegistrationAssignment($input: CreateEventRegistrationAssignmentInput!){
      createEventRegistrationAssignment(input: $input){
           ...EventRegistrationAssignment
        }
    }
    ${EventRegistrationAssignment}
`;

export const deleteEventRegistrationAssignment = `
    mutation deleteEventRegistrationAssignment($input: DeleteEventRegistrationAssignmentInput!){
      deleteEventRegistrationAssignment(input: $input)
    }
`;
