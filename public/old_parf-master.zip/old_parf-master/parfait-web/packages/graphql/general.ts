export const S3Object = `  
fragment S3Object on S3Object {
    bucket
    region
    key
    accessLevel
    identityId
}`;

export const validateAWSPhone = /* GraphQL */ `
  mutation validateAWSPhone($phone: AWSPhone!) {
    validateAWSPhone(phone: $phone)
  }
`;
