export const Invite = /* GraphQL */ `
  fragment Invite on Invite {
    id
    institutionId
    type
    status
    emailAddress
    message
    lastInvite
    inviteInstitutionId
    inviteTenantId
    createdAt
    updatedAt
  }
`;

export const getInvites = /* GraphQL */ `
  query getInvites($limit: Int, $nextToken: String, $sortDirection: ModelSortDirection) {
    getInvites(limit: $limit, nextToken: $nextToken, sortDirection: $sortDirection) {
      items {
        ...Invite
      }
      nextToken
    }
  }
  ${Invite}
`;

export const getInviteWithCode = /* GraphQL */ `
  query getInviteWithCode($inviteCode: String!) {
    getInviteWithCode(inviteCode: $inviteCode) {
      ...Invite
    }
  }
  ${Invite}
`;

export const createInvites = /* GraphQL */ `
  mutation createInvites($input: CreateInvitesInput!) {
    createInvites(input: $input)
  }
`;

export const resendInvite = /* GraphQL */ `
  mutation resendInvite($input: ResendInviteInput!) {
    resendInvite(input: $input) {
      ...Invite
    }
  }
  ${Invite}
`;

export const updateInvite = /* GraphQL */ `
  mutation updateInvite($input: UpdateInviteInput!) {
    updateInvite(input: $input) {
      ...Invite
    }
  }
  ${Invite}
`;
