import { chatMsg } from './chatMessage';

const messageLimit = 15;

export const chatMsgConnection = /* GraphQL */ `
  fragment ChatMessageConnection on ChatMessageConnection {
    nextToken
    items {
      ...ChatMessage
    }
  }
  ${chatMsg}
`;

export const chat = /* GraphQL */ `
  fragment Chat on Chat {
    id
    tenant {
      id
      name
    }
    institution {
      id
    }
    user {
      id
      name
      avatar {
        bucket
        region
        key
      }
    }
    chatMessagesContainer: chatMessages(limit: ${messageLimit}) {
      ...ChatMessageConnection
    }
    unreadMessageCount
    createdAt
    updatedAt
  }
  ${chatMsgConnection}
`;

export const getChats = /* GraphQL */ `
  query GetChats($limit: Int, $nextToken: String) {
    chatConnection: getChats(limit: $limit, nextToken: $nextToken) {
      items {
        ...Chat
      }
      nextToken
    }
  }
  ${chat}
`;

export const getChat = /* GraphQL */ `
  query GetChat($id: ID!) {
    chat: getChat(id: $id) {
      ...Chat
    }
  }
  ${chat}
`;

export const sendChatMsgMutation = /* GraphQL */ `
  mutation SendChatMessage($input: CreateChatMessageInput!) {
    sendChatMessageResult: createChatMessage(input: $input) {
      ...ChatMessage
    }
  }
  ${chatMsg}
`;

export const getChatMsgs = /* GraphQL */ `
query GetChatMessages($chatId: ID!, $nextToken: String!) {
  nextChatMessages: getChatMessages(chatId: $chatId, limit: ${messageLimit}, nextToken: $nextToken) {
    ...ChatMessageConnection
  }
}
${chatMsgConnection}
`;

export const getChatForUser = /* GraphQL */ `
  query getChatForUser($userId: ID!) {
    getChatForUser(userId: $userId) {
      id
    }
  }
`;

export const updateChatMessage = /* GraphQL */ `
  mutation UpdateChatMessage($input: UpdateChatMessageInput!) {
    updateChatMessage(input: $input) {
      id
    }
  }
`;
