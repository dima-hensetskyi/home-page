import { Fair } from './events';
import { TenantUser } from './tenants';

export const Recruit = /* GraphQL */ `
  fragment Recruit on Recruit {
    id
    status
    recruitCohortId
    assignedTenantUser {
      ...TenantUser
    }
    user {
      id
      name
      familyName
      displayName
      givenName
      email
      userQuestions {
        question {
          id
          name
        }
        answers
      }
      avatar {
        bucket
        region
        key
        accessLevel
        identityId
      }
      userInstitutions {
        id
        status
        name
      }
    }
    institution {
      name
      address {
        city
        stateProvince
      }
    }
    recruitCohort {
      name
      classYear
      status
    }
    institutionId
  }
  ${TenantUser}
`;

export const RecruitCohort = /* GraphQL */ `
  fragment RecruitCohort on RecruitCohort {
    id
    name
    classYear
    status
  }
`;

export const GetRecruits = /* GraphQL */ `
  query getRecruits($limit: Int, $nextToken: String, $filter: RecruitsFilterInput) {
    getRecruits(limit: $limit, nextToken: $nextToken, filter: $filter) {
      items {
        ...Recruit
      }
      nextToken
    }
  }
  ${Recruit}
`;

export const GetRecruit = /* GraphQL */ `
  query getRecruit($id: ID!) {
    getRecruit(id: $id) {
      id
      status
    }
  }
`;

export const GetRecruitCohort = /* GraphQL */ `
  query getRecruitCohort($id: ID!) {
    getRecruitCohort(id: $id) {
      ...RecruitCohort
    }
  }
  ${RecruitCohort}
`;

export const GetRecruitsCohorts = /* GraphQL */ `
  query getRecruitCohorts($limit: Int, $nextToken: String) {
    getRecruitCohorts(limit: $limit, nextToken: $nextToken) {
      items {
        ...RecruitCohort
      }
      nextToken
    }
  }
  ${RecruitCohort}
`;

export const GetRecruitsListAndCohorts = /* GraphQL */ `
  query GetRecruitsListAndCohorts(
    $limit: Int
    $nextToken: String
    $cohortsLimit: Int
    $cohortsNextToken: String
    $filter: RecruitsFilterInput
  ) {
    getRecruits(limit: $limit, nextToken: $nextToken, filter: $filter) {
      items {
        ...Recruit
      }
      nextToken
    }
    getRecruitCohorts(limit: $cohortsLimit, nextToken: $cohortsNextToken) {
      items {
        ...RecruitCohort
      }
    }
  }
  ${Recruit}
  ${RecruitCohort}
`;

export const getInstitutionsSearch = /* GraphQL */ `
  query getInstitutionsSearch($limit: Int, $name: String!) {
    getInstitutionsSearch(name: $name, limit: $limit) {
      items {
        name
      }
    }
  }
`;

// # recruit mutations

export const UpdateRecruit = /* GraphQL */ `
  mutation updateRecruit($input: UpdateRecruitInput!) {
    updateRecruit(input: $input) {
      ...Recruit
    }
  }
  ${Recruit}
`;

export const UpdateRecruitCohort = /* GraphQL */ `
  mutation updateRecruitCohort($input: UpdateRecruitCohortInput!) {
    updateRecruitCohort(input: $input) {
      id
      status
      id
    }
  }
`;

//Activities&Notes

export const RecruitActivity = /* GraphQL */ `
  fragment RecruitActivity on RecruitActivity {
    __typename
    id
    recruitId
    userId
    createdAt
    updatedAt
    tenantUser {
      ...TenantUser
    }
    ... on RecruitNote {
      note
    }
    ... on RecruitFair {
      connectType
      note
      event {
        name
      }
      recruit {
        user {
          givenName
        }
      }
    }
    ... on RecruitStatusChange {
      previousStatus
      status
    }
  }
  ${TenantUser}
`;

export const getRecruitActivities = /* GraphQL */ `
  query getRecruitActivities($recruitId: ID!, $limit: Int, $nextToken: String) {
    getRecruitActivities(recruitId: $recruitId, limit: $limit, nextToken: $nextToken) {
      items {
        ...RecruitActivity
      }
      nextToken
    }
  }
  ${RecruitActivity}
`;

export const createRecruitNote = /* GraphQL */ `
  mutation createRecruitNote($input: CreateRecruitNoteInput!) {
    createRecruitNote(input: $input) {
      ...RecruitActivity
    }
  }
  ${RecruitActivity}
`;

export const updateRecruitNote = /* GraphQL */ `
  mutation updateRecruitNote($input: UpdateRecruitNoteInput!) {
    updateRecruitNote(input: $input) {
      ...RecruitActivity
    }
  }
  ${RecruitActivity}
`;

export const deleteRecruitActivity = /* GraphQL */ `
  mutation deleteRecruitActivity($id: ID!) {
    deleteRecruitActivity(id: $id)
  }
`;

export const getRecruitFairScansForUser = /* GraphQL */ `
  query getRecruitFairScansForUser($userId: ID!, $sortDirection: ModelSortDirection, $limit: Int, $nextToken: String) {
    scans: getRecruitFairScansForUser(
      userId: $userId
      sortDirection: $sortDirection
      limit: $limit
      nextToken: $nextToken
    ) {
      nextToken
      items {
        id
        createdAt
        recruit {
          tenant {
            name
          }
        }
      }
    }
  }
`;
