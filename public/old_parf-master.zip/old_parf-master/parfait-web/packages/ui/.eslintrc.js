module.exports = {
  ...require('config/eslint-preset'),
  ignorePatterns: ['dist'],
  rules: {
    // 'no-debugger': 'off',
    'react/display-name': 'off',
    '@typescript-eslint/no-non-null-assertion': 'off',
    '@typescript-eslint/ban-ts-comment': 'off',
    '@typescript-eslint/no-explicit-any': 'off',
    'react/react-in-jsx-scope': 'off',
  },
};
