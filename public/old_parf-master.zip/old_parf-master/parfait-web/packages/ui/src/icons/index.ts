import AppIcon from './app.svg';
import CalendarIcon from './calendar.svg';
import DeleteIcon from './delete.svg';
import EmailIcon from './email.svg';
import FilterIcon from './filter.svg';
import LogoIcon from './logo.svg';
import LogoShort from './logoShort.svg';
import MessagesIcon from './messages.svg';
import PeopleIcon from './people.svg';
import StudentsIcon from './students.svg';
import CollegeFairsIcon from './college-fairs.svg';
import EnterIcon from './enter.svg';

export {
  LogoIcon,
  AppIcon,
  EmailIcon,
  CalendarIcon,
  MessagesIcon,
  PeopleIcon,
  LogoShort,
  FilterIcon,
  DeleteIcon,
  StudentsIcon,
  CollegeFairsIcon,
  EnterIcon,
};
