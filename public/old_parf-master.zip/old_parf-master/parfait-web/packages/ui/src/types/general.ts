import { CognitoUser } from 'amazon-cognito-identity-js';

export type User = CognitoUser & {
  pool: {
    userPoolId: number;
    storage: {
      identityPoolId: string;
    };
  };
  attributes: { [key: string]: string };
};

export type S3Object = {
  bucket: string;
  region: string;
  key: string;
  accessLevel: S3AccessLevel;
  identityId: string;
};

export type S3AccessLevel = 'PUBLIC' | 'PROTECTED' | 'PRIVATE';

export type TextAlignment = 'LEFT' | 'CENTER' | 'RIGHT';
export type AWSDateTime = string;

export type AppType = 'highSchool' | 'university';

export type ModelSortDirection = 'ASC' | 'DESC';

export type Address = {
  address1: string;
  address2: string;
  address3: string;
  city: string;
  stateProvince: string;
  country: string;
  postalCode: string;
  alphaTwoCode: string;
};
