import { ModelSortDirection } from './general';

export type GetInvitesVarsType = {
  limit?: number;
  nextToken?: string;
  sortDirection?: ModelSortDirection;
};

export type GetInvitesResponseType = {
  getInvites: {
    items: Invite[];
    nextToken: string;
  };
};

export type InviteType = 'HIGH_SCHOOL' | 'COLLEGE';
export type InviteStatus = 'PENDING' | 'ACCEPTED';

export type Invite = {
  id: string;
  institutionId: string;
  type: InviteType;
  status: InviteStatus;
  emailAddress: string;
  message: string;
  lastInvite: string;
  inviteInstitutionId: string;
  inviteTenantId: string;
  createdAt: string;
  updatedAt: string;
};

export type CreateInvitesInputType = {
  input: {
    emailAddresses: string[];
    message: string;
    type: InviteType;
  };
};

export type ResendInviteInputType = {
  input: {
    message: string;
    id: string;
  };
};

export type CreateInvitesResponseType = {
  createInvites: boolean;
};

export type ResendInviteResponseType = {
  resendInvite: Invite;
};

export type GetInvitesWithCodeVarsType = {
  inviteCode: string;
};

export type GetInviteWithCodeResponseType = {
  getInviteWithCode: Invite;
};

export type UpdateInvitationVarsType = {
  input: {
    id: string;
    status: InviteStatus;
  };
};

export type UpdateInvitationResponseType = {
  updateInvite: Invite;
};
