export type Tenant = {
  account: string;
  createdAt: string;
  id: string;
  institution: {
    name: string;
  };
  institutionId: string;
  name: string;
  status: string;
  tier: string;
  updatedAt: string;
};

export type GetAuthenticatedTenant = {
  data: {
    tenant: Tenant;
  };
};

import { S3Object } from './general';

export type UpdateUserInputType = {
  input: {
    id: string;
    status?: string;
    email?: string;
    phoneNumber?: string;
    role?: string;
    givenName?: string;
  };
};
export type ReinviteTenantUserInputType = {
  input: {
    id: string;
  };
};

export type CreateUserInputType = {
  input: {
    email: string;
    phoneNumber?: string;
    role: string;
    givenName: string;
    familyName: string;
  };
};

export interface UpdateTenantUserPreferencesInput {
  input: {
    id: string;
    subscribeNews: boolean;
    eventNotification: boolean;
    newChatMessage: boolean;
    onlyChatMessageThread: boolean;
  };
}
export type UpdateTenantUserPreferencesInputResponseType = {
  updateTenantUserPreferences: TenantUser;
};

export interface TenantUserPreferences {
  subscribeNews: boolean;
  eventNotification: boolean;
  newChatMessage: boolean;
  onlyChatMessageThread: boolean;
}

export type TenantUser = {
  familyName: string;
  givenName: string;
  id: string;
  name: string;
  username: string;
  email: string;
  phoneNumber: string;
  avatar: S3Object;
  preferences: TenantUserPreferences;
};

export type AuthenticatedTenantUserResponse = {
  getAuthenticatedTenantUser: TenantUser;
};

export type GetTenantUserAvailableInput = {
  username: string;
  email: string;
};
export type GetTenantUsers = {
  data: {
    tenant: Tenant;
  };
};

export type GetTenantUsersResponse = {
  data: {
    getTenantUsers: {
      items: Array<Tenant>;
    };
  };
};
