import { Address, ModelSortDirection } from './general';
import { TenantUser } from './tenant';

export type Fair = {
  id: string;
  name: string;
  address: null | Address;

  startDateAndTime: string;
  endDateAndTime: string;

  expectedAttendees: number | null;
  fee: number | null;
  emailInviteMessage: null;

  institution: { id: string };
  institutionId: string;
  inviteType: FairInviteType;
  locationName: string;

  organizer: null | {
    username: string;
    id: string;
    givenName: string;
    displayName: string;
    email: string;
    name: string;
  };
  organizerTenantUserId: null;
  status: EventStatus;
  tenant: { id: string };
  tenantId: string;
  description: string;
  note: string;
  updatedAt: string;
  createdAt: string;
};

type EventStatus = 'REGISTRATION_ACTIVE' | 'REGISTRATION_CLOSED' | 'CANCELLED';
type FairInviteType = 'OPEN' | 'INVITE_ONLY';

export type EventRegistrationAssignmentsType = {
  eventRegistrationId: string;
  tenantUserId: string;
  tenantUser: TenantUser;
  createdAt: string;
};

export type EventRegistrationByTenantType = {
  id: string;
  eventInviteId: string;
  status: EventRegistrationStatus;
  createdAt: string;
  event: Fair;
  eventRegistrationAssignments: {
    items: EventRegistrationAssignmentsType[];
  };
};

export type EventRegistrationAssignmentResponse = {
  getEventRegistrationAssignments: {
    items: EventRegistrationAssignmentsType[];
    nextToken: string | null;
  };
};

export type GetEventRegistrationsByTenantResponseType = {
  events: {
    items: EventRegistrationByTenantType[];
    nextToken: string | null;
  };
};

export type EventRegistrationsByTenantInputType = {
  sortDirection?: ModelSortDirection;
  limit: number;
  nextToken?: string | null;
  filter?: EventRegistrationsByTenantFilterType;
};

export type EventRegistrationAssignmentInput = {
  sortDirection?: ModelSortDirection;
  limit?: number;
  nextToken?: string | null;
  eventRegistrationId: string;
};

export type EventRegistrationsByTenantFilterType = {
  statuses?: EventRegistrationStatus[];
  searchTerms?: string[];
};

export type EventAssignmentInput = {
  input: {
    eventRegistrationId: string;
    tenantUserId: string;
  };
};

export type CreateEventAssignmentResponse = EventRegistrationAssignmentsType;

export type EventRegistrationStatus = 'CONFIRMED' | 'CANCELLED';
