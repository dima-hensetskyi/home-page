import { AWSDateTime, S3Object, TextAlignment } from './general';
import CollegeInfo from '../components/features/appManagement/AppManagement/AppInformation/CollegeInfo';

export type InstitutionImage = {
  id: string;
  institutionId: string;
  image: S3Object;
  imageAltText?: string;
  message: string;
  order: number;
  alignment: TextAlignment;
  published: boolean;
  createdAt: AWSDateTime;
  updatedAt: AWSDateTime;
};

export type CollegePrimaryImage = {
  id: string;
  primaryImage: S3Object;
  primaryImageAltText: string;
};

export type GetInstitutionImages = {
  data: {
    institutionImages: {
      items: Array<InstitutionImage>;
      nextToken: string | null;
    };
  };
};

export type UpdateInstitutionImageResponse = {
  data: {
    updateInstitutionImage: InstitutionImage;
  };
};

export type CreateInstitutionImageResponse = {
  data: {
    createInstitutionImageResult: InstitutionImage;
  };
};

export type GetInstitutionPrimaryImage = {
  data: {
    institutionPrimaryImage: CollegePrimaryImage;
  };
};

export type UpdateCollegeResponse = {
  data: {
    updateCollege: CollegePrimaryImage;
  };
};

export type CollegeInfo = Array<{
  [key: string]: string | number | null;
}>;

export type CollegeInfoResponse = {
  data: {
    collegeInfo: {
      id: string;
      info: CollegeInfo;
      name: string;
    };
  };
};

export type CollegeFormInfo = {
  name: string;
  address: {
    address1: string | null;
    address2: string | null;
    alphaTwoCode: string;
    city: string;
    country: string;
    postalCode: string;
    stateProvince: string;
  };
  primaryIcon: S3Object;
  schoolURL: string;
};

export type FetchCollegeFormInfoResponse = {
  data: {
    collegeInfo: CollegeFormInfo;
  };
};
