import { Checkbox, FormControlLabel, Typography } from '@mui/material';
import React from 'react';

type PropsType = {
  onChange: (evt: React.ChangeEvent<HTMLInputElement>) => void;
  value: boolean;
  name: string;
  label: string;
};

export const CheckBox: React.FC<PropsType> = ({ label, name, onChange, value }: PropsType) => {
  return (
    <FormControlLabel
      sx={{ alignItems: 'flex-start' }}
      control={<Checkbox size="small" sx={{ p: '0', mx: '9px' }} onChange={onChange} name={name} checked={value} />}
      label={<Typography variant="body2">{label}</Typography>}
    />
  );
};
