import { Box, Button, Stack } from '@mui/material';
import { diff } from 'deep-object-diff';
import { Form, Formik, Field } from 'formik';
import { TextField as FormikTextField } from 'formik-mui';
import { useMutation, useQueryClient } from 'react-query';
import { useSnackbar } from 'notistack';
import InputMask from 'react-input-mask';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useState } from 'react';

import { MediaUpload } from './MediaUpload';
import { TenantUser } from '../../../types/tenant';
import { unmaskPhoneNumber } from '../adminUserManagement/utils';
import { UpdateTenantUser } from '../adminUserManagement/api';
import { userSchema } from './validationScheme';
import { useAvatarUpload } from './hooks';

type PropsType = {
  onClose: () => void;
  authenticatedUser: TenantUser | undefined;
};

export const ProfileSettings: React.FC<PropsType> = ({ onClose, authenticatedUser }: PropsType) => {
  if (!authenticatedUser) return null;
  const { email, familyName, givenName, id, phoneNumber, username, avatar } = authenticatedUser;

  const [newAvatar, setNewAvatar] = useState<File | null>();
  const queryClient = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();

  const initialValues = {
    givenName,
    familyName,
    username,
    email,
    phoneNumber: phoneNumber ? phoneNumber.replace('+1', '') : '',
  };
  const isUpdatedAvatar = newAvatar || newAvatar === null;

  const uploadNewAvatar = useAvatarUpload();
  const updateCurrentUser = useMutation(UpdateTenantUser, {
    onError: () => {
      enqueueSnackbar('Something went wrong!', {
        variant: 'error',
      });
    },
    onSuccess: () => {
      enqueueSnackbar('User successfully updated!', {
        variant: 'success',
      });
      onClose();
    },
    onSettled: () => {
      queryClient.refetchQueries(['GetTenantUsers'], { active: true });
      queryClient.invalidateQueries('AuthenticatedTenantUser');
      newAvatar && queryClient.invalidateQueries(['Avatar', id]);
    },
  });

  const onSubmit = async (values: typeof initialValues) => {
    let requestObj = diff(initialValues, values);

    if ('phoneNumber' in requestObj) {
      requestObj = unmaskPhoneNumber(requestObj);
    }

    if (newAvatar) {
      const avatar = await uploadNewAvatar.mutateAsync({ id, image: newAvatar });
      if (avatar) requestObj = { ...requestObj, avatar };
    }

    if (newAvatar === null) {
      requestObj = { ...requestObj, avatar: null };
    }

    const newVariables = { input: { id, ...requestObj } };
    await updateCurrentUser.mutateAsync(newVariables);
  };

  const onChangeAvatar = (val: File | null | undefined) => setNewAvatar(() => val);

  return (
    <Formik validationSchema={userSchema} initialValues={initialValues} onSubmit={onSubmit}>
      {({ values, handleBlur, handleChange }) => (
        <Form style={{ width: '100%' }}>
          <MediaUpload image={newAvatar} avatar={avatar} onChangeAvatar={onChangeAvatar} />
          <Stack spacing="16px">
            <Field
              component={FormikTextField}
              fullWidth
              id="givenName"
              label="First Name"
              name="givenName"
              required
              size="small"
              type="text"
            />
            <Field
              component={FormikTextField}
              fullWidth
              id="familyName"
              label="Last Name"
              name="familyName"
              required
              size="small"
              type="text"
            />
            <Field
              component={FormikTextField}
              fullWidth
              disabled={true}
              id="username"
              label="Username"
              name="username"
              required
              size="small"
              type="text"
            />
            <Field
              component={FormikTextField}
              fullWidth
              id="email"
              label="Email"
              name="email"
              placeholder="email@school.edu/org/com"
              required
              size="small"
              type="text"
            />
            <InputMask
              alwaysShowMask={false}
              mask="(999) 999-9999"
              onBlur={handleBlur}
              onChange={handleChange}
              type="tel"
              value={values.phoneNumber}
            >
              {(inputProps: { value: string; onChange: () => void }) => (
                <Field
                  {...inputProps}
                  component={FormikTextField}
                  fullWidth
                  id="phoneNumber"
                  label="Mobile number"
                  name="phoneNumber"
                  size="small"
                  type="text"
                />
              )}
            </InputMask>
            <Box sx={{ display: 'flex', gap: '8px', mt: '24px' }}>
              <LoadingButton
                loading={updateCurrentUser.isLoading || uploadNewAvatar.isLoading}
                size="large"
                disabled={!(isUpdatedAvatar || JSON.stringify(initialValues) !== JSON.stringify(values))}
                variant="contained"
                type="submit"
                sx={{
                  fontSize: '15px',
                  lineHeight: '26px',
                  letterSpacing: '0.46px',
                }}
              >
                Save Changes
              </LoadingButton>
              <Button
                size="large"
                variant="outlined"
                onClick={onClose}
                sx={{
                  fontSize: '15px',
                  lineHeight: '26px',
                  letterSpacing: '0.46px',
                }}
              >
                Cancel
              </Button>
            </Box>
          </Stack>
        </Form>
      )}
    </Formik>
  );
};
