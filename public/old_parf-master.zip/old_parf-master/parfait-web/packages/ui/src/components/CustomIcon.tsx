import React from 'react';
import { DeleteIcon } from '../icons';

export const CustomIcon = () => {
  return (
    <>
      <DeleteIcon />
    </>
  );
};
