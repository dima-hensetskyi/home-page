import { TermsAndConditions } from './TermsAndConditions';
export { TermsAndConditions };
