import { AuthContextType } from './types';
import { useContext } from 'react';
import AuthContext from './AuthContext';

const useAuthContext = (): AuthContextType => {
  return useContext(AuthContext)!;
};

export default useAuthContext;
