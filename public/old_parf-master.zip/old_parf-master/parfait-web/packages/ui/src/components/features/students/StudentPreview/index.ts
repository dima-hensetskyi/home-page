import StudentPreview from './StudentPreview';

export default StudentPreview;
