import { Button } from '@mui/material';
import React, { useState } from 'react';

import { TableTopControlPanel } from '../../Table';
import CollegeFairsList from './CollegeFairsList';
import CreateFair from './CreateFair';

const FairsContainer = () => {
  const [createFairDialogOpen, setCreateFairDialogOpen] = useState(false);

  return (
    <div>
      <TableTopControlPanel title="College fairs">
        <Button
          size="large"
          variant="contained"
          onClick={() => {
            setCreateFairDialogOpen(true);
          }}
        >
          Add college fair
        </Button>
      </TableTopControlPanel>
      <CollegeFairsList />
      <CreateFair
        visible={createFairDialogOpen}
        onClose={() => {
          setCreateFairDialogOpen(false);
        }}
      />
    </div>
  );
};

export default FairsContainer;
