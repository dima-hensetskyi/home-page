import CreateFair from './CreateFair';

export default CreateFair;
