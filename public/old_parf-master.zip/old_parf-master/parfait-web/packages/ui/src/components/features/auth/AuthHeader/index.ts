import AuthHeader from './AuthHeader';

export default AuthHeader;
