import React, { useCallback } from 'react';
import { OverlayScrollbarsComponent } from 'overlayscrollbars-react';
import 'overlayscrollbars/css/OverlayScrollbars.css';

const CustomScrollbar = React.forwardRef((props: React.PropsWithChildren<any>, ref: any) => {
  const { style, children, ...restProps } = props;
  const refSetter = useCallback(
    (scrollbarsRef) => {
      if (scrollbarsRef) {
        const customViewport = scrollbarsRef.osInstance().getElements().viewport;
        for (const key in props) {
          if (!Object.prototype.hasOwnProperty.call(props, key)) {
            continue;
          }
          customViewport.setAttribute(key, restProps[key]);
        }

        ref.current = customViewport;
      }
    },
    [ref],
  );

  return (
    <OverlayScrollbarsComponent ref={refSetter} style={{ ...style }}>
      {children}
    </OverlayScrollbarsComponent>
  );
});

export default CustomScrollbar;
