import { Avatar, Button, Paper, Stack, Typography } from '@mui/material';
import { useQueryClient } from 'react-query';
import { useSnackbar } from 'notistack';
import React, { ChangeEvent } from 'react';

import { S3Object } from '../../../../types/general';

type PropsType = {
  avatar: null | S3Object;
  image: null | File | undefined;
  onChangeAvatar: (val: File | null) => void;
};

export const MediaUpload: React.FC<PropsType> = ({ onChangeAvatar, avatar, image }: PropsType) => {
  const queryClient = useQueryClient();
  const avatarSrc = queryClient.getQueryData<string>(['Avatar', avatar?.key]);
  const { enqueueSnackbar } = useSnackbar();

  const handleNewImage = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 800000) {
        enqueueSnackbar('File is too big!', { variant: 'error' });
      } else {
        onChangeAvatar(file);
      }
    }
  };

  const onRemoveAvatar = () => {
    onChangeAvatar(null);
  };

  return (
    <Paper
      variant="outlined"
      sx={{
        borderRadius: '4px',
        background: 'rgba(0, 0, 0, 0.04)',
        p: '24px',
        gap: '24px',
        mb: '24px',
        display: 'flex',
        minHeight: '184px',
        position: 'relative',
      }}
    >
      {/* {avatarUpload.isLoading ? (
        <Loader />
      ) : ( */}
      <>
        <Avatar
          src={image ? URL.createObjectURL(image) : image === null ? undefined : avatarSrc}
          sx={{ width: '128px', height: '128px', alignSelf: 'center' }}
        ></Avatar>
        <Stack>
          {(!image && image !== null && avatar?.key) || image ? (
            <>
              <Button sx={{ mb: '16px' }} variant="contained" size="medium" component="label">
                Upload new picture
                <input
                  type="file"
                  id="photoUpload"
                  accept="image/png,image/jpeg,image/jpg"
                  onChange={(evt) => {
                    handleNewImage(evt);
                  }}
                  hidden
                />
              </Button>
              <Button sx={{ width: 'fit-content' }} variant="outlined" size="medium" onClick={onRemoveAvatar}>
                Delete
              </Button>
            </>
          ) : (
            <>
              <Button variant="outlined" size="medium" component="label">
                Choose a photo
                <input
                  type="file"
                  id="photoUpload"
                  accept="image/png,image/jpeg,image/jpg"
                  onChange={handleNewImage}
                  hidden
                  style={{ display: 'none !important' }}
                />
              </Button>
              <Typography sx={{ mt: '4px' }} variant="body2">
                {'File not selected'}
              </Typography>
              <Typography variant="caption" sx={{ color: 'rgba(0, 0, 0, 0.6)', mb: '16px' }}>
                Png or Jpeg, max 800kb
              </Typography>
              {/* <Button
                onClick={() => {
                  if (image) {
                    setIsImageUpload(true);
                  }
                }}
                disabled={!image}
                variant="contained"
                size="medium"
                sx={{ width: 'fit-content' }}
              >
                Upload now
              </Button> */}
            </>
          )}
        </Stack>
      </>
    </Paper>
  );
};
