const RolesInformation = [
  {
    title: 'Staff Role:',
    items: ['Manage recruits', 'Manage chats', 'Parfait Invites'],
  },
  {
    title: 'Admin Role - Includes Staff access AND:',
    items: ['App Management', 'User Management', 'Parfait Billing'],
  },
];

export { RolesInformation };
