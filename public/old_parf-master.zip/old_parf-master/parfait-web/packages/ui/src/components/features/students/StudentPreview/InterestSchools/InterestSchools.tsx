import React, { useState, useMemo } from 'react';
import { useQuery } from 'react-query';
import styled from 'styled-components';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import TableBody from '@mui/material/TableBody';
import { Box, Typography, Stack, TableSortLabel } from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import dayjs from 'dayjs';
import { API } from 'aws-amplify';
import { NoData } from '../../../../NoData';
import SchoolsStatus from './SchoolsStatus';
import { fetchInterestSchools } from 'graphql/users';

type Props = {
  userId: string;
};

type Institution = {
  id: string;
  institutionId: string;
  status: string;
  name: string;
  createdAt: string;
};

type InstitutionResponse = {
  data: {
    user: {
      institutions: Array<Institution>;
    };
  };
};

const Wrapper = styled.div`
  tr:nth-of-type(even) td {
    background-color: #f5f5f5;
  }
`;

const InterestSchools = (props: Props) => {
  const { userId } = props;

  const [sortDirectionInterest, setSortDirectionInterest] = useState<'asc' | 'desc'>('asc');
  const [sortDirectionDate, setSortDirectionDate] = useState<'asc' | 'desc'>('asc');
  const [activeSort, setActiveSort] = useState<'interest' | 'date' | null>(null);

  const { data } = useQuery(['InterestSchools', userId], async () => {
    const result = (await API.graphql({
      query: fetchInterestSchools,
      variables: {
        id: userId,
      },
    })) as InstitutionResponse;

    return result.data.user.institutions.filter((institution) => {
      return institution.status !== 'DECLINED';
    });
  });

  const institutions = useMemo(() => {
    if (data && activeSort === 'interest') {
      return data.sort((a, b) => {
        if (sortDirectionInterest === 'asc') {
          return b.status.localeCompare(a.status);
        }
        return a.status.localeCompare(b.status);
      });
    }

    if (data && activeSort === 'date') {
      return data.sort((a, b) => {
        if (sortDirectionDate === 'asc') {
          return dayjs(a.createdAt).unix() - dayjs(b.createdAt).unix();
        }
        return dayjs(b.createdAt).unix() - dayjs(a.createdAt).unix();
      });
    }
    return data;
  }, [data, sortDirectionInterest, sortDirectionDate, activeSort]);

  return (
    <Stack spacing={1.5}>
      <Typography variant="h6" gutterBottom component="div">
        Interest Schools
      </Typography>
      {!institutions ? (
        <Box sx={{ display: 'flex', justifyContent: 'center' }}>
          <CircularProgress size="20px" />
        </Box>
      ) : (
        <Wrapper>
          <TableContainer sx={{ maxHeight: '230px', mb: 2.5 }}>
            <Table
              stickyHeader
              aria-label="sticky table"
              sx={{
                border: '1px solid #e0e0e0',
              }}
            >
              <TableHead>
                <TableRow>
                  <TableCell
                    align="left"
                    width="40%"
                    sx={{
                      background: '#e0e0e0',
                      paddingTop: 0.5,
                      paddingBottom: 0.5,
                    }}
                  >
                    School
                  </TableCell>
                  <TableCell
                    align="left"
                    width="30%"
                    sx={{
                      background: '#e0e0e0',
                      paddingTop: 0.5,
                      paddingBottom: 0.5,
                    }}
                  >
                    <TableSortLabel
                      active={activeSort === 'interest'}
                      direction={sortDirectionInterest}
                      onClick={() => {
                        if (activeSort !== 'interest') {
                          setActiveSort('interest');
                        }
                        if (sortDirectionInterest === 'asc') {
                          setSortDirectionInterest('desc');
                        } else {
                          setSortDirectionInterest('asc');
                        }
                      }}
                    >
                      Interest
                    </TableSortLabel>
                  </TableCell>
                  <TableCell
                    align="left"
                    width="30%"
                    sx={{
                      background: '#e0e0e0',
                      paddingTop: 0.5,
                      paddingBottom: 0.5,
                    }}
                  >
                    <TableSortLabel
                      active={activeSort === 'date'}
                      direction={sortDirectionDate}
                      onClick={() => {
                        if (activeSort !== 'date') {
                          setActiveSort('date');
                        }
                        if (sortDirectionDate === 'asc') {
                          setSortDirectionDate('desc');
                        } else {
                          setSortDirectionDate('asc');
                        }
                      }}
                    >
                      Date
                    </TableSortLabel>
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {institutions && institutions.length > 0 ? (
                  institutions.map((record) => {
                    return (
                      <TableRow key={record.id}>
                        <TableCell
                          key="school"
                          align="left"
                          sx={{
                            paddingTop: 0.75,
                            paddingBottom: 0.75,
                          }}
                        >
                          {record.name}
                        </TableCell>
                        <TableCell
                          key="interest"
                          align="left"
                          sx={{
                            paddingTop: 0.75,
                            paddingBottom: 0.75,
                          }}
                        >
                          <SchoolsStatus status={record.status} />
                        </TableCell>
                        <TableCell
                          key="date"
                          align="left"
                          sx={{
                            paddingTop: 0.75,
                            paddingBottom: 0.75,
                          }}
                        >
                          {dayjs(record.createdAt).format('DD/MM/YYYY')}
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={4}>
                      <NoData
                        sx={{
                          width: '100%',
                        }}
                      />
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </Wrapper>
      )}
    </Stack>
  );
};

export default InterestSchools;
