import AppManagement from './AppManagement';

export default AppManagement;
