import styled from 'styled-components';

export const Container = styled.button`
  border: none;
  text-align: left;
  padding: 12px 16px;
  display: flex;
  width: 100%;
`;
export const ImageBox = styled.div`
  flex-shrink: 0;
`;
export const Image = styled.div`
  background: #ed6c02;
  width: 40px;
  height: 40px;
  border-radius: 50%;
`;
export const Body = styled.div`
  margin-left: 8px;
  flex-grow: 1;
`;
export const Heading = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 2px;
`;
export const MessageText = styled.div`
  white-space: pre-wrap;
  word-break: break-word;
`;
export const Title = styled.div``;
export const Count = styled.div`
  width: 20px;
  height: 20px;
  background: #1976d2;
  border-radius: 50%;
  color: #fff;
  font-size: 12px;
  line-height: 20px;
  text-align: center;
  margin-left: 4px;
  margin-right: 4px;
  flex-shrink: 0;
`;
export const Time = styled.div`
  margin-left: auto;
`;
