import StudentForm from './StudentForm';

export default StudentForm;
