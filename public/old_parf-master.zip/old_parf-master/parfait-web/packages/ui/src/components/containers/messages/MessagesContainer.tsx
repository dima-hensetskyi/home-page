import React, { useReducer, Reducer, useEffect } from 'react';
import { API, graphqlOperation } from 'aws-amplify';
import { useWindowSize } from 'react-use';
import { getChats } from 'graphql/chat';
import MessagesContext from './MessagesContext';
import { Chat, RenderProps } from './types';

type Props = {
  children: (props: RenderProps) => React.ReactNode;
};

type Action =
  | {
      type: 'SET_ACTIVE_CONTACT';
      payload: string;
    }
  | {
      type: 'SET_CHATS_DATA';
      payload: {
        chats: Array<Chat>;
        token: string | null;
      };
    }
  | {
      type: 'LOAD_CHATS_START';
    }
  | {
      type: 'UPDATE_CHAT_UNREAD_COUNT';
      payload: {
        unreadMessageCount: number;
        chatId: string;
      };
    }
  | {
      type: 'LOAD_CHATS_SUCCESS';
      payload: {
        chats: Array<Chat>;
        token: string | null;
      };
    };

type State = {
  activeContact: string | null;
  nextToken: string | null;
  loaded: boolean;
  nextLoading: boolean;
  chats: Array<Chat>;
};

const limit = 10;
const reservedHeaderHeight = 180;
const minHeight = 300;

const getChatUnreadMessageCount = `
  query GetChatUnreadMessageCount($id: ID!){
    getChat(id: $id){
      unreadMessageCount
    }
  }
`;

const MessagesContainer = (props: Props) => {
  const { children } = props;

  const { height } = useWindowSize();

  const [{ activeContact, loaded, chats, nextToken, nextLoading }, dispatch] = useReducer<Reducer<State, Action>>(
    (state, action) => {
      switch (action.type) {
        case 'SET_CHATS_DATA':
          return {
            ...state,
            loaded: true,
            chats: action.payload.chats,
            nextToken: action.payload.token,
            activeContact: action.payload.chats.length > 0 ? action.payload.chats[0].id : null,
          };
        case 'LOAD_CHATS_START':
          return {
            ...state,
            nextLoading: true,
          };
        case 'UPDATE_CHAT_UNREAD_COUNT':
          return {
            ...state,
            chats: state.chats.map((chat) => {
              if (chat.id === action.payload.chatId) {
                return { ...chat, unreadMessageCount: action.payload.unreadMessageCount };
              }

              return chat;
            }),
          };
        case 'LOAD_CHATS_SUCCESS':
          return {
            ...state,
            nextLoading: false,
            chats: state.chats.concat(action.payload.chats),
            nextToken: action.payload.token,
          };
        case 'SET_ACTIVE_CONTACT':
          return {
            ...state,
            activeContact: action.payload,
          };
      }

      return state;
    },
    {
      loaded: false,
      nextLoading: false,
      chats: [],
      activeContact: null,
      nextToken: null,
    },
  );

  useEffect(() => {
    const fetchChatsList = async () => {
      const result = await API.graphql(
        graphqlOperation(getChats, {
          limit,
        }),
      );

      dispatch({
        type: 'SET_CHATS_DATA',
        payload: {
          // @ts-ignore
          chats: result.data.chatConnection.items,
          // @ts-ignore
          token: result.data.chatConnection.nextToken,
        },
      });
    };

    fetchChatsList();
  }, []);

  const setActiveContact = (id: string): void => {
    dispatch({
      type: 'SET_ACTIVE_CONTACT',
      payload: id,
    });
  };

  const endReached = async () => {
    if (nextToken && !nextLoading) {
      dispatch({
        type: 'LOAD_CHATS_START',
      });

      const result = await API.graphql(
        graphqlOperation(getChats, {
          limit,
          token: nextToken,
        }),
      );

      dispatch({
        type: 'LOAD_CHATS_SUCCESS',
        payload: {
          // @ts-ignore
          chats: result.data.chatConnection.items,
          // @ts-ignore
          token: result.data.chatConnection.nextToken,
        },
      });
    }
  };

  const onMessagesStatusRead = async (chatId: string) => {
    const result = (await API.graphql({
      query: getChatUnreadMessageCount,
      variables: {
        id: chatId,
      },
    })) as {
      data: {
        getChat: {
          unreadMessageCount: number;
        };
      };
    };

    console.log('UPDATE_CHAT_UNREAD_COUNT', chatId, result.data.getChat.unreadMessageCount);
    dispatch({
      type: 'UPDATE_CHAT_UNREAD_COUNT',
      payload: {
        chatId,
        unreadMessageCount: result.data.getChat.unreadMessageCount,
      },
    });
  };

  const activeChat = chats.find((chat) => {
    return chat.id === activeContact;
  });
  const calculatedHeight = height - reservedHeaderHeight;
  const messagesHeight = calculatedHeight < minHeight ? minHeight : calculatedHeight;
  const chatUserId = activeChat ? activeChat.user.id : null;

  return (
    <MessagesContext.Provider
      value={{
        setActiveContact,
        activeContact,
        chats,
        activeChat,
        endReached,
        messagesHeight,
        chatUserId,
      }}
    >
      {children({ activeId: activeContact, loaded, empty: chats.length === 0, messagesHeight, onMessagesStatusRead })}
    </MessagesContext.Provider>
  );
};

export default MessagesContainer;
