import styled from 'styled-components';

export const BoxFrame = styled.div`
  padding: 24px;
  box-shadow: 0 2px 4px -1px rgba(0, 0, 0, 0.2), 0px 4px 5px rgba(0, 0, 0, 0.14), 0px 1px 10px rgba(0, 0, 0, 0.12);
  border-radius: 4px;
  margin-bottom: 20px;
`;

export const Row = styled.div`
  display: flex;
`;

export const CellImage = styled.div`
  width: 220px;
  margin-right: 24px;
`;

export const CellBody = styled.div`
  flex-grow: 1;
  margin-right: 24px;
`;

export const CellControls = styled.div`
  width: 160px;
`;

export const Tips = styled.div`
  margin-left: 14px;
  margin-top: 4px;
`;

export const Header = styled.div`
  display: flex;
  align-items: center;
`;

export const PrimaryImageWrapper = styled.div`
  position: relative;
`;

export const Img = styled.img`
  width: 100%;
`;

export const ImgPicker = styled.div`
  position: absolute;
  right: 0;
  bottom: 0;
`;

export const imageHeight = 293;

export const ImageWrapper = styled.div`
  height: ${imageHeight}px;
  display: flex;
  align-items: center;
  justify-content: center;
`;
