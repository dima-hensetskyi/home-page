import { createContext } from 'react';
import { FairsAttendingContextType } from '../types';

export const FairsAttendingContext = createContext<FairsAttendingContextType | null>(null);
