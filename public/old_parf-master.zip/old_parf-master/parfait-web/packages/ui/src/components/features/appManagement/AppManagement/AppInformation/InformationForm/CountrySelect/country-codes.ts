const isoCountryCodes = [
  { name: 'United States of America', alphaTwoCode: 'US', alphaThreeCode: 'USA', numeric: '840' },
];

export default isoCountryCodes;
