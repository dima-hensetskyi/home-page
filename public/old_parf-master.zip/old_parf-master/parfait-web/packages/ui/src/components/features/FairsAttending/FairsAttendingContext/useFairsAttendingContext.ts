import { useContext } from 'react';
import { FairsAttendingContextType } from '../types';
import { FairsAttendingContext } from './FairsAttendingContext';

export const useFairsAttendingContext = (): FairsAttendingContextType => {
  return useContext(FairsAttendingContext)!;
};
