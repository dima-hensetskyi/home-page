import React, { useState } from 'react';
import { DatePicker as MuiDatePicker } from '@mui/x-date-pickers';
import TextField from '@mui/material/TextField';
import { useFormikContext } from 'formik';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs, { Dayjs } from 'dayjs';
import { FormValues } from '../types';

const DatePicker = () => {
  const { setFieldValue, values, errors, touched } = useFormikContext<FormValues>();
  const [value, setValue] = useState<Dayjs | null>(values.date ? dayjs(values.date, 'YYYY-MM-DD') : null);

  const error = errors.date;
  const hasError = !!error && touched.date;

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <MuiDatePicker
        label="Date"
        minDate={dayjs()}
        value={value}
        onChange={(newValue: Dayjs | null) => {
          if (newValue) {
            setFieldValue('date', newValue.format('YYYY-MM-DD'));
            setValue(newValue);
          }
        }}
        renderInput={(params) => (
          <TextField {...params} size="small" error={hasError} helperText={hasError ? error : null} />
        )}
      />
    </LocalizationProvider>
  );
};

export default DatePicker;
