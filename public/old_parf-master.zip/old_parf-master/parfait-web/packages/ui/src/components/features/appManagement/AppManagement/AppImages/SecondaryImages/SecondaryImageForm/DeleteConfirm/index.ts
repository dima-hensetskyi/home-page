import DeleteConfirm from './DeleteConfirm';

export default DeleteConfirm;
