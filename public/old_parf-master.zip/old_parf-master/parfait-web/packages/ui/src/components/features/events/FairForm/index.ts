import FairForm from './FairForm';

export default FairForm;
