import React from 'react';
import { Formik, Form, Field } from 'formik';
import { TextField as FormikTextField } from 'formik-mui';
import { Typography, Stack } from '@mui/material';
import * as Yup from 'yup';
import { API } from 'aws-amplify';
import { useSnackbar } from 'notistack';
import { useQueryClient } from 'react-query';
import useAuthContext from '../../../../containers/auth/useAuthContext';
import { StudentActive } from '../../types';
import { Row, Label, ValueField } from '../styled-components';
import { updateStudentActive } from 'graphql/institutions';
import { pickBy } from '../utils';

type Props = {
  entity: StudentActive | null;
};

const StudentRequestPreview = (props: Props) => {
  const { entity } = props;
  const { enqueueSnackbar } = useSnackbar();
  const queryClient = useQueryClient();
  const { tenant } = useAuthContext()!;

  const initialValues = {
    givenName: entity?.user.givenName,
    familyName: entity?.user.familyName,
    phoneNumber: entity?.user.phoneNumber,
    emailAddress: entity?.user.email,
  };

  const { institutionId } = tenant!;

  return (
    <Formik
      initialValues={initialValues}
      onSubmit={async (values, { setSubmitting }) => {
        try {
          await API.graphql({
            query: updateStudentActive,
            variables: {
              input: pickBy({ ...values, institutionId, id: entity?.id }),
            },
          });

          setSubmitting(false);
          enqueueSnackbar('Student successfully updated!', {
            variant: 'success',
          });
          queryClient.invalidateQueries('getStudents');
        } catch {
          setSubmitting(false);
          enqueueSnackbar('something went wrong!', {
            variant: 'error',
          });
        }
      }}
      validationSchema={Yup.object().shape({
        givenName: Yup.string().required('First name is required.').nullable(),
        familyName: Yup.string().required('Last name is required.').nullable(),
        emailAddress: Yup.string().notRequired().email('Please enter a valid email address.').nullable(),
      })}
    >
      {({ submitForm }) => {
        return (
          <Form>
            <Stack spacing={1}>
              <Row>
                <Label>
                  <Typography variant="body2" gutterBottom>
                    First Name
                  </Typography>
                </Label>
                <ValueField>
                  <Field
                    fullWidth
                    component={FormikTextField}
                    name="givenName"
                    type="text"
                    size="small"
                    onBlur={submitForm}
                  />
                </ValueField>
              </Row>
              <Row>
                <Label>
                  <Typography variant="body2" gutterBottom>
                    Last Name
                  </Typography>
                </Label>
                <ValueField>
                  <Field
                    fullWidth
                    component={FormikTextField}
                    name="familyName"
                    type="text"
                    size="small"
                    onBlur={submitForm}
                  />
                </ValueField>
              </Row>
              <Row>
                <Label>
                  <Typography variant="body2" gutterBottom>
                    Email
                  </Typography>
                </Label>
                <ValueField>
                  <Field
                    fullWidth
                    component={FormikTextField}
                    name="emailAddress"
                    type="text"
                    size="small"
                    onBlur={submitForm}
                  />
                </ValueField>
              </Row>
              <Row>
                <Label>
                  <Typography variant="body2" gutterBottom>
                    Mobile number
                  </Typography>
                </Label>
                <ValueField>
                  <Field
                    fullWidth
                    component={FormikTextField}
                    name="phoneNumber"
                    type="text"
                    size="small"
                    onBlur={submitForm}
                    disabled={true}
                  />
                </ValueField>
              </Row>
            </Stack>
          </Form>
        );
      }}
    </Formik>
  );
};

export default StudentRequestPreview;
