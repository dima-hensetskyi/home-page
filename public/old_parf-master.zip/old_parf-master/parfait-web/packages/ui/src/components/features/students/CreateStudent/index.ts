import CreateStudent from './CreateStudent';

export default CreateStudent;
