import { GetAuthenticatedTenantUser } from 'graphql/tenants';
import { API, graphqlOperation } from 'aws-amplify';
import { AuthenticatedTenantUserResponse } from '../../types/tenant';
import { GraphQLResult } from '@aws-amplify/api';

export const getFullUserName = (res: AuthenticatedTenantUserResponse | undefined) => {
  if (!res) return;
  const { getAuthenticatedTenantUser } = res;
  const { familyName, givenName } = getAuthenticatedTenantUser;
  return `${givenName} ${familyName}`;
};

export const getAuthenticatedTenantUser = async () => {
  const result = (await API.graphql(
    graphqlOperation(GetAuthenticatedTenantUser),
  )) as GraphQLResult<AuthenticatedTenantUserResponse>;

  return result.data;
};
