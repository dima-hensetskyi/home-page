import React from 'react';
import styled from 'styled-components';
import WarningIcon from '@mui/icons-material/Warning';
import { Typography } from '@mui/material';

const Empty = styled.div`
  padding: 50px 0;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const MessagesEmpty = () => {
  return (
    <Empty>
      <WarningIcon
        sx={{
          color: '#ED6C02',
          mr: 2,
        }}
      />
      <Typography variant="body1">No messages found.</Typography>
    </Empty>
  );
};

export default MessagesEmpty;
