import { API } from 'aws-amplify';
import { Field, Form, Formik } from 'formik';
import { getEvent } from 'graphql/events';
import { TextField as FormikTextField } from 'formik-mui';
import { Typography, Grid, Stack } from '@mui/material';
import { useParams } from 'react-router-dom';
import { useQuery } from 'react-query';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useState } from 'react';

import { createEventRegistrationByForm } from 'graphql/events';
import { FormContainer, Container } from './styled-components';
import { GetEventResponse } from '../types';
import { InstitutionInfo } from '../../auth/RegistrationForm/types';
import EventRegistrationData from './EventRegistrationData';
import FullPageLoader from '../../../FullPageLoader';
import ParfaitInfo from './ParfaitInfo';
import SchoolSelect from '../../auth/RegistrationForm/SchoolSelect';
import validationSchema from './validationSchema';

type FormValues = {
  name: string;
  email: string;
  school: string;
};

const PublicRegistration = () => {
  const params = useParams();
  const id = params.id;

  const [registered, setRegistered] = useState(false);
  const [institution, setInstitution] = useState<InstitutionInfo | null>(null);

  const { data, status } = useQuery(['getEvent', id], async () => {
    const response = (await API.graphql({
      query: getEvent,
      variables: {
        id,
      },
    })) as GetEventResponse;

    return response.data.event;
  });

  const initialValues = {
    name: '',
    email: '',
    school: '',
  };

  const onSubmit = async (values: FormValues) => {
    if (!institution) return undefined;

    await API.graphql({
      query: createEventRegistrationByForm,
      variables: {
        input: {
          eventId: id,
          status: 'CONFIRMED',
          registeredEmail: values.email,
          registeredInstitutionId: institution.institutionId,
          registeredName: values.name,
          registeredInstitutionName: institution.institutionName!,
        },
      },
    });

    setRegistered(true);
  };

  if (status === 'loading') {
    return <FullPageLoader />;
  }

  return (
    <Container>
      {data ? (
        <>
          <Typography
            variant="h4"
            component="div"
            sx={{
              mb: 0.5,
            }}
          >
            {data.name}
          </Typography>
          <Typography
            variant="caption"
            display="block"
            gutterBottom
            sx={{
              mb: 5,
              maxWidth: 450,
              color: '#666',
            }}
          >
            {data.description}
          </Typography>
        </>
      ) : null}
      <Grid container spacing={4}>
        <Grid item md={6}>
          {data ? (
            <FormContainer>
              <EventRegistrationData data={data} />
              {registered ? (
                <Typography variant="subtitle1" gutterBottom component="div">
                  You have successfully registered for {data.name}!
                </Typography>
              ) : (
                <Formik validationSchema={validationSchema} initialValues={initialValues} onSubmit={onSubmit}>
                  {({ submitForm, isSubmitting }) => (
                    <Form>
                      <Stack spacing={3}>
                        <Stack spacing={2}>
                          <Field fullWidth component={FormikTextField} name="name" label="Your Name" type="text" />
                          <Field fullWidth component={FormikTextField} name="email" label="Email Address" type="text" />
                          <SchoolSelect
                            appType="university"
                            label="College"
                            institutionInfo={institution}
                            setInstitutionInfo={setInstitution}
                          />
                        </Stack>
                        {data.status === 'CANCELLED' && (
                          <Typography variant="subtitle1" gutterBottom component="div">
                            Registration canceled!
                          </Typography>
                        )}
                        {data.status === 'REGISTRATION_CLOSED' && (
                          <Typography variant="subtitle1" gutterBottom component="div">
                            Registration closed!
                          </Typography>
                        )}
                        <LoadingButton
                          disabled={data.status === 'CANCELLED' || data.status === 'REGISTRATION_CLOSED'}
                          onClick={submitForm}
                          variant="contained"
                          size="large"
                          loading={isSubmitting}
                        >
                          Register
                        </LoadingButton>
                      </Stack>
                    </Form>
                  )}
                </Formik>
              )}
            </FormContainer>
          ) : null}
        </Grid>
        <Grid item md={6}>
          <ParfaitInfo />
        </Grid>
      </Grid>
    </Container>
  );
};

export default PublicRegistration;
