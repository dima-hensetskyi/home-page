import { Typography } from '@mui/material';
import React, { useState } from 'react';

import { SmallDialog } from '../../../Dialog';
import RegistrationsList from './RegistrationsList';

type Props = {
  inviteId: string;
};

const RegistrationsView = (props: Props) => {
  const { inviteId } = props;

  const [visible, setVisible] = useState(false);

  return (
    <>
      <Typography
        sx={{ color: (theme) => theme.palette.primary.main, ':hover': { cursor: 'pointer' } }}
        onClick={() => {
          setVisible(true);
        }}
        variant="body2"
      >
        View registrations
      </Typography>
      <SmallDialog
        content={
          <div>
            <Typography
              variant="h6"
              sx={{
                mb: 2.5,
              }}
            >
              Current Registrations
            </Typography>
            <RegistrationsList eventId={inviteId} />
          </div>
        }
        open={visible}
        lgWidth="834px"
        xlWidth="834px"
        close={() => {
          setVisible(false);
        }}
      />
    </>
  );
};

export default RegistrationsView;
