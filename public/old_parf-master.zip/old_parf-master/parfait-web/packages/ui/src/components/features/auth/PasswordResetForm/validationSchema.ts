import * as Yup from 'yup';

const passwordResetSchema = Yup.object().shape({
  account: Yup.string().required('School Account is required.').nullable(),
  username: Yup.string().required('Username is required.').nullable(),
});

export default passwordResetSchema;
