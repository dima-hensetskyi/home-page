import styled from 'styled-components';

export const User = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 12px;
`;

export const UserName = styled.div`
  margin-left: 16px;
`;
