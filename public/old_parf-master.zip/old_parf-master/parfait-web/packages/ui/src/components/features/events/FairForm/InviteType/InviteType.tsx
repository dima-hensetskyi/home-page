import React from 'react';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import styled from 'styled-components';
import { Tooltip } from '@mui/material';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import { useFormikContext } from 'formik';
import { FormValues } from '../types';

const Wrapper = styled.div`
  .MuiRadio-root {
    padding-top: 3px;
    padding-bottom: 3px;
  }
`;

const Label = styled.div`
  display: flex;
  align-items: center;
`;

const InviteType = () => {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setFieldValue('inviteType', (event.target as HTMLInputElement).value);
  };

  const { values, setFieldValue } = useFormikContext<FormValues>();
  const value = values.inviteType;

  return (
    <Wrapper>
      <FormControl>
        <FormLabel id="demo-controlled-radio-buttons-group">College fair type:</FormLabel>
        <RadioGroup
          aria-labelledby="demo-controlled-radio-buttons-group"
          name="controlled-radio-buttons-group"
          value={value}
          onChange={handleChange}
        >
          <FormControlLabel value="OPEN" control={<Radio size="small" />} label="Open to all colleges" />
          <FormControlLabel
            value="INVITE_ONLY"
            control={<Radio size="small" />}
            label={
              <Label>
                By invite only
                <Tooltip
                  sx={{
                    marginLeft: '6px',
                  }}
                  title="Only allow colleges with an invitation to register for the fair. If not selected, colleges without an invitation can also register."
                >
                  <InfoOutlinedIcon />
                </Tooltip>
              </Label>
            }
          />
        </RadioGroup>
      </FormControl>
    </Wrapper>
  );
};

export default InviteType;
