import React from 'react';
import TextField from '@mui/material/TextField';

const ChatSearch = () => {
  return (
    <>
      <TextField fullWidth size="small" label="Search" variant="outlined" />
    </>
  );
};

export default ChatSearch;
