import MessagesEmpty from './MessagesEmpty';

export default MessagesEmpty;
