import React from 'react';
import styled from 'styled-components';
import { Typography } from '@mui/material';

export type AttributesData = Array<{
  label: string;
  value: string | number;
}>;

type Props = {
  title?: string;
  data: AttributesData;
  labelWidth?: 120;
};

const Heading = styled.div`
  background: #eef2fb;
  padding: 0 8px;
`;

const Table = styled.table`
  table-layout: fixed;
`;

const Cell = styled.td`
  width: 50%;
  vertical-align: top;
  padding: 2px;
`;

const Attributes = (props: Props) => {
  const { title, data, labelWidth } = props;

  return (
    <div>
      {title && (
        <Heading>
          <Typography variant="overline" display="block" gutterBottom>
            {title}
          </Typography>
        </Heading>
      )}
      <Table>
        <tbody>
          {data.map((row, index) => {
            return (
              <tr key={index}>
                <Cell
                  style={{
                    width: labelWidth,
                  }}
                >
                  <Typography variant="body2" color="#666">
                    {row.label}:
                  </Typography>
                </Cell>
                <Cell
                  style={{
                    width: labelWidth ? 'auto' : '50%',
                  }}
                >
                  <Typography variant="body2" color="#212121">
                    {row.value}
                  </Typography>
                </Cell>
              </tr>
            );
          })}
        </tbody>
      </Table>
    </div>
  );
};

export default Attributes;
