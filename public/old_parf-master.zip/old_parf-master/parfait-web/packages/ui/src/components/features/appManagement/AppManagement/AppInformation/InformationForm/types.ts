export type FormValues = {
  name: string;
  schoolURL: string;
  address1: string | null;
  address2: string | null;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  alphaTwoCode: string;
};
