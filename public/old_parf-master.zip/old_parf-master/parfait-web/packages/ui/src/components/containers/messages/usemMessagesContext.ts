import { MessagesContextType } from './types';
import { useContext } from 'react';
import MessagesContext from './MessagesContext';

const useMessagesContext = (): MessagesContextType => {
  return useContext(MessagesContext)!;
};

export default useMessagesContext;
