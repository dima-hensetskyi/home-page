import { Box, Divider, Tooltip, Typography } from '@mui/material';
import React from 'react';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';

import { RolesInformation } from '../data';

export const RoleInformationButton: React.FC = () => (
  <Tooltip
    sx={{
      marginLeft: '10px',
      color: 'rgba(0, 0, 0, 0.54)',
    }}
    title={RolesInformation.map((role, idx) => (
      <Box key={role.title}>
        <Typography>{role.title}</Typography>
        {role.items.map((item) => (
          <Typography key={item}>{`- ${item}`}</Typography>
        ))}
        {idx !== RolesInformation.length - 1 && <Divider sx={{ my: '5px' }} />}
      </Box>
    ))}
  >
    <InfoOutlinedIcon />
  </Tooltip>
);
