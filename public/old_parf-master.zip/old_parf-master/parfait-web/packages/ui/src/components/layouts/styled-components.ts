import styled from 'styled-components';

export const BackgroundImage = styled.div`
  position: absolute;
  right: 0;
  bottom: 0;
  top: 0;
  overflow: hidden;

  svg {
    min-height: 100%;
    top: 0;
  }
`;

export const Wrapper = styled.div`
  overflow: hidden;
  overflow-y: auto;
  min-height: 100vh;
  position: relative;
`;

export const Container = styled.div`
  max-width: 1154px;
  margin: auto;
  padding: 0 20px;
  display: flex;
  flex-direction: column;
  min-height: 100vh;
`;

export const FormWrapper = styled.div`
  max-width: 368px;
  margin-bottom: 20px;
  margin-top: 30px;
  flex-grow: 1;
  display: flex;
  justify-content: center;
  align-items: center;
`;

export const Form = styled.div`
  flex-grow: 1;
`;

export const Image = styled.div`
  position: absolute;
  right: 80px;
  bottom: 118px;
`;

export const Logo = styled.div`
  margin-top: 30px;
`;
