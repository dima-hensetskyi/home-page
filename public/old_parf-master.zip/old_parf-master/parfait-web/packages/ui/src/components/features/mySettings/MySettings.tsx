import { Box, Tab, Tabs } from '@mui/material';
import { useQueryClient } from 'react-query';
import React, { useState } from 'react';

import { Preferences } from './Preferences';
import { ProfileSettings } from './ProfileSettings';
import { AuthenticatedTenantUserResponse } from '../../../types/tenant';

type TabProps = {
  children?: React.ReactNode;
  idx: number;
  val: number;
};

const TabComponent: React.FC<TabProps> = ({ children, val, idx }: TabProps) => {
  if (val !== idx) return null;
  return (
    <div role="tabpanel" hidden={val !== idx} id={`simple-tabpanel-${idx}`} aria-labelledby={`simple-tab-${idx}`}>
      {val === idx && <Box sx={{ pt: '16px' }}>{children}</Box>}
    </div>
  );
};

type TabPanelPropsType = {
  onClose: () => void;
};

export const MySettings: React.FC<TabPanelPropsType> = ({ onClose }: TabPanelPropsType) => {
  const [value, setValue] = useState(0);
  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  const queryClient = useQueryClient();
  const tenantUser = queryClient.getQueryData<AuthenticatedTenantUserResponse>('AuthenticatedTenantUser');
  return (
    <>
      <Tabs value={value} onChange={handleChange}>
        <Tab sx={{ px: '32px' }} label="Profile" />
        <Tab sx={{ px: '32px' }} label="Preferences" />
      </Tabs>
      <TabComponent val={value} idx={0}>
        <ProfileSettings authenticatedUser={tenantUser?.getAuthenticatedTenantUser} onClose={onClose} />
      </TabComponent>
      <TabComponent val={value} idx={1}>
        <Preferences authenticatedUser={tenantUser?.getAuthenticatedTenantUser} onClose={onClose} />
      </TabComponent>
    </>
  );
};
