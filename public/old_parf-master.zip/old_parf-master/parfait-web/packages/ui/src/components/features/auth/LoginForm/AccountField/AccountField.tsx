import React, { useEffect } from 'react';
import { TextField as FormikTextField } from 'formik-mui';
import { Field, useFormikContext } from 'formik';

const AccountField = () => {
  const { setFieldValue } = useFormikContext();

  useEffect(() => {
    const account = localStorage.getItem('account');
    if (account) {
      setFieldValue('account', account);
    }
  }, []);

  return <Field fullWidth component={FormikTextField} name="account" label="Account" type="text" />;
};

export default AccountField;
