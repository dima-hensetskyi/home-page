import React, { MouseEvent, useState } from 'react';
import { TextFieldProps, IconButton } from '@mui/material';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import { Field } from 'formik';
import { TextField } from 'formik-mui';
import { PasswordInputWrapper, IconWrapper } from '../styledComponents';

const PasswordInput = (props: TextFieldProps) => {
  const [showPassword, setShowPassword] = useState(false);

  const handleMouseDownPassword = (event: MouseEvent) => {
    event.preventDefault();
  };

  const handleClickShowPassword = () => {
    setShowPassword((visible) => !visible);
  };

  return (
    <PasswordInputWrapper>
      <Field component={TextField} {...props} type={showPassword ? 'text' : 'password'} margin="dense" />
      <IconWrapper>
        <IconButton
          aria-label="toggle password visibility"
          onClick={handleClickShowPassword}
          onMouseDown={handleMouseDownPassword}
          edge="end"
        >
          {showPassword ? <VisibilityOff /> : <Visibility />}
        </IconButton>
      </IconWrapper>
    </PasswordInputWrapper>
  );
};

export default PasswordInput;
