import React from 'react';
import { Typography } from '@mui/material';
import { Storage } from 'aws-amplify';
import { useQuery } from 'react-query';
import { ChatUser } from '../../../../containers/messages/types';
import { Wrapper, ImagePlaceholder, Image, Name } from './styled-components';

type Props = {
  user?: ChatUser;
  size?: number;
};

const Avatar = (props: Props) => {
  const { user, size } = props;

  const { data: url } = useQuery(
    ['userAvatar', user?.avatar?.key],
    async () => {
      if (user && user.avatar) {
        const { avatar } = user;
        if (!avatar.key || !avatar.bucket) return;
        return await Storage.get(avatar.key, { bucket: avatar.bucket, region: avatar.region });
      }
      return null;
    },
    {
      staleTime: Infinity,
    },
  );

  return (
    <Wrapper
      style={{
        width: size,
        height: size,
      }}
    >
      {url ? (
        <Image
          src={url}
          style={{
            width: size,
            height: size,
          }}
        />
      ) : (
        <>
          <ImagePlaceholder />
          <Name>
            <Typography color="#fff" variant="overline">
              {user
                ? user.name
                    .split(' ')
                    .map((string) => string[0])
                    .join('')
                : null}
            </Typography>
          </Name>
        </>
      )}
    </Wrapper>
  );
};

export default Avatar;
