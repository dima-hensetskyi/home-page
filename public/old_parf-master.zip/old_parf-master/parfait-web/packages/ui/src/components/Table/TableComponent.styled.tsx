import styled from 'styled-components';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';

export const StyledTableCell = styled(TableCell)(() => ({
  // boxShadow: 'inset 0px -1px 0px rgba(0, 0, 0, 0.12)',

  [`&.${tableCellClasses.head}`]: {
    background: 'rgba(0, 0, 0, 0.12)',
    color: 'rgba(0, 0, 0, 0.87)',
    fontWeight: 600,
    fontSize: '14px',
    lineHeight: '24px',
    letterSpacing: '0.17px',
  },
  [`&.${tableCellClasses.body}`]: {
    color: 'rgba(0, 0, 0, 0.87)',
  },
}));

export const StyledTableRow = styled(TableRow)(() => ({
  '&:nth-of-type(even)': {
    backgroundColor: 'rgba(0, 0, 0, 0.04)',
  },
  // hide last border
  '&:last-child td, &:last-child th': {
    border: 0,
  },
}));

export const Loader = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(255, 255, 255, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
`;
