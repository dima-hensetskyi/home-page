import React from 'react';
import { Typography, CircularProgress, Tooltip } from '@mui/material';
import { Loader, Container } from './styled-components';

type Props = {
  disabledTooltipText?: string;
  message: string;
  btnText: string;
  loading: boolean;
  btnDisabled?: boolean;
  onClick: () => void;
};

const Message = (props: Props) => {
  const { message, btnText, loading, onClick, btnDisabled, disabledTooltipText } = props;

  const btn = (
    <Typography
      variant="body2"
      gutterBottom
      sx={{
        color: btnDisabled ? '#828282' : '#1976D2',
        cursor: btnDisabled ? 'default' : 'pointer',
      }}
      onClick={() => {
        if (!btnDisabled) {
          onClick();
        }
      }}
    >
      {btnText}
    </Typography>
  );

  return (
    <Container>
      {loading && (
        <Loader>
          <CircularProgress />
        </Loader>
      )}
      <Typography
        variant="caption"
        display="block"
        sx={{
          mb: 1,
        }}
      >
        {message}
      </Typography>
      {disabledTooltipText ? (
        <Tooltip title={disabledTooltipText} arrow>
          {btn}
        </Tooltip>
      ) : (
        btn
      )}
    </Container>
  );
};

export default Message;
