import { S3Object } from '../../../types/general';

export type MessagesContextType = {
  setActiveContact: (id: string) => void;
  endReached: () => void;
  activeContact: string | null;
  chats: Array<Chat>;
  activeChat: Chat | undefined;
  messagesHeight: number;
  chatUserId: string | null;
};

export type RenderProps = {
  activeId: string | null;
  loaded: boolean;
  empty: boolean;
  messagesHeight: number;
  onMessagesStatusRead: (chatId: string) => void;
};

export type Message =
  | {
      chatId: string; //"chat-836741197b534e88b22eea67049a84ed"
      content: string; //"New Test 14"
      contentType: 'TEXT';
      createdAt: string; // "2022-04-05T19:07:26.722Z"
      isGroupMessage?: boolean;
      hideTime?: boolean;
      id: string; //"chatMessage-20220405T190726722Z"
      status: 'SENT' | 'DELIVERED' | 'READ';
      tenantUser: null; //
      type: 'USER';
      // userId: string;
      user: {
        id: string;
        name: string;
        familyName: string;
        givenName: string;
        displayName: string;
        avatar: S3Object;
      };
    }
  | {
      chatId: string; //"chat-836741197b534e88b22eea67049a84ed"
      content: string; //"New Test 14"
      contentType: 'TEXT';
      createdAt: string; // "2022-04-05T19:07:26.722Z"
      id: string; //"chatMessage-20220405T190726722Z"
      isGroupMessage?: boolean;
      hideTime?: boolean;
      status: 'READ';
      tenantUser: {
        displayName: string;
        name: string;
        id: string;
        avatar: S3Object;
      }; //
      type: 'TENANT';
      user: {
        id: string;
        displayName: string;
      };
      tenantUserId: string;
    };

export type ChatUser = {
  avatar: S3Object;
  name: string; //"Cody"
  id: string;
};

export type Chat = {
  chatMessagesContainer: {
    nextToken: string;
    items: Array<Message>;
  };
  createdAt: string;
  id: string;
  institution: {
    id: string; //'institution-12bbeed1645f4309a622d35bb0ac47ab'
  };
  tenant: {
    id: string; //'tenant-2518c75d2ba0427f90f60d813c794cfa',
    name: string; // 'Southern Methodist University',
  };
  unreadMessageCount: number;
  updatedAt: string; // "2022-04-07T13:06:32.703Z"
  user: ChatUser;
};
