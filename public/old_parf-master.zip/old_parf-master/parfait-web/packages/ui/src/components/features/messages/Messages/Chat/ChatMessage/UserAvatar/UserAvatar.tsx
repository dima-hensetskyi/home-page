import React from 'react';
import { API, graphqlOperation } from 'aws-amplify';
import { getUserAvatar } from 'graphql/users';
import { useQuery } from 'react-query';
import Avatar from '../../../Avatar';

type Props = {
  userId: string;
};

const UserAvatar = (props: Props) => {
  const { userId } = props;

  const { data: user } = useQuery(
    ['getUserAvatar', userId],
    async () => {
      const result = await API.graphql(
        graphqlOperation(getUserAvatar, {
          id: userId,
        }),
      );

      // @ts-ignore
      return result.data.getUser;
    },
    {
      staleTime: Infinity,
      refetchOnWindowFocus: false,
    },
  );

  return <Avatar user={user} />;
};

export default UserAvatar;
