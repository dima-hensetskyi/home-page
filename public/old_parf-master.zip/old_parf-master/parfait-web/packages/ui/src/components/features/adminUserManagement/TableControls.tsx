import { Button } from '@mui/material';
import React from 'react';

import { TableTopControlPanel } from '../../Table';
import useAuthContext from '../../containers/auth/useAuthContext';

type PropsType = {
  openDialog: (val: boolean) => void;
};

export const TableControls: React.FC<PropsType> = ({ openDialog }: PropsType) => {
  // const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { tenant } = useAuthContext();

  return (
    <TableTopControlPanel titleProps={{ variant: 'h5' }} title={`${tenant?.name || ''} Users`}>
      {/* <FilterMenu isMenuOpen={isMenuOpen} setMenuOpen={setIsMenuOpen} />
      <Autocomplete
        inputValue={''}
        value={''}
        freeSolo
        size="small"
        sx={{ width: '324px', mr: '24px' }}
        // onChange={(evt, val) => val && setIsApply(true)}
        options={[]}
        onInputChange={() => console.log('New value')}
        renderInput={(params) => <TextField sx={{ borderColor: 'green' }} {...params} label="Search" />}
      /> */}
      <Button
        onClick={() => openDialog(true)}
        variant="contained"
        sx={{
          fontSize: '15px',
          lineHeight: '26px',
          letterSpacing: '0.46px',
        }}
      >
        Add user
      </Button>
    </TableTopControlPanel>
  );
};
