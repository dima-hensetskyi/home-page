import CollegeInfo from './CollegeInfo';

export default CollegeInfo;
