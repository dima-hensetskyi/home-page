import InviteType from './InviteType';

export default InviteType;
