import PrimaryImage from './PrimaryImage';

export default PrimaryImage;
