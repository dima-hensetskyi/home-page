import React from 'react';
import { Typography } from '@mui/material';
import PrimaryImage from './PrimaryImage';
import SecondaryImages from './SecondaryImages';
import useAuthContext from '../../../../containers/auth/useAuthContext';

const AppImages = () => {
  const { tenant } = useAuthContext()!;

  return (
    <>
      {tenant ? (
        <Typography
          variant="h5"
          gutterBottom
          component="div"
          sx={{
            mt: 3,
            mb: 3,
          }}
        >
          {tenant.name} Images
        </Typography>
      ) : null}
      <PrimaryImage />
      <SecondaryImages />
    </>
  );
};

export default AppImages;
