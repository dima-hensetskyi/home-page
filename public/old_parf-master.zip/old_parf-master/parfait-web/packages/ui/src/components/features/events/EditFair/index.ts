import EditFair from './EditFair';

export default EditFair;
