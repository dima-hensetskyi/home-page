import styled from 'styled-components';

export const Wrapper = styled.div`
  position: relative;
  width: 40px;
  height: 40px;
`;

export const ImagePlaceholder = styled.div`
  background: #ed6c03;
  width: 40px;
  height: 40px;
  border-radius: 50%;
`;

export const Image = styled.img`
  background-color: #ed6c03;
  width: 32px;
  height: 32px;
  border-radius: 50%;
`;

export const Name = styled.div`
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  text-transform: uppercase;
`;
