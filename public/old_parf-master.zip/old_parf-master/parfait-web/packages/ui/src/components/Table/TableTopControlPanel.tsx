import { Typography, TypographyProps } from '@mui/material';
import React from 'react';
import styled from 'styled-components';

const Wrapper = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
`;

const Controllers = styled.div`
  display: flex;
  align-items: center;
`;

type PropsType = {
  title: string;
  titleProps?: TypographyProps<'h4'>;
  children?: React.ReactNode;
};

const ControlPanel: React.FC<PropsType> = ({ title, children, titleProps = { variant: 'h4' } }: PropsType) => {
  return (
    <>
      <Wrapper>
        <Typography {...titleProps}>{title}</Typography>
        <Controllers>{children}</Controllers>
      </Wrapper>
    </>
  );
};

export default ControlPanel;
