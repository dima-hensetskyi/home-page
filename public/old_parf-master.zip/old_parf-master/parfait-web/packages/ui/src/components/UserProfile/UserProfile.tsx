import { Box, MenuItem, Select, styled, Typography } from '@mui/material';
import React, { useState } from 'react';

import { AvatarComponent } from '../Avatar';
import { Controller, ControllerItem } from './UserProfile.styled';

const ListItemTitle = styled(Typography)(() => ({
  color: 'rgba(0, 0, 0, 0.6)',
  flex: 1,
}));

const ListItemBody = styled(Typography)(() => ({
  width: '200px',
}));

const ProfileDetail = styled(Box)(() => ({
  gap: '4px',
  display: 'flex',
  flexDirection: 'column',
}));

const ProfileDetailTitle = styled(Typography)(() => ({
  background: '#EEF2FA',
  display: 'block',
  padding: '0 5px',
}));

const statuses = ['Accepted', 'Active', 'Applied', 'Declined', 'New'];
const cohortStatus = ['Current', 'Not current', 'Fall 2022'];

type PropsType = {
  userName?: string;
};

export const UserProfile: React.FC<PropsType> = ({ userName }: PropsType) => {
  const [data, setData] = useState({ cohort: 'Fall 2022', status: 'New', assigned: 'Accepted', interest: '' });
  return (
    <Box sx={{ maxWidth: '500px' }}>
      <Box display="flex" alignItems="center">
        <AvatarComponent name={userName} sx={{ bgcolor: (theme) => theme.palette.warning.main, mr: '16px' }} />
        <Typography variant="body1">{userName}</Typography>
      </Box>
      <Controller>
        <ControllerItem>
          <ListItemTitle variant="body2">Cohort:</ListItemTitle>
          <Select
            size="small"
            sx={{ width: '200px' }}
            value={data.cohort}
            onChange={(evt) => setData({ ...data, cohort: evt.target.value as string })}
          >
            {cohortStatus.map((status) => (
              <MenuItem key={status} value={status}>
                {status}
              </MenuItem>
            ))}
          </Select>
        </ControllerItem>
        <ControllerItem>
          <ListItemTitle variant="body2">Status:</ListItemTitle>
          <Select
            size="small"
            sx={{ width: '200px' }}
            value={data.status}
            onChange={(evt) => setData({ ...data, status: evt.target.value as string })}
          >
            {statuses.map((status) => (
              <MenuItem key={status} value={status}>
                {status}
              </MenuItem>
            ))}
          </Select>
        </ControllerItem>
        <ControllerItem>
          <ListItemTitle variant="body2">Assigned:</ListItemTitle>
          <Select
            value={data.assigned}
            size="small"
            displayEmpty={false}
            sx={{ width: '200px' }}
            onChange={(evt) => setData({ ...data, assigned: evt.target.value as string })}
          >
            {statuses.map((status) => (
              <MenuItem key={status} value={status}>
                {status}
              </MenuItem>
            ))}
          </Select>
        </ControllerItem>
        <ControllerItem>
          <ListItemTitle variant="body2">School interest:</ListItemTitle>
          <ListItemBody variant="body2">Bookmark</ListItemBody>
        </ControllerItem>
      </Controller>
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
        <ProfileDetail>
          <ProfileDetailTitle variant="overline">Profile</ProfileDetailTitle>
          <ControllerItem>
            <ListItemTitle variant="body2">Graduation year:</ListItemTitle>
            <ListItemBody variant="body2">2022</ListItemBody>
          </ControllerItem>
          <ControllerItem>
            <ListItemTitle variant="body2">Current school:</ListItemTitle>
            <ListItemBody variant="body2">Linkcoln High School</ListItemBody>
          </ControllerItem>
          <ControllerItem>
            <ListItemTitle variant="body2">Location:</ListItemTitle>
            <ListItemBody variant="body2">Houston, TX</ListItemBody>
          </ControllerItem>
        </ProfileDetail>
        <ProfileDetail>
          <ProfileDetailTitle variant="overline">Academics</ProfileDetailTitle>
          <ControllerItem>
            <ListItemTitle variant="body2">GPA:</ListItemTitle>
            <ListItemBody variant="body2">3.2</ListItemBody>
          </ControllerItem>
          <ControllerItem>
            <ListItemTitle variant="body2">ACT:</ListItemTitle>
            <ListItemBody variant="body2">n/a</ListItemBody>
          </ControllerItem>
          <ControllerItem>
            <ListItemTitle variant="body2">SAT:</ListItemTitle>
            <ListItemBody variant="body2">1250</ListItemBody>
          </ControllerItem>
          <ControllerItem>
            <ListItemTitle variant="body2">Class rank:</ListItemTitle>
            <ListItemBody variant="body2">32/150</ListItemBody>
          </ControllerItem>
        </ProfileDetail>
        <ProfileDetail>
          <ProfileDetailTitle variant="overline">Interests</ProfileDetailTitle>
          <ControllerItem>
            <ListItemTitle variant="body2">Majors:</ListItemTitle>
            <ListItemBody variant="body2">English, Literature, Journalism</ListItemBody>
          </ControllerItem>
          <ControllerItem>
            <ListItemTitle variant="body2">Athletics:</ListItemTitle>
            <ListItemBody variant="body2">Volleyball</ListItemBody>
          </ControllerItem>
        </ProfileDetail>
      </Box>
    </Box>
  );
};
