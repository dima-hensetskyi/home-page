import * as Yup from 'yup';

const passwordResetSubmitFormSchema = Yup.object().shape({
  password: Yup.string().required('Password is required.').nullable(),
  passwordConfirm: Yup.string()
    .required('Confirm Password does not match New Password')
    .test('checkPasswordConfirm', 'Confirm Password does not match New Password', (value, { parent }) =>
      value && parent['password'] ? value === parent['password'] : true,
    )
    .nullable(),
});

export default passwordResetSubmitFormSchema;
