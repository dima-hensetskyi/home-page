import React, { useState } from 'react';
import { LinearProgress, Stack } from '@mui/material';
import AuthHeader from '../AuthHeader';
import { Formik, Form, Field, FormikHelpers } from 'formik';
import Alert from '@mui/material/Alert';
import { TextField as FormikTextField } from 'formik-mui';
import useAuthContext from '../../../containers/auth/useAuthContext';
import { confirmEmailSchema } from './validationSchema';
import { Container, Error } from '../styledComponents';
import Button from '../Button';

const ConfirmEmailForm = () => {
  const { confirmEmail } = useAuthContext();
  const [error, setError] = useState('');

  const initialValues = {
    code: '',
  };

  const onSubmit = async (values: typeof initialValues, { setSubmitting }: FormikHelpers<typeof initialValues>) => {
    setError('');
    try {
      await confirmEmail(values.code);
    } catch (error) {
      setError('The code you entered does not match our records. ');
      setSubmitting(false);
    }
  };

  return (
    <Container>
      <AuthHeader
        title="Confirm your account"
        description="Please enter the confirmation code that was emailed to you."
      />
      <Formik validationSchema={confirmEmailSchema} initialValues={initialValues} onSubmit={onSubmit}>
        {({ isSubmitting }) => (
          <Form>
            <Stack spacing={3}>
              <Field fullWidth component={FormikTextField} name="code" label="Confirmation code" type="text" />
              {error && (
                <Error>
                  <Alert severity="error">{error}</Alert>
                </Error>
              )}
              <div>
                {isSubmitting && <LinearProgress />}
                <Button type="submit">Confirm</Button>
              </div>
            </Stack>
          </Form>
        )}
      </Formik>
    </Container>
  );
};

export default ConfirmEmailForm;
