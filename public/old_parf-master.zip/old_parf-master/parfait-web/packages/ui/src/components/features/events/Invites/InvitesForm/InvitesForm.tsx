import React, { useState } from 'react';
import { Field, Formik, Form } from 'formik';
import styled from 'styled-components';
import { TextField as FormikTextField } from 'formik-mui';
import { Alert, Stack } from '@mui/material';
import AddEmail from './AddEmail';
import * as Yup from 'yup';

const Wrapper = styled.div`
  max-width: 460px;
`;

type Props = {
  onSubmit: (message: string, emails: Array<string>) => Promise<void>;
};

const InvitesForm = (props: Props) => {
  const { onSubmit } = props;

  const [emails, setEmails] = useState<Array<string>>([]);
  const [error, setError] = useState<string | null>(null);

  return (
    <Wrapper>
      <Stack spacing={1.5}>
        {error && <Alert severity="error">{error}</Alert>}
        <AddEmail emails={emails} setEmails={setEmails} />
        <Formik
          onSubmit={(values, { setSubmitting }) => {
            setError(null);

            if (emails.length > 0) {
              onSubmit(values.message, emails);
            } else {
              setError('First you need to add at least one email address for invitation.');
              setSubmitting(false);
            }
          }}
          initialValues={{
            message:
              'You are invited to our upcoming college fair. We use a new college fair platform call Parfait. Once you join Parfait, you can scan students at the fair with a your mobile device. Please click the link below to register!',
          }}
          validationSchema={Yup.object().shape({
            message: Yup.string().max(250, 'Field has a maximum limit of 250 characters.').nullable(),
          })}
        >
          <Form id="fair-invites">
            <Field component={FormikTextField} rows={4} fullWidth multiline name="message" label="Message" />
          </Form>
        </Formik>
      </Stack>
    </Wrapper>
  );
};

export default InvitesForm;
