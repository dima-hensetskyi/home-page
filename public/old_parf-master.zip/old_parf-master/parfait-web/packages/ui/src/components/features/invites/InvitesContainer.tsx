import { Box, Button, Typography } from '@mui/material';
import { useInfiniteQuery, useQueryClient } from 'react-query';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useState } from 'react';

import { BasicDialog } from '../../Dialog';
import { getCorrectDate, getCorrectString } from '../utils';
import { getCorrectInvitesList } from './utils';
import { getInvitesList } from './api';
import { GetInvitesVarsType, Invite } from '../../../types/invites';
import { InviteForm } from './InviteForm/InviteForm';
import { Loader } from '../../Loader';
import { TableComponent, TableTopControlPanel } from '../../Table';

const initialInvitesVars = {
  limit: 10,
  sortDirection: 'DESC' as const,
};

export const InvitesContainer: React.FC = () => {
  // const [inviteType, setInviteType] = useState('');
  const [activeInvite, setActiveInvite] = useState<Invite | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [requestVariables, setRequestVariables] = useState<GetInvitesVarsType>(initialInvitesVars);
  const AlternativeOrder = requestVariables.sortDirection === 'ASC' ? 'DESC' : 'ASC';
  const queryIdWithAltSort = ['GetInvites', { ...requestVariables, sortDirection: AlternativeOrder }];
  const queryId = ['GetInvites', requestVariables];
  const queryClient = useQueryClient();

  const { data, isLoading, isFetching, hasNextPage, fetchNextPage } = useInfiniteQuery(
    queryId,
    (data) => getInvitesList(data.pageParam ? { ...requestVariables, nextToken: data.pageParam } : requestVariables),
    { keepPreviousData: true, retry: false, getNextPageParam: (lastPage) => lastPage?.nextToken },
  );

  const onCloseDialog = () => {
    setActiveInvite(null);
    setIsDialogOpen(false);
  };

  const pages = data?.pages || [];
  const invitesList = getCorrectInvitesList(pages.map((page) => page?.items || []).flat(1));

  return (
    <Box sx={{ display: 'flex', flex: '1', flexDirection: 'column' }}>
      <TableTopControlPanel title="Parfait invites">
        {/* <FormControl fullWidth size="small">
          <InputLabel id="inviteType">Invite type</InputLabel>
          <Select
            sx={{ width: '220px', mr: '24px' }}
            labelId="inviteType"
            label="inviteType"
            value={inviteType}
            onChange={(evt) => {
              setInviteType(evt.target.value as string);
            }}
          >
            {invitesType.map((invite) => (
              <MenuItem key={invite} value={invite}>
                {invite}
              </MenuItem>
            ))}
          </Select>
        </FormControl> */}
        <Button
          size="large"
          variant="contained"
          sx={{
            minWidth: '147px',
            height: '40px',
            fontSize: '15px',
            lineHeight: '26px',
            letterSpacing: '0.46px',
          }}
          onClick={() => setIsDialogOpen(true)}
        >
          Send Invites
        </Button>
      </TableTopControlPanel>
      {isLoading ? (
        <Loader />
      ) : (
        <>
          <TableComponent
            tableDataItems={invitesList}
            sortOrder={requestVariables.sortDirection}
            orderBy="date"
            onSortLabel={() => setRequestVariables({ ...requestVariables, sortDirection: AlternativeOrder })}
            onMouseSortLabel={() => {
              if (!queryClient.getQueryData(queryIdWithAltSort)) {
                queryClient.prefetchInfiniteQuery(queryIdWithAltSort, () =>
                  getInvitesList({ ...requestVariables, sortDirection: AlternativeOrder }),
                );
              }
            }}
            tableCustomRenderers={{
              emailAddress: (invite) => (
                <Typography sx={{ minWidth: '400px' }} variant="body2">
                  {invite?.emailAddress}
                </Typography>
              ),
              date: (invite) => (
                <Typography sx={{ minWidth: '80px' }} variant="body2">
                  {getCorrectDate(invite.date)}
                </Typography>
              ),
              status: (invite) => (
                <Typography sx={{ minWidth: '150px' }} variant="body2">
                  {invite.status === 'PENDING' ? (
                    <>
                      {'Pending... '}
                      <Typography
                        sx={{ color: (theme) => theme.palette.primary.main, cursor: 'pointer', display: 'inline' }}
                        variant="body2"
                        component="span"
                        onClick={() => {
                          setActiveInvite(() => invite.invite);
                          setIsDialogOpen(true);
                        }}
                      >
                        Invite Again
                      </Typography>
                    </>
                  ) : (
                    getCorrectString(invite.status)
                  )}
                </Typography>
              ),
            }}
            tableHeaders={{ emailAddress: 'Email', date: 'Date', status: 'Status' }}
          />
          <Box sx={{ display: 'flex', visibility: hasNextPage ? 'visible' : 'hidden', justifyContent: 'flex-end' }}>
            <LoadingButton
              loading={isFetching}
              sx={{
                fontSize: '15px',
                lineHeight: '26px',
                letterSpacing: '0.46px',
              }}
              variant="contained"
              onClick={() => fetchNextPage()}
            >
              SHOW MORE
            </LoadingButton>
          </Box>
        </>
      )}
      <BasicDialog
        title="Invite high school counselors and other universities to join Parfait"
        open={isDialogOpen}
        onClose={onCloseDialog}
        paperSx={{ minWidth: '708px' }}
        titleBoxSx={{ p: '32px', pb: '33px' }}
        bodySx={{ px: '32px', pb: '32px', pt: '0' }}
      >
        <InviteForm queryId={queryId} invite={activeInvite} onClose={onCloseDialog} />
      </BasicDialog>
    </Box>
  );
};
