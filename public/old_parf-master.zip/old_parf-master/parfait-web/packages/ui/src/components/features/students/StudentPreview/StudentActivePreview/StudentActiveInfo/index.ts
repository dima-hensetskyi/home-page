import StudentActiveInfo from './StudentActiveInfo';

export default StudentActiveInfo;
