import { Box, Divider, Typography } from '@mui/material';
import React from 'react';

import { FairsAttendingItemType } from '../types';
import { getCorrectAddress } from '../utils';
import { getCorrectString } from '../../utils';
import { getCorrectTime } from '../utils/utils';
import { ListItemBody, ListItemTitle, ListItem } from './FairDetails.styled';
import { SmallDialog } from '../../../Dialog';
import { AssignStaffInput } from './AssignStaffInput';

type PropsType = {
  isOpen: boolean;
  onClose: () => void;
  activeFair: FairsAttendingItemType | null;
};

export const FairDetails: React.FC<PropsType> = ({ isOpen, onClose, activeFair }) => {
  if (!activeFair) return null;
  const {
    name,
    locationName,
    expectedAttendees,
    status,
    staffAssigned,
    fullDetail: {
      event: { description, note, organizer, fee, startDateAndTime, endDateAndTime, address },
    },
  } = activeFair;

  const details = {
    'Date & Time': getCorrectTime(startDateAndTime, endDateAndTime),
    Organizer: organizer?.givenName,
    'Organizer Email': organizer?.email,
    Fee: fee || 'none',
    Address: getCorrectAddress(address),
    Location: locationName,
    'Expected Attendees': expectedAttendees,
    Description: description,
    Note: note,
    'Registration Status': getCorrectString(status),
  };

  return (
    <SmallDialog
      lgWidth="516px"
      xlWidth="516px"
      close={onClose}
      open={isOpen}
      content={
        <>
          <Box sx={{ display: 'grid', gap: '24px' }}>
            <Typography variant="h6">{name}</Typography>
            <Box sx={{ display: 'grid', gap: '4px' }}>
              {Object.entries(details).map((item) => {
                const [title, content] = item;
                return (
                  content && (
                    <ListItem key={title}>
                      <ListItemTitle variant="body2">{title}</ListItemTitle>
                      <ListItemBody variant="body2">{content}</ListItemBody>
                    </ListItem>
                  )
                );
              })}
            </Box>
            <Divider />
            <Box>
              <Typography variant="subtitle2" sx={{ mb: '16px' }}>
                Assign Staff to Fair
              </Typography>
              <AssignStaffInput activeFair={activeFair} staffAssigned={staffAssigned} />
            </Box>
          </Box>
        </>
      }
    />
  );
};
