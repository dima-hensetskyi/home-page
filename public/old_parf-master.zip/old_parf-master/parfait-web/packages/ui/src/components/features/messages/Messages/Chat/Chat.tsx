import React, { Reducer, useEffect, useReducer, useRef, useState } from 'react';
import { API, graphqlOperation } from 'aws-amplify';
import { getChat, sendChatMsgMutation, getChatMsgs } from 'graphql/chat';
import { Virtuoso } from 'react-virtuoso';
import styled from 'styled-components';
import Observable from 'zen-observable-ts';
import CircularProgress from '@mui/material/CircularProgress';
import { messageSubscription } from 'graphql/chatMessage';
import { Message } from '../../../../containers/messages/types';
import ChatForm from './ChatForm';
import ChatMessage from './ChatMessage';
import dayjs from 'dayjs';
import MessagesDate from './ChatMessage/MessagesDate';
import CustomScrollbar from '../CustomScrollbar';
import { Box, Typography } from '@mui/material';
import { AvatarComponent } from '../../../../Avatar';
import { useQueryClient } from 'react-query';
import { AuthenticatedTenantUserResponse } from '../../../../../types/tenant';

type Props = {
  chatId: string;
  height: number;
  onMessageRead?: (chatId: string) => void;
};

type Action =
  | {
      type: 'CHAT_LOAD_START';
    }
  | {
      type: 'SEND_MESSAGE';
    }
  | {
      type: 'SEND_MESSAGE_SUCCESS';
      payload: Message;
    }
  | {
      type: 'RECEIVE_MESSAGE';
      payload: Message;
    }
  | {
      type: 'CHAT_LOAD_SUCCESS';
      payload: {
        messages: Array<Message>;
        token: string | null;
      };
    }
  | {
      type: 'FETCH_PREV_MESSAGES';
    }
  | {
      type: 'FETCH_PREV_MESSAGES_SUCCESS';
      payload: {
        messages: Array<Message>;
        token: string | null;
      };
    };

type State = {
  loaded: boolean;
  sendMessageLoading: boolean;
  messages: Array<Message>;
  prevMessagesLoading: boolean;
  prevToken: string | null;
  firstItemIndex: number;
};

type GroupedMessages = { [key: string]: Array<Message> };

const Container = styled.div`
  display: flex;
  flex-direction: column;
`;

const Loader = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
`;

const Chat = (props: Props) => {
  const { chatId, height, onMessageRead } = props;
  const [subscriptionTrigger, setSubscriptionTrigger] = useState<boolean>(false);
  const queryClient = useQueryClient();
  const authenticatedUser = queryClient.getQueryData('AuthenticatedTenantUser') as AuthenticatedTenantUserResponse;
  const {
    getAuthenticatedTenantUser: { avatar, name },
  } = authenticatedUser;

  const initialTopMostItemIndex = 10000;

  const isMyOwnMessage = useRef(false);
  const listRef = useRef(null);

  const [{ messages, loaded, sendMessageLoading, prevToken, prevMessagesLoading, firstItemIndex }, dispatch] =
    useReducer<Reducer<State, Action>>(
      (state, action) => {
        switch (action.type) {
          case 'FETCH_PREV_MESSAGES':
            return {
              ...state,
              prevMessagesLoading: true,
            };
          case 'FETCH_PREV_MESSAGES_SUCCESS':
            return {
              ...state,
              messages: action.payload.messages.concat(state.messages),
              prevMessagesLoading: false,
              prevToken: action.payload.token,
              firstItemIndex: state.firstItemIndex - action.payload.messages.length,
            };
          case 'SEND_MESSAGE_SUCCESS':
            return {
              ...state,
              sendMessageLoading: false,
              messages: state.messages.concat([action.payload]),
            };
          case 'RECEIVE_MESSAGE':
            if (
              !state.messages.find((msg) => {
                return action.payload.id === msg.id;
              })
            ) {
              return {
                ...state,
                messages: state.messages.concat([action.payload]),
              };
            }
            return state;
          case 'SEND_MESSAGE':
            return {
              ...state,
              sendMessageLoading: true,
            };
          case 'CHAT_LOAD_START':
            return {
              ...state,
              messages: [],
              loaded: false,
            };
          case 'CHAT_LOAD_SUCCESS':
            return {
              ...state,
              messages: action.payload.messages,
              prevToken: action.payload.token,
              loaded: true,
            };
        }

        return state;
      },
      {
        messages: [],
        loaded: false,
        prevToken: null,
        prevMessagesLoading: false,
        sendMessageLoading: false,
        firstItemIndex: initialTopMostItemIndex,
      },
    );

  useEffect(() => {
    const fetchChatData = async () => {
      dispatch({
        type: 'CHAT_LOAD_START',
      });

      const result = await API.graphql(
        graphqlOperation(getChat, {
          id: chatId,
        }),
      );
      dispatch({
        type: 'CHAT_LOAD_SUCCESS',
        payload: {
          // @ts-ignore
          messages: result.data.chat.chatMessagesContainer.items.reverse(),
          // @ts-ignore
          token: result.data.chat.chatMessagesContainer.nextToken,
        },
      });
    };

    if (chatId) {
      fetchChatData();
    }
  }, [chatId]);

  const onChangedMessage = (message: Message) => {
    dispatch({
      type: 'RECEIVE_MESSAGE',
      payload: message,
    });
  };

  /**
   * Subscribe to new messages
   */
  useEffect(() => {
    const subscription = (
      API.graphql({
        query: messageSubscription,
        variables: {
          chatId,
        },
      }) as unknown as Observable<any>
    ).subscribe({
      next: (result) => {
        const { changedMessage } = result.value.data;

        onChangedMessage({
          chatId: changedMessage.chatId,
          content: changedMessage.content,
          contentType: changedMessage.contentType,
          createdAt: changedMessage.createdAt,
          id: changedMessage.id,
          status: changedMessage.status,
          tenantUser: changedMessage.tenantUser,
          type: changedMessage.type,
          user: changedMessage.user,
        });
      },
      error: () => {
        // Resubscribe on error
        setSubscriptionTrigger((state) => !state);
      },
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [chatId, subscriptionTrigger]);

  const sendMessage = async (message: string) => {
    const body = {
      content: message,
      contentType: 'TEXT',
      chatId,
      type: 'TENANT',
    };
    isMyOwnMessage.current = true;
    dispatch({
      type: 'SEND_MESSAGE',
    });

    const result = await API.graphql(
      graphqlOperation(sendChatMsgMutation, {
        input: body,
      }),
    );

    dispatch({
      type: 'SEND_MESSAGE_SUCCESS',
      // @ts-ignore
      payload: result.data.sendChatMessageResult,
    });
    isMyOwnMessage.current = false;
  };

  const getNextMessages = async (token: string) => {
    const result = await API.graphql(
      graphqlOperation(getChatMsgs, {
        chatId: chatId,
        nextToken: token,
      }),
    );
    // @ts-ignore
    return result.data.nextChatMessages;
  };

  const startReached = async () => {
    if (prevToken && !prevMessagesLoading) {
      const result = await getNextMessages(prevToken);

      dispatch({
        type: 'FETCH_PREV_MESSAGES_SUCCESS',
        payload: {
          // @ts-ignore
          messages: result.items.reverse(),
          // @ts-ignore
          token: result.nextToken,
        },
      });
    }
  };

  const getGroupedMessages = (): Array<string | Message> => {
    const groupedMessages: GroupedMessages = {};
    messages.forEach((message, idx, arr) => {
      const createdAt = dayjs(message.createdAt).format('DD.MM.YYYY');

      if (createdAt in groupedMessages) {
        groupedMessages[createdAt].push(message);
        const previousMessage = arr[idx - 1];

        if (previousMessage.tenantUser?.id === message.tenantUser?.id) {
          message['isGroupMessage'] = true;
          // const previousMessageTime = dayjs(previousMessage.createdAt);
          // const difference = previousMessageTime.diff(message.createdAt, 'minutes');
          // const isTheSameTime = difference >= -10;
          // const isOldMessage = difference <= -60;
          // if (isTheSameTime) message['hideTime'] = true;
          // if (isOldMessage) message['isGroupMessage'] = false;
        }
      } else {
        groupedMessages[createdAt] = [message];
      }
    });

    const result: Array<string | Message> = [];

    Object.keys(groupedMessages).forEach((key) => {
      result.push(...[key, ...groupedMessages[key]]);
    });

    if (prevToken) {
      result.shift();
    }

    return result;
  };

  if (!loaded) {
    return (
      <Loader style={{ height }}>
        <CircularProgress
          sx={{
            mb: 2,
          }}
        />
      </Loader>
    );
  }
  const messagesList = getGroupedMessages();
  return (
    <Container style={{ height }}>
      <Virtuoso
        scrollerRef={(ref) => {
          if (ref) {
            (ref as HTMLElement).style.willChange = 'transform';
          }
        }}
        components={{
          // @ts-ignore
          Scroller: CustomScrollbar,
        }}
        startReached={startReached}
        firstItemIndex={firstItemIndex}
        ref={listRef}
        style={{ flex: 1 }}
        initialTopMostItemIndex={initialTopMostItemIndex}
        followOutput={(isAtBottom) => {
          if (isMyOwnMessage.current) {
            // if the user has scrolled away and sends a message, bring him to the bottom instantly
            return 'auto';
          } else {
            // a message from another user has been received - don't pull to bottom unless already there
            return isAtBottom ? 'auto' : false;
          }
        }}
        itemContent={(index, messageOrDate) => {
          if (typeof messageOrDate === 'string') {
            return <MessagesDate date={messageOrDate} />;
          }
          return (
            <ChatMessage
              chatId={chatId}
              message={messageOrDate}
              onMessageRead={() => {
                if (onMessageRead) {
                  onMessageRead(chatId);
                }
              }}
            />
          );
        }}
        data={messagesList}
      />
      <Box sx={{ display: 'flex', gap: '8px', alignItems: 'center', mt: '24px' }}>
        <AvatarComponent avatar={avatar} />
        <Typography variant="subtitle2">{name}</Typography>
      </Box>
      <ChatForm onSend={sendMessage} loading={sendMessageLoading} />
    </Container>
  );
};

export default Chat;
