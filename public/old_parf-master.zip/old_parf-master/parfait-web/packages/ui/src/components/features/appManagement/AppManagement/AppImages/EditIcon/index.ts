import EditIcon from './EditIcon';

export default EditIcon;
