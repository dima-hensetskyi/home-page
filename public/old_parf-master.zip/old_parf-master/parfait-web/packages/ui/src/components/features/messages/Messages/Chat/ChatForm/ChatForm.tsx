import React, { useState } from 'react';
import styled from 'styled-components';
import { TextField, Stack, Alert } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';

type Props = {
  onSend: (message: string) => Promise<void>;
  loading: boolean;
};

const Form = styled.form`
  display: block;
  width: 100%;
`;

const ChatForm = (props: Props) => {
  const { onSend, loading } = props;

  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  return (
    <Form
      onSubmit={async (event) => {
        event.preventDefault();
        setError('');

        try {
          await onSend(message);
          setMessage('');
        } catch (error) {
          setError('Send message error');
        }
      }}
    >
      <Stack spacing={1} mt={2}>
        <TextField
          disabled={loading}
          onChange={(event) => {
            setMessage(event.target.value);
          }}
          value={message}
          placeholder="Message..."
          multiline
          rows={2}
          size="small"
        />
        {error && <Alert severity="error">{error}</Alert>}
        <div>
          <LoadingButton disabled={!message?.length} variant="contained" size="small" type="submit" loading={loading}>
            Send message
          </LoadingButton>
        </div>
      </Stack>
    </Form>
  );
};

export default ChatForm;
