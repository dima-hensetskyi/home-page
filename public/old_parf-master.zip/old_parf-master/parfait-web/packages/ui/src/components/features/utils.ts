import moment from 'moment';

export const getCorrectDate = (date: string, format = 'MM/DD/YYYY') => {
  const isToday = moment(date).isSame(new Date(), 'day');
  if (isToday) return 'Today';

  const yesterday = moment().subtract(1, 'days');
  const isYesterday = moment(date).isSame(yesterday, 'day');
  if (isYesterday) return 'Yesterday';

  const userDate = new Date(date);
  return moment(userDate).format(format);
};

export const getCorrectString = (str: string) => {
  return str.slice(0, 1) + str.slice(1).toLowerCase().replace('_', ' ');
};

export const getScrollBottom = (evt: React.UIEvent<HTMLDivElement>) => {
  const { clientHeight, scrollHeight, scrollTop } = evt.currentTarget;
  const isBottom = clientHeight + scrollTop === scrollHeight;
  const isMiddle = scrollHeight - clientHeight - scrollTop === scrollTop;
  return isBottom || isMiddle;
};
