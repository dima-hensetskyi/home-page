import {
  Box,
  Button,
  Chip,
  FormControl,
  FormControlLabel,
  Grid,
  IconButton,
  InputAdornment,
  Radio,
  RadioGroup,
  styled,
  TextField,
} from '@mui/material';
import { useMutation, useQueryClient } from 'react-query';
import { useSnackbar } from 'notistack';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useState } from 'react';

import { collegeInviteMessage, hightSchoolMessage } from '../data';
import { createNewInvites, resendInvitation } from '../api';
import {
  CreateInvitesInputType,
  GetInvitesVarsType,
  Invite,
  InviteType,
  ResendInviteInputType,
} from '../../../../types/invites';
import { EnterIcon } from '../../../../icons';

const NoteTextFiled = styled(TextField)(() => ({
  [`.MuiOutlinedInput-root`]: {
    paddingTop: '12px',
    paddingBottom: '12px',
    minHeight: '104px',
  },
}));

type PropsType = {
  invite?: Invite | null;
  onClose: () => void;
  queryId: (string | GetInvitesVarsType)[];
};

export const InviteForm: React.FC<PropsType> = ({ invite, onClose, queryId }: PropsType) => {
  const [message, setMessage] = useState(invite?.message || hightSchoolMessage);
  const [email, setEmail] = useState('');
  const [inviteType, setInviteType] = useState(invite?.type || 'HIGH_SCHOOL');
  const [emailAddresses, setEmailAddresses] = useState<string[]>(invite?.emailAddress ? [invite?.emailAddress] : []);
  const [isInvalidField, setIsInvalidField] = useState(false);
  const { enqueueSnackbar } = useSnackbar();
  const queryClient = useQueryClient();

  const { mutateAsync, isLoading } = useMutation((vars: CreateInvitesInputType) => createNewInvites(vars), {
    onSuccess: (data) => {
      if (data?.createInvites) {
        enqueueSnackbar('Invites successfully created!', {
          variant: 'success',
        });
        onClose();
      } else {
        enqueueSnackbar('Something went wrong!', {
          variant: 'error',
        });
      }
    },
    onError: () => {
      enqueueSnackbar('Something went wrong!', {
        variant: 'error',
      });
    },
    onSettled: () => {
      queryClient.invalidateQueries(queryId);
    },
  });

  const resendInvite = useMutation((vars: ResendInviteInputType) => resendInvitation(vars), {
    onSuccess: () => {
      enqueueSnackbar('Invites successfully updated!', {
        variant: 'success',
      });
      onClose();
    },
    onError: () => {
      enqueueSnackbar('Something went wrong!', {
        variant: 'error',
      });
    },
    onSettled: () => {
      queryClient.invalidateQueries(queryId);
    },
  });

  const onDeleteEmail = (oldEmail: string) => {
    const idx = emailAddresses.findIndex((email) => email === oldEmail);
    if (idx >= 0) {
      const newEmailAddresses = [...emailAddresses];
      newEmailAddresses.splice(idx, 1);
      setEmailAddresses(newEmailAddresses);
    }
  };

  const onAddNewEmail = () => {
    const isValidEmail = email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
    if (isValidEmail) {
      setEmailAddresses((prev) => Array.from(new Set([...prev, email])));
      setEmail('');
    } else {
      setIsInvalidField(true);
    }
  };

  return (
    <Box sx={{ gap: '15px', display: 'grid' }}>
      <FormControl sx={{ mt: '-8px' }}>
        <RadioGroup
          value={inviteType}
          onChange={(evt) => {
            const newType = evt.target.value as InviteType;
            setInviteType(newType);
            setMessage(newType === 'COLLEGE' ? collegeInviteMessage : hightSchoolMessage);
          }}
          row
          name="invitesType-group"
        >
          <FormControlLabel
            disabled={!!invite?.id}
            value="HIGH_SCHOOL"
            control={<Radio size="small" />}
            label="High School Invites"
          />
          <FormControlLabel
            disabled={!!invite?.id}
            value="COLLEGE"
            control={<Radio size="small" />}
            label="College Invites"
          />
        </RadioGroup>
      </FormControl>
      <NoteTextFiled
        rows="3"
        inputProps={{ maxLength: 250 }}
        label="Message"
        value={message}
        multiline={true}
        onChange={(evt) => setMessage(evt.target.value as string)}
      />
      <Box sx={{ display: 'grid', gap: '8px' }}>
        <TextField
          disabled={!!invite?.id}
          type="text"
          placeholder="email@school.edu/org/com"
          helperText={isInvalidField && 'Valid email is required.'}
          error={isInvalidField}
          autoComplete="email"
          value={email}
          onChange={(evt) => {
            isInvalidField && setIsInvalidField(false);
            setEmail(evt.target.value);
          }}
          onKeyDown={(evt) => evt.key === 'Enter' && onAddNewEmail()}
          id="email"
          name="email"
          label="Email addresses"
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton
                  sx={{ width: '32px', height: '32px' }}
                  disabled={isInvalidField || !!invite?.id}
                  onClick={onAddNewEmail}
                >
                  <EnterIcon />
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
        {emailAddresses.length > 0 && (
          <Grid container sx={{ gap: '8px', maxHeight: '112px', overflowY: 'auto' }}>
            {emailAddresses.map((email) => (
              <Chip
                label={email}
                key={email}
                onDelete={() => {
                  !invite?.id && onDeleteEmail(email);
                }}
              />
            ))}
          </Grid>
        )}
      </Box>
      <Box sx={{ gap: '8px', display: 'flex', mt: '9px' }}>
        <LoadingButton
          loading={isLoading || resendInvite.isLoading}
          variant="contained"
          sx={{
            fontSize: '15px',
            lineHeight: '26px',
            letterSpacing: '0.46px',
          }}
          disabled={message.length < 3 || !emailAddresses.length}
          onClick={() =>
            invite?.id
              ? resendInvite.mutateAsync({ input: { message, id: invite.id } })
              : mutateAsync({ input: { emailAddresses, message, type: inviteType } })
          }
        >
          Send invites
        </LoadingButton>
        <Button
          variant="outlined"
          sx={{
            fontSize: '15px',
            lineHeight: '26px',
            letterSpacing: '0.46px',
          }}
          onClick={onClose}
        >
          Cancel
        </Button>
      </Box>
    </Box>
  );
};
