import MessagesLoading from './MessagesLoading';

export default MessagesLoading;
