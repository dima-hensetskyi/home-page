const stringToColor = (name: string) => {
  let hash = 0;
  let i;

  for (i = 0; i < name.length; i += 1) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }

  let color = '#';

  for (i = 0; i < 3; i += 1) {
    const value = (hash >> (i * 8)) & 0xff;
    color += `00${value.toString(16)}`.substr(-2);
  }

  return color;
};

type EmptyObject = {
  [K in any]: string;
};

const colors: EmptyObject = {};

export const getAvatarColor = (name: string) => {
  if (!name) return;
  const key = name as keyof typeof colors;

  if (colors[key]) return colors[key];

  const bgcolor = stringToColor(name);
  colors[key] = bgcolor;
  return bgcolor;
};

export const getNameInitial = (name: string): string => {
  const username = name.split(' ');
  const [firstName, lastName] = username;
  return [firstName, lastName].map((word) => word?.slice(0, 1).toUpperCase()).join('');
};
