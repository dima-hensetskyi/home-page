import StudentActivePreview from './StudentActivePreview';

export default StudentActivePreview;
