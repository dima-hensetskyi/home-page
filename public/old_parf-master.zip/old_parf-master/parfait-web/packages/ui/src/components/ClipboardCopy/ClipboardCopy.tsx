import React from 'react';
import styled from 'styled-components';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import { useSnackbar } from 'notistack';

const Button = styled.button`
  border: none;
  background: none;
  cursor: pointer;
  color: #1976d2;
`;

type Props = {
  text: string;
};

const ClipboardCopy = (props: Props) => {
  const { text } = props;
  const { enqueueSnackbar } = useSnackbar();
  return (
    <Button
      onClick={() => {
        navigator.clipboard.writeText(text);
        enqueueSnackbar('Copied to clipboard!', {
          variant: 'success',
        });
      }}
    >
      <ContentCopyIcon />
    </Button>
  );
};

export default ClipboardCopy;
