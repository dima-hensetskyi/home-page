import {
  Box,
  CircularProgress,
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material';
import React from 'react';

import { HeaderButton } from './HeaderButton';
import { isPrimitive, objectKeys, objectValues, TableProps } from './types';
import { NoData } from '../NoData';
import { Loader, StyledTableCell, StyledTableRow } from './TableComponent.styled';

function TableComponent<T extends object>({
  tableHeaders,
  tableCustomRenderers,
  tableDataItems,
  columnsWidth,
  isLoading,
  orderBy,
  sortedRows,
  sortOrder = 'ASC',
  onSortLabel,
  onMouseSortLabel,
  loading,
}: TableProps<T>) {
  const isNoData = tableDataItems.length === 0;

  return (
    <TableContainer
      sx={{
        boxShadow: 3,
        minWidth: '100%',
        my: '20px',
        display: 'flex',
        filter: 'dropShadow(0px 4px 5px rgba(0, 0, 0, 0.14)) dropShadow(0px 1px 10px rgba(0, 0, 0, 0.12))',
        minHeight: { xs: '356px', lg: '520px' },
        position: 'relative',
      }}
      component={Box}
    >
      {loading ? (
        <Loader>
          <CircularProgress size="40px" />
        </Loader>
      ) : null}
      <Table stickyHeader={true} sx={{ height: 'fit-content' }}>
        <TableHead>
          <TableRow>
            {objectValues(tableHeaders).map((headerLabel) => (
              <HeaderButton
                key={headerLabel}
                headerLabel={headerLabel}
                headersArray={tableHeaders}
                sortedRows={sortedRows || []}
                order={sortOrder}
                orderBy={orderBy || ''}
                onSortLabel={onSortLabel}
                onMouseSortLabel={onMouseSortLabel}
              />
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {isLoading || isNoData ? (
            <StyledTableRow>
              <StyledTableCell>
                {isLoading ? (
                  <Box
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      position: 'absolute',
                      inset: '0',
                    }}
                  >
                    <CircularProgress />
                  </Box>
                ) : (
                  <NoData sx={{ position: 'absolute', top: 100, left: 0, right: 0, mx: 'auto' }}></NoData>
                )}
              </StyledTableCell>
            </StyledTableRow>
          ) : (
            tableDataItems.map((item: T, idx: number) => {
              return (
                <StyledTableRow key={idx}>
                  {objectKeys(item).map((itemProperty, idx) => {
                    const customRenderer = tableCustomRenderers?.[itemProperty];
                    const columnWidth = columnsWidth?.[itemProperty];

                    if (customRenderer) {
                      return (
                        <StyledTableCell sx={{ py: { xs: '6px', lg: '16px' }, width: columnWidth }} key={idx}>
                          {customRenderer(item)}
                        </StyledTableCell>
                      );
                    }

                    if (tableHeaders[itemProperty]) {
                      return (
                        <StyledTableCell sx={{ py: { xs: '6px', lg: '16px' }, width: columnWidth }} key={idx}>
                          <Typography variant="body2">
                            <> {isPrimitive(item[itemProperty]) ? item[itemProperty] : ''}</>
                          </Typography>
                        </StyledTableCell>
                      );
                    }
                  })}
                </StyledTableRow>
              );
            })
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

export default TableComponent;
