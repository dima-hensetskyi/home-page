import React, { useEffect, useState } from 'react';
import { Typography } from '@mui/material';
import dayjs from 'dayjs';
import { Container, ImageBox, Heading, Title, Count, Time, Body, MessageText } from './styledComponents';
import { API } from 'aws-amplify';
import Observable from 'zen-observable-ts';
import { messageSubscription } from 'graphql/chatMessage';
import { Chat } from '../../../../../containers/messages/types';
import { Message } from '../../../../../containers/messages/types';
import { AvatarComponent } from '../../../../../Avatar';

type Props = {
  chat: Chat;
  active: boolean;
  onClick: (id: string) => void;
};

const ContactItem = (props: Props) => {
  const { chat, onClick, active } = props;

  const { user, chatMessagesContainer } = chat;
  const { id: chatId } = chat;
  const { items } = chatMessagesContainer;
  const [messages, setMessages] = useState(items);

  const todayDate = dayjs().format('DD.MM.YYYY');
  const resultDate = messages.length > 0 ? dayjs(messages[0].createdAt).format('DD.MM.YYYY') : null;

  const cutString = (content: string, length: number): string => {
    if (content.length > length) {
      return `${content.slice(0, length)}...`;
    }

    return content;
  };

  /**
   * Subscribe to new messages
   */
  useEffect(() => {
    const subscription = (
      API.graphql({
        query: messageSubscription,
        variables: {
          chatId,
        },
      }) as unknown as Observable<any>
    ).subscribe({
      next: (result) => {
        const { changedMessage } = result.value.data;

        setMessages((state) => {
          return [changedMessage, ...state];
        });
      },
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [chatId]);

  const getUserName = (message: Message) => {
    if (message.type === 'USER') {
      return message.user.displayName;
    }

    return message.tenantUser.displayName;
  };

  return (
    <Container
      style={{
        background: active ? '#EEF2FB' : 'transparent',
      }}
      onClick={() => {
        onClick(chat.id);
      }}
    >
      {user ? (
        <ImageBox>
          <AvatarComponent avatar={user.avatar} name={user.name} />
        </ImageBox>
      ) : null}
      <Body>
        <Heading>
          {user ? (
            <Title>
              <Typography variant="subtitle2">{user.name}</Typography>
            </Title>
          ) : null}
          {chat.unreadMessageCount ? <Count>{chat.unreadMessageCount}</Count> : null}
          {messages.length > 0 ? (
            <Time>
              <Typography
                variant="body2"
                sx={{
                  fontSize: 12,
                  color: '#606164',
                }}
              >
                {todayDate === resultDate
                  ? dayjs(messages[0].createdAt).format('hh:mm A')
                  : dayjs(messages[0].createdAt).format('MMM DD, YYYY')}
              </Typography>
            </Time>
          ) : null}
        </Heading>
        {items.length > 0 ? (
          <MessageText>
            <Typography
              variant="body2"
              sx={{
                fontSize: 12,
                color: '#606164',
              }}
            >
              {cutString(`${getUserName(messages[0])}: ${messages[0].content}`, 50)}
            </Typography>
          </MessageText>
        ) : null}
      </Body>
    </Container>
  );
};

export default ContactItem;
