import React, { useState } from 'react';
import { LinearProgress, Tooltip, IconButton, Alert, Stack } from '@mui/material';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import AuthHeader from '../AuthHeader';
import { Formik, Form, Field, FormikHelpers } from 'formik';
import { TextField as FormikTextField } from 'formik-mui';
import useAuthContext from '../../../containers/auth/useAuthContext';
import { confirmEmailSchema } from './validationSchema';
import { useSearchParams } from 'react-router-dom';
import { Container, Error, FormControlDivider, FormControlTooltipRow, TooltipWrapper } from '../styledComponents';
import Button from '../Button';

const ConfirmCollegeForm = () => {
  const { confirmCollegeAffiliation } = useAuthContext();

  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [searchParams] = useSearchParams();
  const institutionName = searchParams.get('institutionName');
  const tenantUserId = searchParams.get('tenantUserId');

  const initialValues = {
    linkedInUrl: '',
    staffProfileURL: '',
  };

  const onSubmit = async (values: typeof initialValues, { setSubmitting }: FormikHelpers<typeof initialValues>) => {
    if (values.linkedInUrl === '' && values.staffProfileURL === '') {
      setError('Please enter at least one valid url.');
      setSubmitting(false);
      return;
    }

    if (!tenantUserId) {
      setError('Page url is broken.');
      setSubmitting(false);
      return;
    }

    try {
      await confirmCollegeAffiliation(tenantUserId, values.linkedInUrl, values.staffProfileURL);
      setSubmitting(false);
      setSuccess(true);
    } catch (error) {
      setError('Unexpected error.');
      setSubmitting(false);
    }
  };

  return (
    <Container>
      {success ? (
        <AuthHeader
          title="Thank you!"
          description="We will email you within 24 hours, when your account is confirmed and ready to use."
        />
      ) : (
        <>
          <AuthHeader
            title="One last thing…"
            description={`Please provide one of the following to help us confirm your position with ${institutionName}`}
          />
          <Formik validationSchema={confirmEmailSchema} initialValues={initialValues} onSubmit={onSubmit}>
            {({ isSubmitting }) => (
              <Form>
                <Stack spacing={3}>
                  <Stack spacing={2}>
                    <Field
                      fullWidth
                      component={FormikTextField}
                      name="linkedInUrl"
                      label="LinkedIn Profile Url"
                      type="text"
                      placeholder="linkedin.com/in/you"
                    />
                    <FormControlDivider>or</FormControlDivider>
                    <FormControlTooltipRow>
                      <Field
                        fullWidth
                        component={FormikTextField}
                        name="staffProfileURL"
                        label="University Staff Profile URL"
                        type="text"
                      />
                      <TooltipWrapper>
                        <Tooltip
                          title="Any page of the school’s website in which you are mentioned as a current staff member or representative of
              the school"
                          arrow
                        >
                          <IconButton>
                            <InfoOutlinedIcon />
                          </IconButton>
                        </Tooltip>
                      </TooltipWrapper>
                    </FormControlTooltipRow>
                  </Stack>
                  {error && (
                    <Error>
                      <Alert severity="error">{error}</Alert>
                    </Error>
                  )}
                  <div>
                    {isSubmitting && <LinearProgress />}
                    <Button type="submit">Confirm</Button>
                  </div>
                </Stack>
              </Form>
            )}
          </Formik>
        </>
      )}
    </Container>
  );
};

export default ConfirmCollegeForm;
