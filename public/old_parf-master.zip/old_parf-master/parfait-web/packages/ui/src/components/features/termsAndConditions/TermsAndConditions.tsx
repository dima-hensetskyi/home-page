import { Box, Typography } from '@mui/material';
import { useTitle } from 'react-use';
import React from 'react';
import LogoIcon from '../../../icons/logo.svg';

import { LandingPageLayout } from '../../layouts';

export const TermsAndConditions: React.FC = () => {
  useTitle('Terms & Conditions | Parfait');
  return (
    <LandingPageLayout>
      <Box sx={{ display: 'flex', flexDirection: 'column', textAlign: 'center' }}>
        <Box sx={{ mt: '30px' }}>
          <LogoIcon />
        </Box>
        <Typography variant="h4">TERMS AND CONDITIONS</Typography>
        <Typography variant="subtitle1" sx={{ textAlign: 'justify', mt: '30px' }}></Typography>
      </Box>
    </LandingPageLayout>
  );
};
