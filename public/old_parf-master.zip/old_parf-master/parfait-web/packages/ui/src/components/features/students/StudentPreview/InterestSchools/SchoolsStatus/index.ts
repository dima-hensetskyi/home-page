import SchoolsStatus from './SchoolsStatus';

export default SchoolsStatus;
