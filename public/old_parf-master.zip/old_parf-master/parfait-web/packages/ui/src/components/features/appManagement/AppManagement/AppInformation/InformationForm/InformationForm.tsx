import React, { useMemo, useState } from 'react';
import { Field, Form, Formik, FormikHelpers } from 'formik';
import { Stack, Typography } from '@mui/material';
import { TextField as FormikTextField } from 'formik-mui';
import LoadingButton from '@mui/lab/LoadingButton';
import { API, graphqlOperation, Storage } from 'aws-amplify';
import { useQuery, useQueryClient } from 'react-query';
import { v4 as uuidv4 } from 'uuid';
import config from 'config/aws-config';
import { fetchCollegeFormInfo, updateCollegeFormInfo } from 'graphql/institutions';
import useAuthContext from '../../../../../containers/auth/useAuthContext';
import Image from '../../AppImages/Image';
import LeaveFormConfirmation from '../../../../../LeaveFormConfirmation';
import { CollegeFormInfo, FetchCollegeFormInfoResponse } from '../../../../../../types/institutions';
import CountrySelect from './CountrySelect';
import EditIcon from '../../AppImages/EditIcon';
import { useSnackbar } from 'notistack';
import AddIconModal from '../AddIconModal';
import { PrimaryIcon, PrimaryIconWrapper } from './styled-components';
import { FormValues } from './types';
import { validationSchema } from './validationSchema';
import { ImgPicker } from '../../styled-components';

const InformationForm = () => {
  const { user, tenant } = useAuthContext();
  const [image, setImage] = useState<File | null>(null);
  const queryClient = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();

  const { institutionId } = tenant!;

  const { data: collegeInfo } = useQuery<CollegeFormInfo>(['fetchCollegeFormInfo', institutionId], async () => {
    const result = (await API.graphql(
      graphqlOperation(fetchCollegeFormInfo, {
        id: institutionId,
      }),
    )) as FetchCollegeFormInfoResponse;

    return result.data.collegeInfo;
  });

  const onSubmit = async (values: FormValues, { resetForm }: FormikHelpers<FormValues>) => {
    if (!user) return;

    const input: { [key: string]: any } = {
      name: values.name,
      schoolURL: values.schoolURL,
      address: {
        address1: values.address1,
        address2: values.address2,
        stateProvince: values.stateProvince,
        country: values.country,
        postalCode: values.postalCode,
        alphaTwoCode: values.alphaTwoCode,
        city: values.city,
      },
    };

    let s3object;

    if (image) {
      const key = `tenants/${user.pool.storage.identityPoolId!}/${uuidv4()}-${image.name}`;

      const imageUploadResult = await Storage.put(key, image, {
        contentType: image.type,
        level: 'public',
      });

      s3object = {
        bucket: config.s3.BUCKET,
        region: config.s3.REGION,
        key: imageUploadResult.key,
        accessLevel: 'PUBLIC',
      };
    }

    if (s3object) {
      input.primaryIcon = s3object;
    }

    try {
      const result = (await API.graphql(
        graphqlOperation(updateCollegeFormInfo, {
          input,
        }),
      )) as FetchCollegeFormInfoResponse;

      queryClient.setQueryData(['fetchCollegeFormInfo', institutionId], result.data.collegeInfo);

      enqueueSnackbar('Changes successfully published!', {
        variant: 'success',
      });
    } catch {
      enqueueSnackbar('Unexpected error while saving changes!', {
        variant: 'error',
      });
    }

    resetForm();
  };

  const initialValues: FormValues = useMemo(() => {
    return collegeInfo
      ? {
          name: collegeInfo.name || '',
          schoolURL: collegeInfo.schoolURL || '',
          address1: collegeInfo.address.address1 || '',
          address2: collegeInfo.address.address2 || '',
          city: collegeInfo.address.city || '',
          stateProvince: collegeInfo.address.stateProvince || '',
          postalCode: collegeInfo.address.postalCode || '',
          country: collegeInfo.address.country || '',
          alphaTwoCode: collegeInfo.address.alphaTwoCode || '',
        }
      : {
          name: '',
          schoolURL: '',
          address1: '',
          address2: '',
          city: '',
          stateProvince: '',
          postalCode: '',
          country: '',
          alphaTwoCode: '',
        };
  }, [collegeInfo]);

  return (
    <Formik validationSchema={validationSchema} enableReinitialize initialValues={initialValues} onSubmit={onSubmit}>
      {({ submitForm, isSubmitting }) => (
        <Form>
          <LeaveFormConfirmation />
          <Stack spacing={2}>
            <Stack spacing={2}>
              <Field fullWidth component={FormikTextField} name="name" label="School Name" type="text" size="small" />
              <Field
                fullWidth
                component={FormikTextField}
                name="schoolURL"
                label="School Web Address"
                type="text"
                size="small"
              />
            </Stack>
            <Typography variant="subtitle2" gutterBottom component="div">
              Address
            </Typography>
            <Stack spacing={2}>
              <Field fullWidth component={FormikTextField} name="address1" label="Address 1" type="text" size="small" />
              <Field fullWidth component={FormikTextField} name="address2" label="Address 2" type="text" size="small" />
              <Field fullWidth component={FormikTextField} name="city" label="City" type="text" size="small" />
              <Stack direction="row" spacing={1}>
                <Field
                  fullWidth
                  component={FormikTextField}
                  name="stateProvince"
                  label="State"
                  type="text"
                  size="small"
                />
                <Field
                  fullWidth
                  component={FormikTextField}
                  name="postalCode"
                  label="Zip Code"
                  type="text"
                  size="small"
                />
              </Stack>
              <CountrySelect />
            </Stack>
            <Typography
              variant="subtitle2"
              sx={{
                mt: 3,
                mb: 2,
              }}
              component="div"
            >
              Primary icon
            </Typography>
            <PrimaryIconWrapper>
              <PrimaryIcon>
                {image ? (
                  <img src={URL.createObjectURL(image)} alt="CellImage" />
                ) : (
                  <>
                    {collegeInfo && collegeInfo.primaryIcon ? (
                      <Stack sx={{ maxHeight: '126px' }}>
                        <Image image={collegeInfo.primaryIcon} />
                      </Stack>
                    ) : (
                      <Typography variant="body2" gutterBottom>
                        Select icon
                      </Typography>
                    )}
                  </>
                )}
                <ImgPicker>
                  <AddIconModal
                    onAdd={(file) => {
                      setImage(file);
                    }}
                  >
                    <EditIcon />
                  </AddIconModal>
                </ImgPicker>
              </PrimaryIcon>
            </PrimaryIconWrapper>
            <div>
              <LoadingButton
                sx={{ minWidth: '108px', minHeight: '42px' }}
                variant="contained"
                onClick={submitForm}
                loading={isSubmitting}
              >
                Publish
              </LoadingButton>
            </div>
          </Stack>
        </Form>
      )}
    </Formik>
  );
};

export default InformationForm;
