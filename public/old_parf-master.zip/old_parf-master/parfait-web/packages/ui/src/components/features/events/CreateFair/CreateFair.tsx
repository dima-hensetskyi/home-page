import { API, graphqlOperation } from 'aws-amplify';
import { Box, Button, Typography } from '@mui/material';
import { useQueryClient } from 'react-query';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useState } from 'react';

import FairForm from '../FairForm';
import { FormValues } from '../FairForm/types';
import { createFair } from 'graphql/events';
import { SmallDialog } from '../../../Dialog';

type Props = {
  visible: boolean;
  onClose: () => void;
};

const CreateFair = (props: Props) => {
  const { visible, onClose } = props;
  const [loading, setLoading] = useState(false);

  const queryClient = useQueryClient();

  const onSubmit = async (values: FormValues, startDate: string, endDate: string) => {
    setLoading(true);

    await API.graphql(
      graphqlOperation(createFair, {
        input: {
          inviteType: values.inviteType,
          name: values.name,
          status: values.status,
          startDateAndTime: startDate,
          endDateAndTime: endDate,
          description: values.description,
          note: values.note,
          organizerTenantUserId: values.organizerTenantUserId,
          locationName: values.locationName,
          address: {
            address1: values.address1,
            address2: values.address2,
            stateProvince: values.stateProvince,
            postalCode: values.postalCode,
            city: values.city,
            country: 'United States of America',
            alphaTwoCode: 'US',
          },
          //organizerTenantUserId: values.expectedAttendees,
          expectedAttendees: values.expectedAttendees,
          fee: values.fee,
        },
      }),
    );

    queryClient.invalidateQueries('getEvents');

    setLoading(false);
    onClose();
  };

  const initialValues: FormValues = {
    name: '',

    status: 'REGISTRATION_ACTIVE',
    date: '',
    startTime: '',
    endTime: '',
    inviteType: 'OPEN',

    organizerTenantUserId: '',
    fee: null,

    address1: '',
    address2: '',
    city: '',
    stateProvince: '',
    postalCode: '',
    expectedAttendees: null,

    locationName: '',

    description: '',
    note: '',
  };

  return (
    <SmallDialog
      content={
        <div>
          <Typography
            variant="h6"
            sx={{
              mb: 2.5,
            }}
          >
            Create college fair
          </Typography>
          <FairForm initialValues={initialValues} onSubmit={onSubmit} type="create" />
        </div>
      }
      open={visible}
      lgWidth="736px"
      xlWidth="810px"
      close={() => {
        onClose();
      }}
      headerButton={
        <Box sx={{ display: 'flex', gap: '8px' }}>
          <LoadingButton form="fair-form" variant="contained" type="submit" loading={loading}>
            Create
          </LoadingButton>
          <Button variant="outlined" onClick={onClose}>
            Cancel
          </Button>
        </Box>
      }
    />
  );
};

export default CreateFair;
