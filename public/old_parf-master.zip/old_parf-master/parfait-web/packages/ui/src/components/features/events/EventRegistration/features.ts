const features = [
  'Scan students’ QR codes during college fairs',
  'Manage your new prospects from fairs',
  'Assign staff team members to fairs for which you are registered',
  'Receive notifications on changes to fairs',
  'Message recruits directly through the Parfait Student App',
  'Find a new source for prospects with the Parfait Student App',
];

export default features;
