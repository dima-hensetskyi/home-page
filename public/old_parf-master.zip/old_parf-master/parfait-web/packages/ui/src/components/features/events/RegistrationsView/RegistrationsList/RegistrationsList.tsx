import { API } from 'aws-amplify';
import { Box } from '@mui/material';
import { useInfiniteQuery } from 'react-query';
import CircularProgress from '@mui/material/CircularProgress';
import LoadingButton from '@mui/lab/LoadingButton';
import React from 'react';
import styled from 'styled-components';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';

import { NoData } from '../../../../NoData';

const Wrapper = styled.div`
  tr:nth-of-type(even) td {
    background-color: #f5f5f5;
  }
`;

const ColumnStyle = {
  paddingTop: 0.75,
  paddingBottom: 0.75,
  overflow: 'hidden',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
};

type Props = {
  eventId: string;
};

const getEventRegistrations = /* GraphQL */ `
  query getEventRegistrations($eventId: ID!, $sortDirection: ModelSortDirection, $limit: Int, $nextToken: String) {
    registrations: getEventRegistrations(
      eventId: $eventId
      sortDirection: $sortDirection
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        id
        eventId
        status
        createdAt
        updatedAt
        ... on EventRegistrationByForm {
          registeredName
          registeredEmail
          registeredInstitutionName
        }
      }
      nextToken
    }
  }
`;

type EventRegistration = {
  id: string;
  eventId: string;
  status: 'CONFIRMED' | 'CANCELLED';
  createdAt: string;
  updatedAt: string;
  registeredEmail: string;
  registeredName: string;
  registeredInstitutionName: string;
};

type GetEventRegistrations = {
  data: {
    registrations: {
      items: Array<EventRegistration>;
      nextToken: null | string;
    };
  };
};

const columns = [
  { id: 'email', label: 'Email' },
  { id: 'name', label: 'Name' },
  { id: 'college', label: 'College' },
];

const RegistrationsList = (props: Props) => {
  const { eventId } = props;

  const { data, isFetching, isLoading, hasNextPage, fetchNextPage } = useInfiniteQuery(
    ['getEventRegistrations', eventId],
    async (data) => {
      const result = (await API.graphql({
        query: getEventRegistrations,
        variables: {
          eventId: eventId,
          nextToken: data.pageParam,
          limit: 16,
        },
      })) as GetEventRegistrations;

      return result.data.registrations;
    },
    {
      keepPreviousData: true,
      retry: false,
      getNextPageParam: (lastPage) => lastPage?.nextToken,
    },
  );

  const pages = data?.pages || [];
  const eventInvites = pages.map((page) => page?.items || []).flat(1);

  return isLoading ? (
    <Box sx={{ display: 'flex', justifyContent: 'center' }}>
      <CircularProgress size="20px" />
    </Box>
  ) : (
    <Wrapper>
      <TableContainer sx={{ maxHeight: 'calc(100vh - 310px)', mb: 2.5 }}>
        <Table
          stickyHeader
          aria-label="sticky table"
          sx={{
            border: '1px solid #e0e0e0',
          }}
        >
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell
                  key={column.id}
                  align="left"
                  sx={{
                    background: '#e0e0e0',
                    paddingTop: 0.5,
                    paddingBottom: 0.5,
                  }}
                >
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {eventInvites && eventInvites.length > 0 ? (
              eventInvites.map((record) => {
                return (
                  <TableRow key={record.id}>
                    <TableCell key="email" align="left" sx={{ ...ColumnStyle, maxWidth: '318px' }}>
                      {record.registeredEmail}
                    </TableCell>
                    <TableCell key="name" align="left" sx={{ ...ColumnStyle, maxWidth: '200px' }}>
                      {record.registeredName}
                    </TableCell>
                    <TableCell key="college" align="left" sx={{ ...ColumnStyle, maxWidth: '248px' }}>
                      {record.registeredInstitutionName}
                    </TableCell>
                  </TableRow>
                );
              })
            ) : (
              <TableRow>
                <TableCell colSpan={4}>
                  <NoData
                    sx={{
                      width: '100%',
                    }}
                  />
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', visibility: hasNextPage ? 'visible' : 'hidden' }}>
        <LoadingButton
          loading={isFetching}
          sx={{
            fontSize: '15px',
            lineHeight: '26px',
            letterSpacing: '0.46px',
          }}
          variant="contained"
          onClick={() => fetchNextPage()}
        >
          SHOW MORE
        </LoadingButton>
      </Box>
    </Wrapper>
  );
};

export default RegistrationsList;
