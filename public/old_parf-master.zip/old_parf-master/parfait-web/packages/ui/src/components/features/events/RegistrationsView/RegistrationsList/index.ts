import RegistrationsList from './RegistrationsList';

export default RegistrationsList;
