import ConfirmCollegeForm from './ConfirmCollegeForm';

export default ConfirmCollegeForm;
