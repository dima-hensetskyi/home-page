import InvitesForm from './InvitesForm';

export default InvitesForm;
