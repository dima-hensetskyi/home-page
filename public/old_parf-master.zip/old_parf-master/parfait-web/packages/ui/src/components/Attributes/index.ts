import Attributes from './Attributes';

export default Attributes;
