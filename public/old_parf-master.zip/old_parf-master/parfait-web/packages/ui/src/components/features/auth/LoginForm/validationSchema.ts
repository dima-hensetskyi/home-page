import * as Yup from 'yup';

const signInValidationSchema = Yup.object().shape({
  account: Yup.string().required('School Account is required.').nullable(),
  username: Yup.string().required('Username is required.').nullable(),
  password: Yup.string().required('Password is required.').nullable(),
});

export default signInValidationSchema;
