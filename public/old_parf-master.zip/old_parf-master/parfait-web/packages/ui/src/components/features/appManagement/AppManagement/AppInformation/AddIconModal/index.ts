import AddIconModal from './AddIconModal';

export default AddIconModal;
