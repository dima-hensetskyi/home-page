import { Box, Dialog, DialogContent, IconButton, SxProps, Theme, Typography } from '@mui/material';
import React from 'react';
import { createPortal } from 'react-dom';
import CloseIcon from '@mui/icons-material/Close';

type PropsType = {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  paperSx?: SxProps<Theme>;
  titleBoxSx?: SxProps<Theme>;
  bodySx?: SxProps<Theme>;
};

export const BasicDialog: React.FC<PropsType> = ({
  open,
  onClose,
  title,
  children,
  paperSx,
  titleBoxSx,
  bodySx,
}: PropsType) => {
  if (!open) return null;

  const DialogDom = (
    <Dialog PaperProps={{ sx: paperSx }} onClose={onClose} open={open}>
      <Box sx={titleBoxSx}>
        {title && <Typography variant="h6">{title}</Typography>}
        {onClose ? (
          <IconButton
            aria-label="close"
            onClick={onClose}
            sx={{
              position: 'absolute',
              right: '28px',
              top: '28px',
              color: (theme) => theme.palette.grey[500],
            }}
          >
            <CloseIcon />
          </IconButton>
        ) : null}
      </Box>
      <DialogContent sx={bodySx}>{children}</DialogContent>
    </Dialog>
  );

  const target = document.body;
  return createPortal(DialogDom, target);
};
