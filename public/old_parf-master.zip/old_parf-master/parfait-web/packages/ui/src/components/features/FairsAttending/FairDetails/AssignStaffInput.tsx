import {
  Box,
  Chip,
  CircularProgress,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  SelectChangeEvent,
} from '@mui/material';
import CancelIcon from '@mui/icons-material/Cancel';
import React from 'react';

import { EventRegistrationAssignmentsType } from '../../../../types/events';
import { FairsAttendingItemType } from '../types';
import { getScrollBottom } from '../../utils';
import { useAssignStaff, useCreateAssignStaff, useTenantUsers, useDeleteAssignStaff } from '../hooks';

type PropsType = {
  staffAssigned: EventRegistrationAssignmentsType[];
  activeFair: FairsAttendingItemType;
};

export const AssignStaffInput: React.FC<PropsType> = ({ staffAssigned, activeFair }: PropsType) => {
  const tenantUsers = useTenantUsers({ sortDirection: 'ASC', limit: 10 });
  const tenantUsersList = tenantUsers.data?.pages.map((page) => page?.items || []).flat(1) || [];

  const AssignStaff = useAssignStaff(activeFair.id, staffAssigned);
  const addStaff = useCreateAssignStaff(activeFair.id, tenantUsersList);
  const removeStaff = useDeleteAssignStaff(activeFair.id);
  const staff = AssignStaff.data?.items || [];

  const staffList = staff.map((user) => user.tenantUser.id);

  const onChange = (evt: SelectChangeEvent<string[]>) => {
    const arr = evt.target.value;

    if (arr.length > staffList.length) {
      const val = arr[arr.length - 1] as string;
      addStaff.mutateAsync({ input: { eventRegistrationId: activeFair.id, tenantUserId: val } });
    } else {
      if (Array.isArray(arr)) {
        const removedEmployee = staffList.filter((employeeId) => !arr.includes(employeeId))[0];
        if (removedEmployee)
          removeStaff.mutate({ input: { eventRegistrationId: activeFair.id, tenantUserId: removedEmployee } });
      }
    }
  };

  const onScroll = (evt: React.UIEvent<HTMLDivElement>) => {
    const isFetchMore = getScrollBottom(evt);
    if (isFetchMore && tenantUsers.hasNextPage && !tenantUsers.isFetching) {
      //user is at the end of the list so load more items
      tenantUsers.fetchNextPage();
    }
  };

  return (
    <FormControl fullWidth size="small">
      <InputLabel id="Status">Staff</InputLabel>
      <Select
        multiple
        labelId="Staff"
        label="Staff"
        value={staffList}
        sx={{
          '& .MuiSelect-select': {
            maxHeight: '125px !important',
            minHeight: '56px',
            overflowY: 'auto !important',
            py: '12px',
          },
        }}
        MenuProps={{
          PaperProps: {
            onScroll,
          },
          style: {
            maxHeight: 220,
          },
        }}
        onChange={onChange}
        renderValue={() => (
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: '8px', maxWidth: '425px' }}>
            {staff.map((user) => {
              const { id, name } = user.tenantUser;
              return (
                <Chip
                  key={user.eventRegistrationId + id}
                  label={name}
                  clickable
                  deleteIcon={<CancelIcon onMouseDown={(evt) => evt.stopPropagation()} />}
                  onDelete={() =>
                    removeStaff.mutate({ input: { eventRegistrationId: activeFair.id, tenantUserId: id } })
                  }
                />
              );
            })}
          </Box>
        )}
      >
        {tenantUsersList.map((user) => (
          <MenuItem key={user.id} value={user.id}>
            {user.name}
          </MenuItem>
        ))}
        {tenantUsers.isFetching && (
          <Box sx={{ display: 'flex', justifyContent: 'center', width: '100%' }}>
            <CircularProgress sx={{ width: '20px !important', height: '20px !important' }} />
          </Box>
        )}
      </Select>
    </FormControl>
  );
};
