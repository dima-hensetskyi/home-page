import React, { useState } from 'react';
import TableTopControlPanel from '../../../components/Table/TableTopControlPanel';
import { Button } from '@mui/material';
import StudentsList from './StudentsList';
import CreateStudent from './CreateStudent';
import StudentsSearch from './StudentsSearch';
import StudentsFilter from './StudentsFilter';
import { FilterValue } from './types';

const Students = () => {
  const [createStudentDialogOpen, setCreateStudentDialogOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<FilterValue>({
    year: [],
  });

  return (
    <div>
      <TableTopControlPanel title="Students">
        <StudentsFilter filter={filter} setFilter={setFilter} />
        <StudentsSearch
          onChangeSearch={(value) => {
            setSearch(value);
          }}
        />
        <Button
          size="large"
          variant="contained"
          onClick={() => {
            setCreateStudentDialogOpen(true);
          }}
        >
          Add Student
        </Button>
      </TableTopControlPanel>
      <StudentsList search={search} filter={filter} />
      <CreateStudent
        visible={createStudentDialogOpen}
        onClose={() => {
          setCreateStudentDialogOpen(false);
        }}
      />
    </div>
  );
};

export default Students;
