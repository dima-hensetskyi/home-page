export type FairInviteType = 'OPEN' | 'INVITE_ONLY';

export type FormValues = {
  name: string;

  status: string;
  date: string;
  startTime: string;
  endTime: string;
  inviteType: FairInviteType;

  organizerTenantUserId: string;
  fee: null | number;

  address1: string;
  address2: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  expectedAttendees: null | number;

  locationName: string;

  description: string;
  note: string;
};
