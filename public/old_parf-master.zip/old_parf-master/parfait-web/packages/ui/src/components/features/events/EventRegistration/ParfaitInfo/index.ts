import ParfaitInfo from './ParfaitInfo';

export default ParfaitInfo;
