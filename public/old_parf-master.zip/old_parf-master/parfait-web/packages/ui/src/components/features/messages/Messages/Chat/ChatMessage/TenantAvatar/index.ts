import TenantAvatar from './TenantAvatar';

export default TenantAvatar;
