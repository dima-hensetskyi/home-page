import * as Yup from 'yup';
import dayjs from 'dayjs';

const checkTime = (time: string | undefined) => dayjs(time, 'HH:mm').isValid();
const isTimeBefore = (firstTime: string, secondTime: string) =>
  dayjs(firstTime, 'HH:mm').isBefore(dayjs(secondTime, 'HH:mm'));
const checkDate = (date: string) => dayjs(date, 'YYYY-MM-DD').isValid();
const isDateAfterToday = (date: string) => dayjs(date, 'YYYY-MM-DD').isAfter(dayjs());

export const validationSchema = Yup.object().shape({
  name: Yup.string()
    .required('Please enter a Fair Name.')
    .max(100, 'Field has a maximum limit of 100 characters.')
    .nullable(),
  date: Yup.string()
    .required('Please enter a date.')
    .test('checkDate', 'Invalid date', (date) => (date ? checkDate(date) : false))
    .test('isDateAfterToday', 'Invalid date', (date) =>
      date && date !== dayjs().format('YYYY-MM-DD') ? isDateAfterToday(date) : true,
    )
    .nullable(),
  startTime: Yup.string()
    .required('Please enter a start time.')
    .test('checkTime', 'Invalid start time', (date) => (date ? checkTime(date) : false))
    .test('checkStartTimeDuration', 'Invalid time', (date, { parent }) =>
      date && parent['endTime'] && checkTime(parent['endTime'])
        ? isTimeBefore(date, parent['endTime'] as string)
        : true,
    )
    .nullable(),
  endTime: Yup.string()
    .required('Please enter an end time.')
    .test('checkTime', 'Invalid end time', (date) => (date ? checkTime(date) : false))
    .test('checkEndTimeDuration', 'Invalid time', (date, { parent }) =>
      date && parent['startTime'] && checkTime(parent['startTime'])
        ? isTimeBefore(parent['startTime'] as string, date)
        : true,
    )
    .nullable(),
  organizerTenantUserId: Yup.string().required('Please enter a staff member.').nullable(),

  address1: Yup.string().required('Please enter a address.').nullable(),
  city: Yup.string().required('Please enter a staff member.').nullable(),
  stateProvince: Yup.string().required('Please enter a state.').nullable(),
  postalCode: Yup.string().required('Please enter a postal Code.').nullable(),

  locationName: Yup.string().max(250, 'Field has a maximum limit of 250 characters.').nullable(),

  description: Yup.string()
    .max(500, 'Field has a maximum limit of 500 characters.')
    .required('Please enter a description.')
    .nullable(),
  note: Yup.string().max(250, 'Field has a maximum limit of 250 characters.').nullable(),
});
