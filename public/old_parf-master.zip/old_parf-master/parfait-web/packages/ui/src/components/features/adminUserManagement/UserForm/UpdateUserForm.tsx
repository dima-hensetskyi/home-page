import { diff } from 'deep-object-diff';
import { useMutation, useQueryClient } from 'react-query';
import React from 'react';
import { useSnackbar } from 'notistack';

import { TenantUsersRequestVariablesType, UserListItem } from '../type';
import { unmaskPhoneNumber } from '../utils';
import { UpdateTenantUser } from '../api';
import { userFormVariablesType, UserForm } from './UserForm';
import { Loader } from '../../../Loader';
import { AuthenticatedTenantUserResponse } from '../../../../types/tenant';

type TypeProps = {
  user: UserListItem | null;
  onClose: () => void;
  queryId: (string | TenantUsersRequestVariablesType)[];
};

export const UpdateUserForm: React.FC<TypeProps> = ({ user, onClose, queryId }: TypeProps) => {
  if (!user) return null;
  const { status, role, id, fullDetail } = user;
  const { givenName, familyName, avatar, username, email, phoneNumber } = fullDetail;
  const queryClient = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();
  const tenantUser = queryClient.getQueryData<AuthenticatedTenantUserResponse>('AuthenticatedTenantUser');

  const initialFormValues = {
    givenName,
    familyName,
    username,
    email: email || '',
    phoneNumber: phoneNumber ? phoneNumber.replace('+1', '') : '',
    status: status || '',
    role: role || '',
  };

  const updateUser = useMutation(UpdateTenantUser, {
    onError: () => {
      enqueueSnackbar('Something went wrong!', {
        variant: 'error',
      });
    },
    onSuccess: () => {
      enqueueSnackbar('User successfully updated!', {
        variant: 'success',
      });
      onClose();
    },
    onSettled: (data) => {
      if (data?.updateTenantUser.id === tenantUser?.getAuthenticatedTenantUser.id) {
        queryClient.invalidateQueries('AuthenticatedTenantUser');
      }
      queryClient.invalidateQueries(queryId);
    },
  });

  const onSubmit = (values: userFormVariablesType) => {
    let requestObj = diff(initialFormValues, values);

    if (Object.keys(requestObj).length) {
      if ('phoneNumber' in requestObj) {
        requestObj = unmaskPhoneNumber(requestObj);
      }

      const newVariables = { input: { id, ...requestObj } };
      updateUser.mutateAsync(newVariables);
    }
  };

  return updateUser.isLoading ? (
    <Loader />
  ) : (
    <UserForm
      type="Update"
      avatar={avatar}
      onClose={onClose}
      onSubmit={onSubmit}
      initialFormValues={initialFormValues}
    />
  );
};
