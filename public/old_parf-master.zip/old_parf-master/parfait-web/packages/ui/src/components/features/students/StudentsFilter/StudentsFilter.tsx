import React, { useState } from 'react';
import { Button, Stack, FormControl, InputLabel, MenuItem, SelectChangeEvent, Select } from '@mui/material';
import { FilterMenu } from '../../../Table';
import { FilterValue } from '../types';

type Props = {
  filter: FilterValue;
  setFilter: (value: FilterValue) => void;
};

const years = [
  '1990',
  '1991',
  '1992',
  '1993',
  '1994',
  '1995',
  '1996',
  '1997',
  '1998',
  '1999',
  '2000',
  '2001',
  '2002',
  '2003',
  '2004',
  '2005',
  '2006',
  '2007',
  '2008',
  '2009',
  '2010',
  '2011',
  '2012',
  '2013',
  '2014',
  '2015',
  '2016',
  '2017',
  '2018',
  '2019',
  '2020',
  '2021',
  '2022',
];

const StudentsFilter = (props: Props) => {
  const { setFilter } = props;

  const [isMenuOpen, setMenuOpen] = useState(false);
  const [value, setValue] = useState<Array<string>>([]);

  const onClear = () => {
    setFilter({ year: [] });
    setMenuOpen(false);
    setValue([]);
  };

  const onSubmit = () => {
    setFilter({ year: value });
    setMenuOpen(false);
  };

  const isFiltering = true;

  return (
    <FilterMenu isMenuOpen={isMenuOpen} setMenuOpen={setMenuOpen}>
      <Stack spacing={2}>
        <FormControl fullWidth size="small">
          <InputLabel id="demo-simple-select-label">Year</InputLabel>
          <Select
            multiple
            size="small"
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            // @ts-ignore
            value={value}
            label="Year"
            onChange={(event: SelectChangeEvent) => {
              const {
                target: { value },
              } = event;
              setValue(typeof value === 'string' ? value.split(',') : value);
            }}
          >
            {years.map((year) => {
              return (
                <MenuItem value={year} key={year}>
                  {year}
                </MenuItem>
              );
            })}
          </Select>
        </FormControl>
        <Button
          variant="contained"
          fullWidth
          disabled={!isFiltering}
          sx={{
            background: '#1976D2',
            marginBottom: '15px',
            fontSize: '13px',
            lineHeight: '22px',
            letterSpacing: '0.46px',
          }}
          onClick={onSubmit}
        >
          apply filter
        </Button>
        <Button
          variant="outlined"
          fullWidth
          onClick={onClear}
          sx={{
            color: '#1976D2',
            fontSize: '13px',
            lineHeight: '22px',
            letterSpacing: '0.46px',
          }}
        >
          Clear all
        </Button>
      </Stack>
    </FilterMenu>
  );
};

export default StudentsFilter;
