import React, { useState } from 'react';

import { EventRegistrationsByTenantInputType } from '../../../types/events';
import { FairDetails } from './FairDetails';
import { FairsAttendingContext } from './FairsAttendingContext';
import { FairsAttendingItemType } from './types';
import { FairsAttendingTable } from './FairsAttendingTable';
import { filterVariables } from './utils';

const initialVars = { limit: 10, sortDirection: 'DESC' as const };

export const FairsAttendingContainer = () => {
  const [reqVars, setReqVars] = useState<EventRegistrationsByTenantInputType>(initialVars);
  const [activeFair, setActiveFair] = useState<null | FairsAttendingItemType>(null);

  const onClearReqVars = (deleteVariables: 'filter' | 'search') => {
    if (reqVars?.filter) {
      const { filter } = reqVars;

      const newVars = filterVariables(deleteVariables, filter);
      const isEmpty = !Object.keys(newVars).length;

      if (!isEmpty) {
        setReqVars({ ...reqVars, filter: { ...newVars } });
      } else {
        const vars = { ...reqVars };
        delete vars.filter;
        setReqVars(vars);
      }
    }
  };

  const onReqVarsChange = (newVars: EventRegistrationsByTenantInputType) => setReqVars(newVars);
  const onActiveFairChange = (newVal: FairsAttendingItemType | null) => setActiveFair(newVal);

  return (
    <FairsAttendingContext.Provider value={{ setReqVars: onReqVarsChange, reqVars, onClearReqVars }}>
      <FairsAttendingTable onActiveFairChange={onActiveFairChange} />
      <FairDetails activeFair={activeFair} isOpen={!!activeFair} onClose={() => setActiveFair(null)} />
    </FairsAttendingContext.Provider>
  );
};
