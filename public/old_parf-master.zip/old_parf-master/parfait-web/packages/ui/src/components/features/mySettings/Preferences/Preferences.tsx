import { Box, Button, FormControlLabel, Grid, Radio, RadioGroup, Stack, Typography } from '@mui/material';
import { useSnackbar } from 'notistack';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useState } from 'react';

import { CheckBox } from './CheckBox';
import { TenantUser } from '../../../../types/tenant';
import { UpdateTenantUserPreference } from '../api';
import { useMutation, useQueryClient } from 'react-query';

type PropsType = {
  onClose: () => void;
  authenticatedUser: TenantUser | undefined;
};

const notificationPreferences = ['newChatMessage', 'onlyChatMessageThread', 'eventNotification'];

export const Preferences: React.FC<PropsType> = ({ onClose, authenticatedUser }: PropsType) => {
  if (!authenticatedUser) return null;
  const [preferences, setPreferences] = useState(authenticatedUser.preferences);
  const [notificationPreference, setNotificationPreference] = useState(
    authenticatedUser.preferences.newChatMessage ? 'newChatMessage' : 'onlyChatMessageThread',
  );

  const { id } = authenticatedUser;
  const { enqueueSnackbar } = useSnackbar();
  const queryClient = useQueryClient();

  const { isLoading, mutateAsync } = useMutation(UpdateTenantUserPreference, {
    onError: () => {
      enqueueSnackbar('Something went wrong!', {
        variant: 'error',
      });
    },
    onSuccess: () => {
      enqueueSnackbar('Preference successfully updated!', {
        variant: 'success',
      });
    },
    onSettled: () => {
      queryClient.invalidateQueries('AuthenticatedTenantUser');
    },
  });

  const handleChange = (evt: React.ChangeEvent<HTMLInputElement>) => {
    setPreferences({ ...preferences, [evt.target.name]: evt.target.checked });
  };

  const onNotificationPreferencesChange = (evt: React.ChangeEvent<HTMLInputElement>) => {
    const newPreference = evt.target.value;
    const newPreferences = { ...preferences };
    notificationPreferences.forEach((val) => {
      newPreferences[val as keyof typeof newPreferences] = val === newPreference;
    });

    setNotificationPreference(newPreference);
    setPreferences(newPreferences);
  };

  return (
    <Stack sx={{ justifyContent: 'space-between' }}>
      <Grid>
        <Typography variant="subtitle1">Communication preferences</Typography>
        <CheckBox
          label="Subscribe to Parfait news and Marketing emails."
          name="subscribeNews"
          onChange={handleChange}
          value={preferences.subscribeNews}
        />
      </Grid>
      <Grid sx={{ mt: '16px', gap: '8px', display: 'grid' }}>
        <Typography variant="subtitle1">Notification preferences</Typography>
        <RadioGroup
          aria-labelledby="demo-controlled-radio-buttons-group"
          name="controlled-radio-buttons-group"
          sx={{ display: 'grid', gap: '8px' }}
          value={notificationPreference}
          onChange={onNotificationPreferencesChange}
        >
          {/* <FormControlLabel
            sx={{ alignItems: 'flex-start' }}
            value="eventNotification"
            control={<Radio size="small" sx={{ p: '0', mx: '9px' }} />}
            label={<Typography variant="body2">Email me when I receive a College Fair notification</Typography>}
          /> */}
          <FormControlLabel
            sx={{ alignItems: 'flex-start' }}
            value="newChatMessage"
            control={<Radio size="small" sx={{ p: '0', mx: '9px' }} />}
            label={<Typography variant="body2">Send email notifications for all new chat messages.</Typography>}
          />
          <FormControlLabel
            sx={{ alignItems: 'flex-start' }}
            value="onlyChatMessageThread"
            control={<Radio size="small" sx={{ p: '0', mx: '9px' }} />}
            label={
              <Typography variant="body2">
                Send email notifications only when there is a new message on a chat thread I have replied on.
              </Typography>
            }
          />
        </RadioGroup>
      </Grid>
      <Box sx={{ display: 'flex', gap: '8px', mt: '24px' }}>
        <LoadingButton
          loading={isLoading}
          size="large"
          variant="contained"
          onClick={() => mutateAsync({ input: { ...preferences, id } })}
          sx={{
            fontSize: '15px',
            lineHeight: '26px',
            letterSpacing: '0.46px',
          }}
        >
          Save Changes
        </LoadingButton>
        <Button
          size="large"
          variant="outlined"
          onClick={onClose}
          sx={{
            fontSize: '15px',
            lineHeight: '26px',
            letterSpacing: '0.46px',
          }}
        >
          Cancel
        </Button>
      </Box>
    </Stack>
  );
};
