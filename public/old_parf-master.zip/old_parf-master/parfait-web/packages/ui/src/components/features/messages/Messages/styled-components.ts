import styled from 'styled-components';

export const Container = styled.div``;

export const Row = styled.div`
  display: flex;
  flex-direction: row;
`;

export const ColChatList = styled.div`
  width: 280px;
  margin-right: 16px;
`;
export const ColChatMessages = styled.div`
  flex: 1;
  margin-right: 32px;
`;
export const ColChatUserInfo = styled.div`
  max-width: 324px;
  flex: 1;
`;
