import { useMutation, useQueryClient } from 'react-query';
import { EventAssignmentInput, EventRegistrationAssignmentsType } from '../../../../types/events';
import { deleteEventAssignment } from '../api';

export const useDeleteAssignStaff = (eventId: string) => {
  const queryClient = useQueryClient();
  const staffQueryId = ['GetEventAssignments', eventId];

  return useMutation(async (vars: EventAssignmentInput) => deleteEventAssignment(vars), {
    onMutate: async (vars: EventAssignmentInput) => {
      // await queryClient.cancelQueries(['getFairsAttending', context.reqVars]);
      await queryClient.cancelQueries(staffQueryId);
      const oldData = queryClient.getQueryData<{
        items: EventRegistrationAssignmentsType[];
        nextToken: string | null;
      }>(staffQueryId);
      if (oldData) {
        const newStaff = { ...oldData };
        const employeeIdx = newStaff.items.findIndex((user) => user.tenantUserId === vars.input.tenantUserId);
        newStaff.items.splice(employeeIdx, 1);
        queryClient.setQueryData(staffQueryId, newStaff);
      }
      return { oldData };
    },
    onError: (_err, _variables, context) => {
      if (context?.oldData) {
        const oldData = context?.oldData;
        queryClient.setQueryData(staffQueryId, oldData);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries(staffQueryId);
    },
  });
};
