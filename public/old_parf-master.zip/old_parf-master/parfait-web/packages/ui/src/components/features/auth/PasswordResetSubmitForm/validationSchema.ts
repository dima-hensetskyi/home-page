import * as Yup from 'yup';

const passwordResetSubmitFormSchema = Yup.object().shape({
  code: Yup.string().required('Code is required.').nullable(),
  password: Yup.string().required('Password is required.').nullable(),
  passwordConfirm: Yup.string().required('Confirm Password does not match New Password').nullable(),
});

export default passwordResetSubmitFormSchema;
