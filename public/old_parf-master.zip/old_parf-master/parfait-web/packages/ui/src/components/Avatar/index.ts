import { AvatarComponent } from './Avatar';

export { AvatarComponent };
