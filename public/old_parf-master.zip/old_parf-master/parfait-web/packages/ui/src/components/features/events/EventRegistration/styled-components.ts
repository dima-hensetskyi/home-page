import styled from 'styled-components';

export const List = styled.ul`
  list-style: none;
  margin: 0;
  padding: 0;
`;

export const ListItem = styled.li`
  margin-bottom: 8px;

  &:last-child {
    margin: 0;
  }
`;

export const FormContainer = styled.div`
  max-width: 368px;
`;

export const Container = styled.div`
  margin: 120px auto 20px;
  //margin-top: 120px;
  //margin-bottom: 20px;
  max-width: 1076px;
  padding: 0 15px;
  //margin-left: auto;
  //margin-right: auto;
`;
