import { Box, Typography } from '@mui/material';
import { useInfiniteQuery, useQueryClient } from 'react-query';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useEffect, useState } from 'react';

import { CreateUserForm } from './UserForm/CreateUserForm';
import { fetchTenantsUsers } from './api';
import { getCorrectString } from './utils';
import { getCorrectTenantUsers } from './utils';
import { Loader } from '../../Loader';
import { SmallDialog } from '../../Dialog';
import { TableComponent } from '../../Table';
import { TableControls } from './TableControls';
import { TenantUsersRequestVariablesType, UserListItem } from './type';
import { UpdateUserForm } from './UserForm/UpdateUserForm';
import { ReinviteButton } from './ReinviteButton';
import { AuthenticatedTenantUserResponse } from '../../../types/tenant';

export type UserType = {
  name: string;
  userId: string;
  status: string;
  since: string;
  role: string;
  lastActive: string;
};

export const UsersView: React.FC = () => {
  const [activeUser, setActiveUser] = useState<null | UserListItem>(null);
  const [requestVariables, setRequestVariables] = useState<TenantUsersRequestVariablesType>({
    limit: 10,
    sortDirection: 'ASC',
  });
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const queryId = ['GetTenantUsers', requestVariables];
  const AlternativeOrder = requestVariables.sortDirection === 'ASC' ? 'DESC' : 'ASC';
  const queryIdWithAltSort = ['GetTenantUsers', { ...requestVariables, sortDirection: AlternativeOrder }];
  const queryClient = useQueryClient();

  const { data, hasNextPage, isFetching, isLoading, fetchNextPage } = useInfiniteQuery(
    queryId,
    (data) => fetchTenantsUsers(data.pageParam ? { ...requestVariables, nextToken: data.pageParam } : requestVariables),
    {
      keepPreviousData: true,
      retry: false,
      getNextPageParam: (lastPage) => lastPage?.nextToken,
    },
  );

  const onToggleDialog = (val: boolean) => setIsDialogOpen(val);
  const onDialogClose = () => {
    setIsDialogOpen(false);
    activeUser && setActiveUser(() => null);
  };

  const tenantUser = queryClient.getQueryData<AuthenticatedTenantUserResponse>('AuthenticatedTenantUser');
  useEffect(() => {
    if (activeUser && activeUser.id === tenantUser?.getAuthenticatedTenantUser.id) {
      const newUser = tenantUser.getAuthenticatedTenantUser;
      if (newUser) setActiveUser({ ...activeUser, fullDetail: { ...activeUser.fullDetail, ...newUser } });
    }
  }, [tenantUser]);

  return (
    <>
      <TableControls openDialog={onToggleDialog} />
      {isLoading ? (
        <Loader />
      ) : (
        <>
          <TableComponent
            tableDataItems={getCorrectTenantUsers(data?.pages.map((page) => page?.items || []).flat(1) || [])}
            // isLoading={isFetching}
            tableHeaders={{
              name: 'Name',
              username: 'Username',
              status: 'Status',
              // createdAt: 'Since',
              role: 'Role',
              lastAuthentication: 'Last Active',
            }}
            sortOrder={requestVariables.sortDirection}
            orderBy="name"
            onSortLabel={() => setRequestVariables({ ...requestVariables, sortDirection: AlternativeOrder })}
            onMouseSortLabel={() => {
              if (!queryClient.getQueryData(queryIdWithAltSort)) {
                queryClient.prefetchInfiniteQuery(queryIdWithAltSort, () =>
                  fetchTenantsUsers({ ...requestVariables, sortDirection: AlternativeOrder }),
                );
              }
            }}
            tableCustomRenderers={{
              name: (user) => (
                <Typography
                  sx={{ cursor: 'pointer' }}
                  onClick={() => {
                    setActiveUser(user);
                    setIsDialogOpen(true);
                  }}
                  variant="body2"
                  color={(theme) => theme.palette.primary.main}
                >
                  {user.name}
                </Typography>
              ),
              status: (user) => <ReinviteButton user={user} />,
              role: (user) => (user.role === 'USER' ? 'Staff' : getCorrectString(user.role)),
            }}
          />
          <Box sx={{ display: 'flex', visibility: hasNextPage ? 'visible' : 'hidden', justifyContent: 'flex-end' }}>
            <LoadingButton
              loading={isFetching}
              sx={{
                fontSize: '15px',
                lineHeight: '26px',
                letterSpacing: '0.46px',
              }}
              variant="contained"
              onClick={() => fetchNextPage()}
            >
              SHOW MORE
            </LoadingButton>
          </Box>
        </>
      )}
      <SmallDialog
        close={onDialogClose}
        open={isDialogOpen}
        content={
          activeUser ? (
            <UpdateUserForm queryId={queryId} onClose={onDialogClose} user={activeUser} />
          ) : (
            <CreateUserForm queryId={queryId} onClose={onDialogClose} />
          )
        }
      />
    </>
  );
};
