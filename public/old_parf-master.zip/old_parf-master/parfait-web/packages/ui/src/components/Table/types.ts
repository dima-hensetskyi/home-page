/** Helpers */

import React from 'react';

// helper to get an array containing the object values with
// the correct type infered.

export function objectValues<T extends object>(obj: T) {
  return Object.keys(obj).map((objKey) => obj[objKey as keyof T]);
}

export function objectKeys<T extends object>(obj: T) {
  return Object.keys(obj).map((objKey) => objKey as keyof T);
}

export type PrimitiveType = string | symbol | number | boolean;

// Type guard for the primitive types which will support printing
// out of the box
export function isPrimitive(value: any): value is PrimitiveType {
  return (
    typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean' || typeof value === 'symbol'
  );
}

export type ItemsFromObj<T extends object> = Partial<Record<keyof T, string>>;
export type CustomRenderers<T extends object> = Partial<Record<keyof T, (it: T) => React.ReactNode>>;
export type ColumnsWidth<T extends object> = Partial<Record<keyof T, string>>;

export interface TableProps<T extends object> {
  tableDataItems: Array<T>;
  tableHeaders: ItemsFromObj<T>;
  tableCustomRenderers?: CustomRenderers<T>;
  orderBy?: string;
  sortedRows?: string[];
  sortOrder?: 'ASC' | 'DESC';
  isLoading?: boolean;
  columnsWidth?: ColumnsWidth<T>;
  onSortLabel?: () => void;
  onMouseSortLabel?: () => void;
  loading?: boolean;
}
