import * as Yup from 'yup';

const validationSchema = Yup.object().shape({
  name: Yup.string().required('Please enter a name.').nullable(),
  email: Yup.string().required('Please enter a email.').email('Please enter a valid email.').nullable(),
  school: Yup.string().required('College is required.').nullable(),
});

export default validationSchema;
