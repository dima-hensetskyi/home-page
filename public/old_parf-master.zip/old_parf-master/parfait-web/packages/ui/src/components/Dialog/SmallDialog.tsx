import { Box, Button } from '@mui/material';
import { createPortal } from 'react-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import CloseIcon from '@mui/icons-material/Close';
import React, { useState } from 'react';

import { StyledDialog } from './SmallDialog.styled';
import { Transition } from '../Transition';

type PropsType = {
  additionalContent?: React.ReactNode;
  headerButton?: React.ReactNode;
  onShowMoreMouseEnter?: () => void;
  children?: never;
  close: () => void;
  content: React.ReactNode;
  open: boolean;
  xsWidth?: string;
  lgWidth?: string;
  xlWidth?: string;
};
export const SmallDialog: React.FC<PropsType> = ({
  open = true,
  close,
  content,
  additionalContent,
  headerButton,
  lgWidth = '390px',
  xlWidth = '500px',
  xsWidth = lgWidth,
  onShowMoreMouseEnter,
}: PropsType) => {
  const [showMore, setShowMore] = useState(false);
  if (!open) return null;
  const DialogDom = (
    <StyledDialog
      disableEnforceFocus
      hideBackdrop
      PaperProps={{
        sx: {
          position: 'fixed',
          right: 0,
          bottom: 0,
          top: {
            xs: `${window.scrollY > 70 ? 0 : 70 - window.scrollY}px`,
            lg: `${window.scrollY > 90 ? 0 : 90 - window.scrollY}px`,
          },
          width: showMore
            ? { xs: 'calc(100% - 60px)', lg: 'calc(100% - 260px)' }
            : { xs: xsWidth, lg: lgWidth, xl: xlWidth },
          minWidth: '390px',
          maxHeight: 'none',
          transition: 'width 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms',
          maxWidth: 'none',
          transitionDuration: '254ms',
          m: 0,
          px: '32px',
        },
      }}
      open={open}
      TransitionComponent={Transition}
    >
      <Box
        sx={{
          display: 'flex',
          justifyContent: additionalContent || headerButton ? 'space-between' : 'flex-end',
          py: '22px',
        }}
      >
        {additionalContent && (
          <Button
            onMouseEnter={
              onShowMoreMouseEnter
                ? () => {
                    !showMore && onShowMoreMouseEnter();
                  }
                : undefined
            }
            onClick={() => setShowMore(!showMore)}
            variant="text"
            size="small"
            color="primary"
            sx={{ p: 0, fz: '14px' }}
            startIcon={!showMore && <ArrowBackIcon />}
            endIcon={showMore && <ArrowForwardIcon />}
          >
            {showMore ? 'Hide details' : 'Show details'}
          </Button>
        )}
        {headerButton}
        <Button
          onClick={() => {
            setShowMore(false);
            close();
          }}
          variant="text"
          size="small"
          sx={{ color: '#00000099', p: 0, fz: '14px' }}
          startIcon={<CloseIcon />}
        >
          Close
        </Button>
      </Box>
      <Box
        sx={{
          display: 'flex',
          pb: '35px',
          gap: '32px',
        }}
      >
        <Box sx={{ width: showMore ? 'calc((100% - 62px) / 3)' : '100%' }}>{content}</Box>
        {showMore && (
          <Box
            sx={{
              display: showMore ? 'block' : 'none',
              flex: 1,
            }}
          >
            {additionalContent}
          </Box>
        )}
      </Box>
    </StyledDialog>
  );

  const target = document.body;

  return createPortal(DialogDom, target);
};
