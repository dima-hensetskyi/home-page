import StudentPendingPreview from './StudentPendingPreview';

export default StudentPendingPreview;
