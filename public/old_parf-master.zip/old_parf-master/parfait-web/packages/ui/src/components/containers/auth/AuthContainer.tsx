import React, { useReducer, Reducer, useEffect } from 'react';
import Amplify, { Auth, API, graphqlOperation } from 'aws-amplify';
import config from 'config/aws-config';
import { useNavigate } from 'react-router-dom';
import {
  createTenantAndAccountOwner,
  getAuthenticatedTenant,
  getTenantAvailable,
  getTenantUserConnectionInfo,
  updateTenantUser,
} from 'graphql/tenants';
import { FullPageLoader } from '../../';
import AuthContext from './AuthContext';
import { AppType, User } from '../../../types/general';
import { GetAuthenticatedTenant, Tenant } from '../../../types/tenant';
import { useQuery } from 'react-query';
import { getAuthenticatedTenantUser } from '../../Header/utils';
import { updateInvitation } from '../../features/invites/api';

type Props = {
  children: (props: { authorized: boolean }) => JSX.Element;
  appType: AppType;
};

type Action =
  | {
      type: 'SET_USER';
      payload: { user: User; tenant: Tenant };
    }
  | {
      type: 'SET_LOADED';
      payload: { user: User; tenant: Tenant } | null;
    }
  | {
      type: 'SIGN_OUT';
    }
  | {
      type: 'SET_REGISTRATION_INFO';
      payload: RegistrationLoginInfo;
    };

type RegistrationLoginInfo = {
  userName: string;
  password: string;
  institutionName: string;
  account: string;
  invitationCode?: string;
};

type State = {
  user: User | null;
  tenant: Tenant | null;
  loaded: boolean;
  registrationLoginInfo: RegistrationLoginInfo | null;
};

const AuthContainer = (props: Props) => {
  const { children, appType } = props;
  const navigate = useNavigate();

  const [{ user, tenant, loaded, registrationLoginInfo }, dispatch] = useReducer<Reducer<State, Action>>(
    (state, action) => {
      switch (action.type) {
        case 'SET_USER':
          return {
            ...state,
            user: action.payload.user,
            tenant: action.payload.tenant,
          };
        case 'SET_LOADED':
          return {
            ...state,
            user: action.payload ? action.payload.user : null,
            tenant: action.payload ? action.payload.tenant : null,
            loaded: true,
          };
        case 'SIGN_OUT':
          return {
            ...state,
            user: null,
          };
        case 'SET_REGISTRATION_INFO':
          return {
            ...state,
            registrationLoginInfo: action.payload,
          };
      }

      return state;
    },
    {
      user: null,
      tenant: null,
      loaded: false,
      registrationLoginInfo: null,
    },
  );

  const setIdentifiedAmplifyConfig = async (account: string, username: string) => {
    setAnonymousAmplifyConfig();
    const userCognitoInfoResults = await API.graphql(
      graphqlOperation(getTenantUserConnectionInfo, { account, username }),
    );

    /* @ts-ignore */
    const cognitoInfo = userCognitoInfoResults.data.getTenantUserConnectionInfo;

    localStorage.setItem('userPoolId', cognitoInfo.userPool);
    localStorage.setItem('identityPoolId', cognitoInfo.identityPool);
    localStorage.setItem('userPoolWebClientId', cognitoInfo.appClient);

    Amplify.configure({
      Auth: {
        mandatorySignIn: true,
        userPoolId: cognitoInfo.userPool,
        identityPoolId: cognitoInfo.identityPool,
        userPoolWebClientId: cognitoInfo.appClient,
      },
      Storage: {
        region: config.s3.REGION,
        bucket: config.s3.BUCKET,
      },
    });
  };

  const setAnonymousAmplifyConfig = (): void => {
    const userPoolId = localStorage.getItem('userPoolId');
    const identityPoolId = localStorage.getItem('identityPoolId');
    const userPoolWebClientId = localStorage.getItem('userPoolWebClientId');
    Amplify.configure({
      Auth: {
        // If we have stored credentials then sign in should be mandatory -- but we should be skipping login
        // mandatorySignIn: (user PoolId ? true : false),
        mandatorySignIn: false,
        region: config.cognito.REGION,
        userPoolId: userPoolId || config.cognito.USER_POOL_ID,
        identityPoolId: identityPoolId || config.cognito.IDENTITY_POOL_ID,
        userPoolWebClientId: userPoolWebClientId || config.cognito.APP_CLIENT_ID,
      },
      Storage: {
        region: config.s3.REGION,
        bucket: config.s3.BUCKET,
      },
    });
  };

  useEffect(() => {
    const checkState = async () => {
      setAnonymousAmplifyConfig();

      try {
        const user = await Auth.currentAuthenticatedUser();
        const tenantResponse = (await API.graphql({ query: getAuthenticatedTenant })) as GetAuthenticatedTenant;

        dispatch({
          type: 'SET_LOADED',
          payload: { user, tenant: tenantResponse.data.tenant },
        });
      } catch (err) {
        dispatch({
          type: 'SET_LOADED',
          payload: null,
        });
      }
    };

    checkState();
  }, []);

  const signOut = (): void => {
    Auth.signOut().then(() => {
      dispatch({
        type: 'SIGN_OUT',
      });
      navigate('/sign-in');
      localStorage.clear();
      setAnonymousAmplifyConfig();
    });
  };

  const checkTenantAvailable = async (account: string): Promise<boolean> => {
    const res = await API.graphql(
      graphqlOperation(getTenantAvailable, {
        account,
      }),
    );
    return res !== 'Not Available';
  };

  const signIn = async (account: string, username: string, password: string): Promise<any> => {
    const user = await Auth.signIn(username, password);
    if (user?.challengeName === 'NEW_PASSWORD_REQUIRED') {
      dispatch({
        type: 'SET_REGISTRATION_INFO',
        payload: {
          userName: username,
          password,
          institutionName: '',
          account,
        },
      });
      navigate(`/complete-new-password?username=${username}&account=${account}`);
      return;
    }

    const tenantResponse = (await API.graphql({ query: getAuthenticatedTenant })) as GetAuthenticatedTenant;

    dispatch({
      type: 'SET_USER',
      payload: { user, tenant: tenantResponse.data.tenant },
    });

    navigate('/');
  };

  const signUp = async (
    name: string,
    email: string,
    userName: string,
    password: string,
    account: string,
    institutionName: string,
    institutionId?: string,
    invitationCode?: string | null,
  ): Promise<any> => {
    setAnonymousAmplifyConfig();

    const body = {
      account,
      institutionName,
      institutionId,
      tenantType: appType === 'highSchool' ? 'HIGH_SCHOOL' : 'COLLEGE',
      username: userName,
      accountOwnerFullName: name,
      email,
      password,
    };

    const response = await API.graphql(
      graphqlOperation(createTenantAndAccountOwner, {
        input: body,
      }),
    );

    localStorage.setItem('account', account);

    dispatch({
      type: 'SET_REGISTRATION_INFO',
      payload: {
        userName,
        password,
        institutionName,
        account,
        invitationCode: invitationCode || '',
      },
    });

    navigate(`/confirm-email`);

    return response;
  };

  const confirmEmail = async (code: string) => {
    if (registrationLoginInfo) {
      const { userName, password, institutionName, account } = registrationLoginInfo;

      await setIdentifiedAmplifyConfig(account, userName);
      await Auth.confirmSignUp(userName, code);
      /**
       * Authorization for next step
       */
      const cognitoUser = await Auth.signIn(userName, password);
      const tenantUserId = cognitoUser.attributes['custom:tenantUser'];

      if (appType === 'university') {
        navigate(`/confirm-college-profile?institutionName=${institutionName}&tenantUserId=${tenantUserId}`);
      } else {
        if (registrationLoginInfo?.invitationCode) {
          await updateInvitation(registrationLoginInfo.invitationCode);
        }
        navigate(`/sign-in`);
      }
    }
  };

  const confirmCollegeAffiliation = async (tenantUserId: string, linkedInUrl: string, staffProfileURL: string) => {
    const positionReferenceLinks: Array<string> = [];

    if (linkedInUrl) {
      positionReferenceLinks.push(linkedInUrl);
    }

    if (staffProfileURL) {
      positionReferenceLinks.push(staffProfileURL);
    }

    const tenantUser = {
      id: tenantUserId,
      positionReferenceLinks: positionReferenceLinks,
    };

    /**
     * To perform this request user have to be authorized
     */
    await API.graphql(graphqlOperation(updateTenantUser, { input: tenantUser }));

    if (registrationLoginInfo?.invitationCode) {
      await updateInvitation(registrationLoginInfo.invitationCode);
    }

    await Auth.signOut().then(() => {
      localStorage.clear();
    });
  };

  const authorized = !!user && !!tenant;

  const forgotPassword = (account: string, username: string) => {
    return Auth.forgotPassword(username).then(() => {
      navigate(`/reset-password-submit?username=${username}&account=${account}`);
    });
  };

  const forgotPasswordSubmit = (username: string, code: string, newPassword: string) => {
    return Auth.forgotPasswordSubmit(username, code, newPassword);
  };

  const completeNewPasswordSubmit = async (newPassword: string) => {
    if (registrationLoginInfo) {
      const { userName, password } = registrationLoginInfo;
      const user = await Auth.signIn(userName, password);
      await Auth.completeNewPassword(user, newPassword, {});
    }
  };

  const getUserRole = (): string | null => {
    return user ? user?.attributes['custom:role'] : null;
  };

  const tenantUser = useQuery('AuthenticatedTenantUser', getAuthenticatedTenantUser, { enabled: authorized });

  if (!loaded || tenantUser.isLoading) {
    return <FullPageLoader />;
  }

  return (
    <AuthContext.Provider
      value={{
        setIdentifiedAmplifyConfig,
        checkTenantAvailable,
        confirmCollegeAffiliation,
        confirmEmail,
        signIn,
        signUp,
        signOut,
        user,
        tenant,
        userRole: getUserRole(),
        forgotPassword,
        forgotPasswordSubmit,
        completeNewPasswordSubmit,
        appType,
        authorized,
      }}
    >
      {children({ authorized })}
    </AuthContext.Provider>
  );
};

export default AuthContainer;
