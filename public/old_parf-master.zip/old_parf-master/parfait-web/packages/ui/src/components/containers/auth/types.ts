import { AppType, User } from '../../../types/general';
import { Tenant } from '../../../types/tenant';

export type AuthContextType = {
  signOut: () => void;
  confirmCollegeAffiliation: (tenantUserId: string, linkedInUrl: string, staffProfileURL: string) => any;
  signIn: (account: string, email: string, pass: string) => Promise<void>;
  signUp: (
    name: string,
    email: string,
    userName: string,
    password: string,
    account: string,
    institutionName: string,
    institutionId?: string,
    invitationCode?: string | null,
  ) => void;
  user: User | null;
  tenant: Tenant | null;
  userRole: string | null;
  setIdentifiedAmplifyConfig: (account: string, email: string) => void;
  checkTenantAvailable: (account: string) => Promise<boolean>;
  confirmEmail: (code: string) => Promise<void>;
  forgotPassword: (account: string, username: string) => Promise<void>;
  forgotPasswordSubmit: (username: string, code: string, newPassword: string) => Promise<string>;
  completeNewPasswordSubmit: (newPassword: string) => void;
  appType: AppType;
  authorized: boolean;
};
