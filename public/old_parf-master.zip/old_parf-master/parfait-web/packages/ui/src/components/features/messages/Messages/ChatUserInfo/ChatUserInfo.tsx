import React from 'react';
import { useQuery } from 'react-query';
import { Stack, Typography, Box } from '@mui/material';
import { OverlayScrollbarsComponent } from 'overlayscrollbars-react';
import CircularProgress from '@mui/material/CircularProgress';
import useMessagesContext from '../../../../containers/messages/usemMessagesContext';
import { AttributesData } from '../../../../Attributes/Attributes';
import Attributes from '../../../../Attributes';
// import Avatar from '../Avatar';
import { User, UserName } from './styled-components';
import { QuestionCategory, UserInfoState } from './types';
import { fetchRecruit, fetchGetQuestions, fetchUserAnswers, fetchUser } from './api';
import { AvatarComponent } from '../../../../Avatar';

const NO_DATA = '-';

const ChatUserInfo = () => {
  const { activeChat, messagesHeight, chatUserId } = useMessagesContext();

  if (!chatUserId) {
    return null;
  }

  const { data } = useQuery<UserInfoState>(
    ['ChatUserInfo', chatUserId],
    async () => {
      const [recruit, questions, answers, user] = await Promise.all([
        fetchRecruit(chatUserId),
        fetchGetQuestions(),
        fetchUserAnswers(chatUserId),
        fetchUser(chatUserId),
      ]);

      return {
        userAnswers: answers,
        questions,
        recruit,
        user,
      };
    },
    {
      enabled: Boolean(chatUserId),
      retry: false,
    },
  );

  const getAnswersByCategory = (category: QuestionCategory): AttributesData => {
    const result: AttributesData = [];

    if (!data) return result;

    const { questions, userAnswers } = data;

    const questionsByCategory = questions.filter((question) => {
      return question.category === category;
    });

    return questionsByCategory.reduce((acc: AttributesData, question) => {
      const res = userAnswers.find((answers) => {
        return answers.question.id === question.id;
      });

      acc.push({
        label: question.name,
        value: res ? res!.answers.join(', ') : NO_DATA,
      });

      return acc;
    }, []);
  };

  if (!activeChat) {
    return <div>Please select a chat</div>;
  }

  const user = activeChat.user || null;

  if (!data) {
    return (
      <Box
        sx={{
          mb: 2,
          mt: 2,
          display: 'flex',
          justifyContent: 'center',
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  const { recruit } = data;

  return (
    <OverlayScrollbarsComponent
      style={{
        height: messagesHeight,
      }}
    >
      {user ? (
        <User>
          {/* <Avatar size={40} user={data.user} /> */}
          <AvatarComponent avatar={user.avatar} name={user.name} />
          <UserName>
            <Typography variant="subtitle1" gutterBottom>
              {user.name}
            </Typography>
          </UserName>
        </User>
      ) : null}
      <Stack spacing={3}>
        {recruit ? (
          <Attributes
            labelWidth={120}
            data={[
              {
                label: 'Cohort',
                value: recruit.recruitCohort.name,
              },
              {
                label: 'Status',
                value: recruit.status,
              },
              {
                label: 'Assigned',
                value: recruit.assignedTenantUser ? recruit.assignedTenantUser.username : NO_DATA,
              },
            ]}
          />
        ) : null}
        <Attributes labelWidth={120} title="Profile" data={getAnswersByCategory('GENERAL')} />
        <Attributes labelWidth={120} title="Academics" data={getAnswersByCategory('ACADEMICS')} />
        <Attributes labelWidth={120} title="Interests" data={getAnswersByCategory('INTEREST')} />
      </Stack>
    </OverlayScrollbarsComponent>
  );
};

export default ChatUserInfo;
