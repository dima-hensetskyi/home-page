import defStyles from 'config/styles';

const { primaryLight } = defStyles.customColors;

import styled from 'styled-components';

export const Container = styled.div`
  margin-bottom: 20px;
`;
export const Error = styled.div`
  margin-top: 10px;
`;
export const FormControlDivider = styled.div`
  color: #9e9e9e;
  text-transform: uppercase;
  font-size: 12px;
  display: flex;
  align-items: center;
  flex-direction: row;
  margin: 27px 0;
  line-height: 1;

  &:after {
    content: '';
    display: block;
    height: 1px;
    width: 200px;
    background: #e0e0e0;
    margin-left: 9px;
  }
`;

export const FormControlTooltipRow = styled.div`
  display: flex;
  align-items: flex-start;
`;

export const TooltipWrapper = styled.div`
  margin-top: 7px;
`;

export const PasswordInputWrapper = styled.div`
  position: relative;

  & > div:first-child {
    margin-top: 0;
  }
`;

export const IconWrapper = styled.div`
  position: absolute;
  right: 15px;
  top: 10px;
`;
