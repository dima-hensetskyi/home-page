import { EventRegistrationByTenantType, EventRegistrationsByTenantFilterType } from '../../../../types/events';
import dayjs from 'dayjs';
import { Address } from '../../../../types/general';

export const getFairsAttendingItem = (item: EventRegistrationByTenantType) => {
  const {
    status,
    id,
    event: { expectedAttendees, locationName, name, startDateAndTime },
    eventRegistrationAssignments,
  } = item;

  return {
    name,
    status,
    date: startDateAndTime,
    locationName,
    staffAssigned: eventRegistrationAssignments.items,
    expectedAttendees,
    id,
    fullDetail: item,
  };
};

export const getFairsList = (items: EventRegistrationByTenantType[] | []) =>
  items.map((evt) => getFairsAttendingItem(evt));

export const getAddressItem = (address: string | null | undefined) => (address ? address + ',' : '');
export const getCorrectAddress = (address: Address | null) =>
  `${getAddressItem(address?.address1)} ${getAddressItem(address?.address2)} ${address?.city}, ${
    address?.stateProvince
  }, ${address?.postalCode}`;

export const getCorrectTime = (startTime: string, endTime: string) =>
  `${dayjs(startTime).format('MMMM D, YYYY, LT')}${endTime ? ' - ' + dayjs(endTime).format('LT') : ''}`;

export const filterVariables = (deleteKeys: 'search' | 'filter', variables: EventRegistrationsByTenantFilterType) =>
  Object.fromEntries(
    Object.entries(variables).filter(([k]) =>
      deleteKeys === 'search' ? k !== 'searchTerms' : k !== 'statuses' && k !== 'recruitCohortIds',
    ),
  );

export const getSearchingFairsList = (items: EventRegistrationByTenantType[] | []) =>
  items.map((fair) => fair.event.name);
