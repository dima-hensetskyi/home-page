import ParfaitLogo from './ParfaitLogo';

export default ParfaitLogo;
