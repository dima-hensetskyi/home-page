import React, { useState } from 'react';
import { Formik, Form, Field } from 'formik';
import { TextField as FormikTextField } from 'formik-mui';
import { Stack, Button, Typography, Alert } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { FormValues } from '../types';
import * as Yup from 'yup';
import { checkPhoneNumber } from '../../adminUserManagement/api';

type Props = {
  onSubmit: (values: FormValues) => void;
  initialValues: FormValues;
  onClose: () => void;
};

const StudentForm = (props: Props) => {
  const { onSubmit, initialValues, onClose } = props;

  const [emailOrPhoneRequiredError, setEmailOrPhoneRequiredError] = useState(false);

  return (
    <Formik
      initialValues={initialValues}
      onSubmit={async (values, { setSubmitting }) => {
        setEmailOrPhoneRequiredError(false);
        if (values.phoneNumber || values.emailAddress) {
          await onSubmit(values);
          setSubmitting(false);
        } else {
          setEmailOrPhoneRequiredError(true);
          setSubmitting(false);
        }
      }}
      validationSchema={Yup.object().shape({
        givenName: Yup.string().required('First Name is required.').nullable(),
        familyName: Yup.string().required('Last Name is required.').nullable(),
        graduationYear: Yup.string().required('Please select a graduation year.').nullable(),
        emailAddress: Yup.string().notRequired().email('Please provide valid email.').nullable(),
        phoneNumber: Yup.string()
          .notRequired()
          .test('awsPhoneValidation', 'Invalid phone number', async (num) =>
            num ? new Promise((resolve) => checkPhoneNumber(num, resolve)) : true,
          )
          .nullable(),
      })}
    >
      {({ isSubmitting }) => {
        return (
          <Form id="student-form">
            <Stack
              spacing={2}
              sx={{
                mb: 3,
              }}
            >
              {emailOrPhoneRequiredError && (
                <Alert severity="error">Please provide phone number or email address.</Alert>
              )}
              <Field
                fullWidth
                component={FormikTextField}
                name="givenName"
                label="First Name"
                type="text"
                size="small"
              />
              <Field
                fullWidth
                component={FormikTextField}
                name="familyName"
                label="Last Name"
                type="text"
                size="small"
              />
              <Field
                fullWidth
                component={FormikTextField}
                name="graduationYear"
                label="Graduation Year"
                type="text"
                size="small"
              />
              <Typography
                variant="overline"
                display="block"
                gutterBottom
                sx={{
                  color: '#9E9E9E',
                }}
              >
                Mobile number or email address
              </Typography>
              <Field
                fullWidth
                component={FormikTextField}
                name="phoneNumber"
                label="Mobile number"
                type="text"
                size="small"
              />
              <Field fullWidth component={FormikTextField} name="emailAddress" label="Email" type="text" size="small" />
            </Stack>
            <Stack spacing={1} direction="row">
              <LoadingButton form="student-form" variant="contained" type="submit" loading={isSubmitting}>
                SAVE & INVITE
              </LoadingButton>
              <Button variant="outlined" onClick={onClose}>
                Cancel
              </Button>
            </Stack>
          </Form>
        );
      }}
    </Formik>
  );
};

export default StudentForm;
