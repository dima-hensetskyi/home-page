import * as Yup from 'yup';

export const confirmEmailSchema = Yup.object().shape({
  code: Yup.string().required('Please enter a valid confirmation code.').nullable(),
});
