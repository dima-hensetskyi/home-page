import ChatMessage from './ChatMessage';

export default ChatMessage;
