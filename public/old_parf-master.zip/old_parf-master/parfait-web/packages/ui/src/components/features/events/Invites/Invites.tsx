import { API } from 'aws-amplify';
import { Typography, Stack, Button } from '@mui/material';
import { useSnackbar } from 'notistack';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useState } from 'react';

import { SmallDialog } from '../../../Dialog';
import InvitesForm from './InvitesForm';
import InvitesList from './InvitesList';

type Props = {
  inviteId: string;
  inviteName: string;
};

const createEventInvitesByEmail = /* GraphQL */ `
  mutation createEventInvitesByEmail($input: CreateEventInvitesByEmailInput!) {
    createEventInvitesByEmail(input: $input)
  }
`;

const Invites = (props: Props) => {
  const { inviteId, inviteName } = props;

  const [visible, setVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const { enqueueSnackbar } = useSnackbar();

  const onSubmit = async (message: string, emails: Array<string>) => {
    setLoading(true);

    try {
      await API.graphql({
        query: createEventInvitesByEmail,
        variables: {
          input: {
            eventId: inviteId,
            emails,
            message,
          },
        },
      });

      enqueueSnackbar('Invites successfully sent!', {
        variant: 'success',
      });
      setLoading(false);
      setVisible(false);
    } catch (e) {
      setLoading(false);
      enqueueSnackbar('Invites sent error!', {
        variant: 'error',
      });
    }
  };

  return (
    <>
      <Typography
        sx={{ color: (theme) => theme.palette.primary.main, ':hover': { cursor: 'pointer' } }}
        onClick={() => {
          setVisible(true);
        }}
        variant="body2"
      >
        Invites
      </Typography>
      <SmallDialog
        content={
          <div>
            <Typography
              variant="h6"
              sx={{
                mb: 2.5,
              }}
            >
              Add invites for {inviteName}
            </Typography>
            <Stack spacing={3}>
              <InvitesForm onSubmit={onSubmit} />
              <InvitesList eventId={inviteId} />
            </Stack>
          </div>
        }
        open={visible}
        lgWidth="600px"
        xlWidth="674px"
        close={() => {
          setVisible(false);
        }}
        headerButton={
          <Stack spacing={1} direction="row">
            <LoadingButton form="fair-invites" variant="contained" type="submit" loading={loading}>
              Send Invites
            </LoadingButton>
            <Button
              variant="outlined"
              onClick={() => {
                setVisible(false);
              }}
            >
              Cancel
            </Button>
          </Stack>
        }
      />
    </>
  );
};

export default Invites;
