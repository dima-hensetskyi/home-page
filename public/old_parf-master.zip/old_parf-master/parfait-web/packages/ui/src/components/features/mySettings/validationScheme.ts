import * as Yup from 'yup';
import { checkPhoneNumber } from '../adminUserManagement/api';

export const userSchema = Yup.object().shape({
  givenName: Yup.string().min(1).required('Please enter a First Name.'),
  familyName: Yup.string().min(1).required('Please enter a Last Name.'),
  username: Yup.string()
    .required('User Name is required.')
    .matches(/^[a-z0-9]+$/i, 'User name can only be alphanumeric.')
    .min(3, 'User name must contain a minimum of three characters.'),
  email: Yup.string().required('Please enter a valid email address.').email('Please enter a valid email address.'),
  phoneNumber: Yup.string()
    .notRequired()
    .test('awsPhoneValidation', 'Invalid phone number', async (num) =>
      num ? new Promise((resolve) => checkPhoneNumber(num, resolve)) : true,
    )
    .nullable(),
});
