import React from 'react';
import { Storage } from 'aws-amplify';
import { S3Object } from '../../../../../../types/general';
import styled from 'styled-components';
import { ImageWrapper } from '../../styled-components';
import CircularProgress from '@mui/material/CircularProgress';
import { useQuery } from 'react-query';

const Img = styled.img`
  width: 100%;
`;

type Props = {
  image: S3Object;
};

const Image = (props: Props) => {
  const { image } = props;

  const { data: url } = useQuery(
    ['AppManagementImage', image.key],
    async () => {
      const result = (await Storage.get(image.key, { bucket: image.bucket, region: image.region })) as string;

      return result;
    },
    {
      staleTime: Infinity,
      refetchOnWindowFocus: false,
    },
  );

  return <ImageWrapper>{url ? <Img src={url} alt="Secondary image" /> : <CircularProgress />}</ImageWrapper>;
};

export default Image;
