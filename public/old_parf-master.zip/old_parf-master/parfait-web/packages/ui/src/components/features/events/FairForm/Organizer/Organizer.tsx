import { API } from 'aws-amplify';
import { MenuItem, Select, InputLabel, FormControl, FormHelperText } from '@mui/material';
import { useFormikContext } from 'formik';
import { useQuery } from 'react-query';
import React from 'react';

import { FormValues } from '../types';
import { GetTenantUsers } from 'graphql/tenants';
import { GetTenantUsersResponse } from '../../../../../types/tenant';

const Organizer = () => {
  const { values, setFieldValue, errors, touched } = useFormikContext<FormValues>();
  const { data } = useQuery('GetTenantUsers', async () => {
    const result = (await API.graphql({ query: GetTenantUsers })) as GetTenantUsersResponse;

    return result.data.getTenantUsers.items;
  });

  return (
    <div>
      <FormControl fullWidth size="small">
        <InputLabel id="organizerTenantUserId">Organizer</InputLabel>
        <Select
          label="Organizer"
          labelId="organizerTenantUserId"
          error={!!touched?.organizerTenantUserId && !!errors?.organizerTenantUserId}
          value={values.organizerTenantUserId}
          size="small"
          onChange={(evt) => {
            setFieldValue('organizerTenantUserId', evt.target.value);
          }}
        >
          {data
            ? data.map((tenant) => (
                <MenuItem key={tenant.id} value={tenant.id}>
                  {tenant.name}
                </MenuItem>
              ))
            : null}
        </Select>
        <FormHelperText sx={{ color: (theme) => theme.palette.error.main }}>
          {touched?.organizerTenantUserId && errors?.organizerTenantUserId}
        </FormHelperText>
      </FormControl>
    </div>
  );
};

export default Organizer;
