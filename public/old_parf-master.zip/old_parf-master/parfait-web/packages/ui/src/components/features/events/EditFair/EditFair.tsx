import { API, graphqlOperation } from 'aws-amplify';
import { Box, Button, Typography } from '@mui/material';
import { editFair } from 'graphql/events';
import { useQueryClient } from 'react-query';
import dayjs from 'dayjs';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useState } from 'react';

import { Fair } from '../types';
import { FormValues } from '../FairForm/types';
import { SmallDialog } from '../../../Dialog';
import FairForm from '../FairForm';

type Props = {
  entity: Fair;
  onClose: () => void;
};

const EditFair = (props: Props) => {
  const { entity, onClose } = props;
  const [loading, setLoading] = useState(false);

  const queryClient = useQueryClient();

  const onSubmit = async (values: FormValues, startDate: string, endDate: string) => {
    setLoading(true);

    await API.graphql(
      graphqlOperation(editFair, {
        input: {
          id: entity.id,
          status: values.status,
          name: values.name,
          startDateAndTime: startDate,
          endDateAndTime: endDate,
          description: values.description,
          note: values.note,
          organizerTenantUserId: values.organizerTenantUserId,
          locationName: values.locationName,
          address: {
            address1: values.address1,
            address2: values.address2,
            stateProvince: values.stateProvince,
            postalCode: values.postalCode,
            city: values.city,
            country: 'United States of America',
            alphaTwoCode: 'US',
          },
          //organizerTenantUserId: values.expectedAttendees,
          expectedAttendees: values.expectedAttendees,
          fee: values.fee,
        },
      }),
    );

    queryClient.invalidateQueries('getEvents');

    setLoading(false);
    onClose();
  };

  const initialValues: FormValues = {
    name: entity.name,

    status: entity.status,
    date: dayjs(entity.startDateAndTime).format('YYYY-MM-DD'),
    startTime: dayjs(entity.startDateAndTime).format('HH:mm'),
    endTime: dayjs(entity.endDateAndTime).format('HH:mm'),
    inviteType: entity.inviteType,

    organizerTenantUserId: entity.organizerTenantUserId || '',
    fee: entity.fee,

    address1: entity.address ? entity.address.address1 : '',
    address2: entity.address ? entity.address.address2 : '',
    city: entity.address ? entity.address.city : '',
    stateProvince: entity.address ? entity.address.stateProvince : '',
    postalCode: entity.address ? entity.address.postalCode : '',
    expectedAttendees: entity.expectedAttendees,

    locationName: entity.locationName,

    description: entity.description,
    note: entity.note,
  };

  return (
    <SmallDialog
      content={
        entity ? (
          <div>
            <Typography
              variant="h6"
              sx={{
                mb: 2.5,
              }}
            >
              Update college fair
            </Typography>
            <FairForm initialValues={initialValues} onSubmit={onSubmit} type="edit" onClose={onClose} id={entity.id} />
          </div>
        ) : null
      }
      open={!!entity}
      lgWidth="736px"
      xlWidth="810px"
      close={() => {
        onClose();
      }}
      headerButton={
        <Box sx={{ display: 'flex', gap: '8px' }}>
          <LoadingButton form="fair-form" variant="contained" type="submit" loading={loading}>
            Update
          </LoadingButton>
          <Button variant="outlined" onClick={onClose}>
            Cancel
          </Button>
        </Box>
      }
    />
  );
};

export default EditFair;
