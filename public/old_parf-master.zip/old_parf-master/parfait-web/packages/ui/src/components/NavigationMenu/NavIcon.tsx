import { AppIcon, EmailIcon, CalendarIcon, MessagesIcon, PeopleIcon, StudentsIcon } from '../../icons';
import React from 'react';
import styled from 'styled-components';

const NavLinksIconsMap = {
  Recruits: PeopleIcon,
  Messages: MessagesIcon,
  'App Management': AppIcon,
  Invites: EmailIcon,
  'College Fairs': CalendarIcon,
  Students: StudentsIcon,
};

const Wrapper = styled.div`
  width: 22px;
  height: 20px;

  @media (min-width: 1200px) {
    margin-right: 22px;
  }
`;

type propType = {
  iconName: string;
};

export const NavIcon: React.FC<propType> = ({ iconName }: propType) => {
  const Icon = NavLinksIconsMap[iconName as keyof typeof NavLinksIconsMap];
  return (
    <Wrapper>
      <Icon />
    </Wrapper>
  );
};
