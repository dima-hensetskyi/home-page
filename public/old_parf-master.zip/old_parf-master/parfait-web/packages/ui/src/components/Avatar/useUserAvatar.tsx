import { Storage } from 'aws-amplify';
import { useQuery } from 'react-query';

import { S3Object } from '../../types/general';

export const useUserAvatar = (avatar: S3Object | undefined) => {
  return useQuery(
    ['Avatar', avatar?.key],
    async () => {
      if (avatar?.key) {
        const result = (await Storage.get(avatar?.key, {
          bucket: avatar?.bucket,
          region: avatar?.region,
          level: 'protected',
          identityId: avatar.identityId,
        })) as string;
        return result;
      }
    },
    {
      enabled: !!avatar?.key,
      staleTime: Infinity,
      refetchOnWindowFocus: false,
    },
  );
};
