import LeaveFormConfirmation from './LeaveFormConfirmation';

export default LeaveFormConfirmation;
