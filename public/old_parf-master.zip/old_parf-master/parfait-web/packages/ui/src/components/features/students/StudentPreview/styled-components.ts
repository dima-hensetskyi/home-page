import styled from 'styled-components';

export const Row = styled.div`
  display: flex;
  align-items: center;
`;
export const Label = styled.div`
  width: 40%;
  color: #666;

  p:after {
    content: ':';
  }
`;

export const ValueField = styled.div`
  width: 60%;
`;
