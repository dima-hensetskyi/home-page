import React, { useState } from 'react';
import Button from '@mui/material/Button';
import { Box, Dialog, DialogTitle, Stack, Typography } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { editFair } from 'graphql/events';
import { API, graphqlOperation } from 'aws-amplify';
import { useFormikContext } from 'formik';
import { FormValues } from '../types';
import { useQueryClient } from 'react-query';

type Props = {
  eventId: string;
  onClose: () => void;
};

const CancelFair = (props: Props) => {
  const { eventId, onClose } = props;

  const [modalVisible, setModalVisible] = useState<boolean>(false);
  const [cancelLoading, setCancelLoading] = useState<boolean>(false);
  const { values } = useFormikContext<FormValues>();
  const queryClient = useQueryClient();

  const onCancelClick = async () => {
    setCancelLoading(true);

    await API.graphql(
      graphqlOperation(editFair, {
        input: {
          id: eventId,
          status: 'CANCELLED',
        },
      }),
    );

    setCancelLoading(false);
    onClose();
    queryClient.invalidateQueries('getEvents');
  };

  return (
    <>
      {values.status !== 'CANCELLED' && (
        <div>
          <Button
            variant="outlined"
            color="error"
            onClick={() => {
              setModalVisible(true);
            }}
          >
            Cancel fair
          </Button>
        </div>
      )}
      <Dialog onClose={() => setModalVisible(false)} open={modalVisible}>
        <DialogTitle>Cancel fair and notify participants?</DialogTitle>
        <Box
          sx={{
            margin: 3,
            mt: 0,
          }}
        >
          <Typography variant="body2">This action cannot be undone.</Typography>
          <Stack direction="row" spacing={2} sx={{ mt: 2 }}>
            <LoadingButton
              variant="contained"
              size="small"
              color="error"
              loading={cancelLoading}
              onClick={onCancelClick}
            >
              CONTINUE
            </LoadingButton>
            <Button
              variant="outlined"
              onClick={() => {
                setModalVisible(false);
              }}
            >
              CANCEL
            </Button>
          </Stack>
        </Box>
      </Dialog>
    </>
  );
};

export default CancelFair;
