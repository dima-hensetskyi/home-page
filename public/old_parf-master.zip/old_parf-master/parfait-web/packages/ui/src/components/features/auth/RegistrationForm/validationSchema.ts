import * as Yup from 'yup';
import { AppType } from '../../../../types/general';
import { isValidZipCode } from './utils';

const passwordMessage = 'Please enter a valid password.';
const emailMessage = 'Valid email is required';
const zipCodeMessage = 'Valid zip code is required';

export const getRegistrationValidationSchema = (appType: AppType) => {
  return Yup.object().shape({
    name: Yup.string().required('Name is required.').nullable(),
    email: Yup.string().required(emailMessage).email(emailMessage).nullable(),
    school: Yup.string().required('School is required.').nullable(),
    displaySchoolInput: Yup.boolean(),
    zipCode:
      appType === 'highSchool'
        ? Yup.string().when('displaySchoolInput', {
            is: false,
            then: Yup.string()
              .required(zipCodeMessage)
              .test({
                name: 'Validate zip code',
                test: (value) => {
                  return isValidZipCode(value);
                },
                message: zipCodeMessage,
              })
              .nullable(),
          })
        : Yup.string().nullable(),
    userName: Yup.string()
      .required('Username is required.')
      .matches(/^[a-z0-9]+$/i, 'Username can only be alphanumeric.')
      .min(3, 'Username must contain a minimum of three characters.')
      .nullable(),
    password: Yup.string()
      .required('Password is required.')
      .min(8, passwordMessage)
      .matches(/\d/, passwordMessage)
      .matches(/[A-Z]/, passwordMessage)
      .matches(/[a-z]/, passwordMessage)
      .nullable(),
  });
};
