import { Formik, Form, FormikHelpers } from 'formik';
import { LinearProgress, Alert, Stack } from '@mui/material';
import { useSearchParams } from 'react-router-dom';
import React, { useState } from 'react';

import { Container, Error } from '../styledComponents';
import AuthHeader from '../AuthHeader';
import Button from '../Button';
import PasswordField from '../RegistrationForm/PasswordField';
import PasswordInput from '../PasswordInput';
import passwordResetSubmitFormSchema from './validationSchema';
import useAuthContext from '../../../containers/auth/useAuthContext';

export const CompletePasswordForm = () => {
  const [error, setError] = useState<string | null>(null);
  const { signIn, completeNewPasswordSubmit } = useAuthContext();

  const [searchParams] = useSearchParams();
  const userName = searchParams.get('username');
  const account = searchParams.get('account');

  const initialValues = {
    password: '',
    passwordConfirm: '',
  };

  const onSubmit = async (values: typeof initialValues, { setSubmitting }: FormikHelpers<typeof initialValues>) => {
    const { password, passwordConfirm } = values;
    setError(null);

    if (password !== passwordConfirm) {
      setError('Confirm Password does not match New Password');
      return;
    }

    try {
      await completeNewPasswordSubmit(password);
      await signIn(account!, userName!, password);
    } catch (e) {
      setError('Your email or password were incorrect.');
      setSubmitting(false);
    }
  };

  return (
    <Container>
      <AuthHeader title="New Password" description="Please enter a new password for your account." />
      <Formik validationSchema={passwordResetSubmitFormSchema} initialValues={initialValues} onSubmit={onSubmit}>
        {({ isSubmitting }) => (
          <Form>
            <Stack spacing={2}>
              <PasswordField label="New Password" />
              <PasswordInput fullWidth name="passwordConfirm" label="Confirm New Password" />
            </Stack>
            <Stack
              spacing={1}
              sx={{
                marginTop: '24px',
              }}
            >
              {error && (
                <Error>
                  <Alert severity="error">{error}</Alert>
                </Error>
              )}
              <div>
                {isSubmitting && <LinearProgress />}
                <Button type="submit">Save</Button>
              </div>
            </Stack>
          </Form>
        )}
      </Formik>
    </Container>
  );
};
