import { AppBar, Typography } from '@mui/material';
import { useQueryClient } from 'react-query';
// import NotificationsIcon from '@mui/icons-material/Notifications';
import React from 'react';
import styled from 'styled-components';

import { AuthenticatedTenantUserResponse } from '../../types/tenant';
import defStyles from 'config/styles';
import HeaderAccountMenu from '../HeaderMenu/HeaderAccountMenu';
import useAuthContext from '../containers/auth/useAuthContext';

const { aqua } = defStyles.customColors;

const SchoolDetail = styled.div`
  display: flex;
  flex-direction: column;
`;

const UserDetail = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
`;

const Header: React.FC = () => {
  const { tenant, appType } = useAuthContext();
  const queryClient = useQueryClient();
  const tenantUser = queryClient.getQueryData<AuthenticatedTenantUserResponse>('AuthenticatedTenantUser');

  return (
    <AppBar
      position="relative"
      sx={{
        maxHeight: { xs: '70px', lg: '90px' },
        height: '100%',
        background: aqua,
        boxShadow: 'none',
        zIndex: 999,
        padding: { xs: '10px 32px', lg: '20px 32px' },
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}
    >
      <SchoolDetail>
        {tenant ? (
          <Typography variant="subtitle1" color="black">
            {tenant.name}
          </Typography>
        ) : null}
        <Typography variant="caption" sx={{ color: 'rgba(0, 0, 0, 0.6)' }}>
          {appType === 'highSchool' ? 'High School Management' : 'College Management'}
        </Typography>
      </SchoolDetail>
      {tenantUser && (
        <UserDetail>
          {/* <IconButton size="medium" sx={{ height: 'fit-content', marginRight: '15px' }}>
            <Badge color="secondary">
              <NotificationsIcon sx={{ color: 'rgba(0, 0, 0, 0.6)', fontSize: '20px' }} />
            </Badge>
          </IconButton> */}
          <HeaderAccountMenu authenticatedTenantUser={tenantUser} />
        </UserDetail>
      )}
    </AppBar>
  );
};

export default Header;
