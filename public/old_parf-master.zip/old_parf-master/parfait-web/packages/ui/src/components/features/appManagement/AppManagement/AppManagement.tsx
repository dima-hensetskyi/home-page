import React from 'react';
import { Typography } from '@mui/material';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import AppImages from './AppImages';
import AppInformation from './AppInformation';

const AppManagement = () => {
  const navigate = useNavigate();

  const location = useLocation();

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    navigate(newValue);
  };

  return (
    <>
      <Typography variant="h4" color="#000" sx={{ mb: 2 }}>
        App management
      </Typography>
      <Box sx={{ width: '100%' }}>
        <Tabs
          value={location.pathname.replace('/app-management/', '')}
          onChange={handleChange}
          aria-label="secondary tabs example"
        >
          <Tab value="images" label="Images" />
          <Tab value="information" label="Information" />
        </Tabs>
      </Box>
      <Routes>
        <Route path="images" element={<AppImages />} />
        <Route path="information" element={<AppInformation />} />
      </Routes>
    </>
  );
};

export default AppManagement;
