import SecondaryImageForm from './SecondaryImageForm';

export default SecondaryImageForm;
