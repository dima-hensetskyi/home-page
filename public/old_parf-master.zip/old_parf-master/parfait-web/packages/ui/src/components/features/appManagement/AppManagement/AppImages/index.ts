import AppImages from './AppImages';

export default AppImages;
