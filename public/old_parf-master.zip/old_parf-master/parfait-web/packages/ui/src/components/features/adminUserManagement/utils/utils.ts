import { getCorrectDate } from '../../utils';
import { TenantUserResponseType } from '../type';

export const getCorrectTenantUser = (user: TenantUserResponseType) => {
  const {
    id,
    givenName,
    familyName,
    username,
    status,
    createdAt,
    updatedAt,
    email,
    avatar,
    phoneNumber,
    lastAuthentication,
    role,
  } = user;

  return {
    name: `${givenName} ${familyName}`,
    username,
    status: status,
    createdAt: getCorrectDate(createdAt),
    role,
    lastAuthentication: (lastAuthentication && getCorrectDate(lastAuthentication)) || 'No Activity',
    phoneNumber,
    id,
    updatedAt,
    email,
    avatar,
    fullDetail: user,
  };
};

export const getCorrectTenantUsers = (response: TenantUserResponseType[] | []) => {
  return response.map((user) => getCorrectTenantUser(user));
};

export const unmaskPhoneNumber = (requestObj: object) => {
  const key = 'phoneNumber' as string;
  const number: string = requestObj[key as keyof typeof requestObj];
  const phoneNumber = `+1${number.replace(/[^\d]/g, '')}`;
  return { ...requestObj, phoneNumber };
};
