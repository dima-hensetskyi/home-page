import { SmallDialog } from './SmallDialog';
import { BasicDialog } from './BasicDialog';

export { SmallDialog, BasicDialog };
