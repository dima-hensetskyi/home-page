import CollegeFairsList from './CollegeFairsList';

export default CollegeFairsList;
