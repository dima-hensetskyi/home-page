import React from 'react';
import LogoIcon from '../../icons/logo.svg';

const ParfaitLogo = () => {
  return <LogoIcon />;
};

export default ParfaitLogo;
