export const isValidZipCode = (zipCode: string | null | undefined): boolean => {
  return typeof zipCode === 'string' ? /(^\d{5}$)|(^\d{5}-\d{4}$)/.test(zipCode) : true;
};
