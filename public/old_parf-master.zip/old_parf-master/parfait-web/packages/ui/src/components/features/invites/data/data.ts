export const collegeInviteMessage =
  'I am inviting you to the new college recruiting platform, Parfait. I think it could be a valuable tool to help you connect with students who may be a good fit for your school. The platform makes recruiting at college fairs much easier and also supports direct messaging with students.';
export const hightSchoolMessage =
  'I am inviting you to the new college recruiting platform, Parfait. I think it could be a valuable tool to help your students discover college opportunities. The platform also supports the organization of college fairs. ';
