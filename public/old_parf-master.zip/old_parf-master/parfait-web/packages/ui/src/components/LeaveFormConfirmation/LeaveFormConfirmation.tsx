import React, { ContextType, useContext, useEffect, useState, useRef } from 'react';
import type { History, Transition } from 'history';
import { Navigator as BaseNavigator, UNSAFE_NavigationContext as NavigationContext } from 'react-router-dom';
import { useFormikContext } from 'formik';
import { Button, Modal, Stack, Typography } from '@mui/material';
import styled from 'styled-components';

interface Navigator extends BaseNavigator {
  block: History['block'];
}

type NavigationContextWithBlock = ContextType<typeof NavigationContext> & { navigator: Navigator };

export const Container = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 512px;
  background: #fff;
  box-shadow: 3px 5px -1px rgba(0, 0, 0, 0.2), 0px 5px 8px rgba(0, 0, 0, 0.14), 0px 1px 14px rgba(0, 0, 0, 0.12);
  border-radius: 4px;
  padding: 32px;
`;

const LeaveFormConfirmation = () => {
  const [showModal, setShowModal] = useState(false);
  const unblockRef = useRef<any>(null);
  const transitionRef = useRef<any>(null);
  const { dirty, submitForm } = useFormikContext();

  const { navigator } = useContext(NavigationContext) as NavigationContextWithBlock;

  useEffect(() => {
    if (!dirty) {
      return;
    }

    const unblock = navigator.block((tx: Transition) => {
      transitionRef.current = tx;
      unblockRef.current = unblock;
      setShowModal(true);
    });

    return unblock;
  }, [navigator, dirty]);

  return (
    <Modal open={showModal}>
      <Container>
        <Typography
          variant="h5"
          sx={{
            mb: 3,
          }}
          component="div"
        >
          Publish Changes
        </Typography>
        <Typography
          variant="body2"
          sx={{
            mb: 3,
          }}
        >
          You have un-published changes. If you leave the page, your changes will not be saved.
        </Typography>
        <Stack direction="row" spacing={1}>
          <Button
            variant="contained"
            size="small"
            onClick={() => {
              submitForm();
              setShowModal(false);
            }}
          >
            Publish
          </Button>
          <Button
            variant="outlined"
            size="small"
            onClick={() => {
              unblockRef.current();
              transitionRef.current.retry();
            }}
          >
            Continue
          </Button>
        </Stack>
      </Container>
    </Modal>
  );
};

export default LeaveFormConfirmation;
