import { CompletePasswordForm } from './CompletePasswordForm';

export { CompletePasswordForm };
