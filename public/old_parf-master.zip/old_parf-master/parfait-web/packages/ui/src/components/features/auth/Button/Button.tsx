import * as React from 'react';
import { Button as MuiButton, ButtonProps } from '@mui/material';

const Button = (props: ButtonProps) => {
  return (
    <MuiButton
      size="large"
      fullWidth
      variant="contained"
      color="primary"
      sx={{
        backgroundColor: '#1976D2!important',
      }}
      {...props}
    />
  );
};

export default Button;
