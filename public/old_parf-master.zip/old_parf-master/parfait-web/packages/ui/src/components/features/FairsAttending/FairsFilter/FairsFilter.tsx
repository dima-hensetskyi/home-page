import { Button, FormControl, InputLabel, MenuItem, Select } from '@mui/material';
import React, { useState } from 'react';

import { EventRegistrationStatus } from '../../../../types/events';
import { getCorrectString } from '../../utils';
import { useFairsAttendingContext } from '../FairsAttendingContext';

const statuses: EventRegistrationStatus[] = ['CONFIRMED', 'CANCELLED'];

type PropsType = {
  setMenuOpen: React.Dispatch<React.SetStateAction<boolean>>;
};

export const FairsFilter: React.FC<PropsType> = ({ setMenuOpen }: PropsType) => {
  const { setReqVars, reqVars, onClearReqVars } = useFairsAttendingContext();
  const [status, setStatus] = useState<EventRegistrationStatus[]>(reqVars?.filter?.statuses || []);

  const onSubmit = () => {
    setReqVars({ ...reqVars, filter: { ...reqVars.filter, statuses: status } });
    setMenuOpen(false);
  };

  const onClear = () => {
    onClearReqVars('filter');
    setMenuOpen(false);
  };

  return (
    <>
      <FormControl fullWidth size="small" sx={{ marginBottom: '15px' }}>
        <InputLabel id="Status">Status</InputLabel>
        <Select
          multiple
          labelId="Status"
          label="Status"
          value={status}
          onChange={(evt) => {
            const val = evt.target.value;
            const news = Array.isArray(val) ? val : (val.split(',') as unknown as EventRegistrationStatus[]);
            setStatus(news);
          }}
        >
          {statuses.map((status) => (
            <MenuItem key={status} value={status}>
              {getCorrectString(status)}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <Button
        variant="contained"
        fullWidth
        // disabled={!isFiltering}
        sx={{
          background: '#1976D2',
          marginBottom: '15px',
          fontSize: '13px',
          lineHeight: '22px',
          letterSpacing: '0.46px',
        }}
        onClick={onSubmit}
      >
        apply filter
      </Button>
      <Button
        variant="outlined"
        fullWidth
        onClick={onClear}
        sx={{
          color: '#1976D2',
          fontSize: '13px',
          lineHeight: '22px',
          letterSpacing: '0.46px',
        }}
      >
        Clear all
      </Button>
    </>
  );
};
