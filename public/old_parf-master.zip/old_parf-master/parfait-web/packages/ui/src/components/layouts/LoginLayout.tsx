import React from 'react';
import { useTitle } from 'react-use';
import LoginBackground from '../../icons/loginBackground.svg';
import LogoIcon from '../../icons/logo.svg';
import LoginFrameUniversity from '../../icons/loginFrameUniversity.svg';
import LoginFrameHighSchool from '../../icons/loginFrameHighSchool.svg';
import { AppType } from '../../types/general';
import { Wrapper, Container, Logo, FormWrapper, Form, BackgroundImage, Image } from './styled-components';

type Props = {
  title: string;
  children: React.ReactNode;
  type: AppType;
};

const LoginLayout = (props: Props) => {
  const { children, title, type } = props;

  useTitle(title);

  return (
    <Wrapper>
      <Container>
        <Logo>
          <LogoIcon />
        </Logo>
        <FormWrapper>
          <Form>{children}</Form>
        </FormWrapper>
      </Container>
      <BackgroundImage>
        <LoginBackground />
      </BackgroundImage>
      <Image>{type === 'university' ? <LoginFrameUniversity /> : <LoginFrameHighSchool />}</Image>
    </Wrapper>
  );
};

export default LoginLayout;
