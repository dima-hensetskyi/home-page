import React from 'react';
import { Stack } from '@mui/material';
import { useMutation } from 'react-query';
import { API } from 'aws-amplify';
import dayjs from 'dayjs';
import { SmallDialog } from '../../../Dialog';
import { Student } from '../types';
import StudentPendingPreview from './StudentPendingPreview';
import Message from './Message';
import useAuthContext from '../../../containers/auth/useAuthContext';
import { useSnackbar } from 'notistack';
import StudentActivePreview from './StudentActivePreview';
import StudentActiveInfo from './StudentActivePreview/StudentActiveInfo';
import InterestSchools from './InterestSchools';
import FairScans from './FairScans';
import { reinviteStudentPendingQuery } from 'graphql/institutions';

type Props = {
  entity: Student | null;
  onClose: () => void;
  refetch: () => void;
};

const requestStudentAccess = `
    mutation requestStudentAccess($input: RequestStudentAccessInput!){
        requestStudentAccess(input: $input){
            id
        }
    }
`;

const StudentPreview = (props: Props) => {
  const { entity, onClose, refetch } = props;
  const { tenant } = useAuthContext()!;
  const { enqueueSnackbar } = useSnackbar();
  const isStudentPending = entity?.type === 'StudentPending';
  const isStudentActive = entity?.type === 'StudentActive';

  const { institutionId } = tenant!;

  const { mutate: reinvite, isLoading: isReinviteLoading } = useMutation(
    async (id: string) => {
      await API.graphql({
        query: reinviteStudentPendingQuery,
        variables: {
          input: {
            institutionId,
            id,
          },
        },
      });
    },
    {
      onSuccess: () => {
        enqueueSnackbar('Invite successfully sent!', {
          variant: 'success',
        });
        onClose();
        refetch();
      },
    },
  );

  const { mutate: askForPermission, isLoading: isPermissionLoading } = useMutation(
    async (id: string) => {
      await API.graphql({
        query: requestStudentAccess,
        variables: {
          input: {
            institutionId,
            id,
          },
        },
      });
    },
    {
      onSuccess: () => {
        enqueueSnackbar('Permission request successfully sent!', {
          variant: 'success',
        });
        onClose();
        refetch();
      },
    },
  );

  return (
    <SmallDialog
      additionalContent={
        isStudentActive && entity.access === 'GRANTED' ? (
          <div>
            <InterestSchools userId={entity.userId} />
            <FairScans userId={entity.userId} />
          </div>
        ) : null
      }
      content={
        entity ? (
          <div>
            {isStudentActive && (
              <>
                {entity.access === 'GRANTED' ? (
                  <Stack spacing={3}>
                    <StudentActivePreview entity={entity} />
                    <StudentActiveInfo entity={entity} />
                  </Stack>
                ) : null}
                {entity.access === 'NEW' ||
                  (entity.access === 'DECLINED' && (
                    <Stack spacing={3}>
                      <StudentActivePreview entity={entity} />
                      <Message
                        message="Student has not granted permission to profile and college information"
                        btnText="Ask for permission"
                        loading={isPermissionLoading}
                        onClick={() => {
                          askForPermission(entity.id);
                        }}
                      />
                    </Stack>
                  ))}
                {entity.access === 'REQUEST' && (
                  <Stack spacing={3}>
                    <StudentActivePreview entity={entity} />
                    <Message
                      message="Permission request is still pending."
                      btnText="Ask for permission again?"
                      loading={isPermissionLoading}
                      onClick={() => {
                        askForPermission(entity.id);
                      }}
                    />
                  </Stack>
                )}
              </>
            )}
            <Stack spacing={3}>
              {isStudentPending && (
                <>
                  <StudentPendingPreview entity={entity} />
                  <Message
                    message="The student has not yet downloaded the Parfait Mobile App."
                    btnText="Invite again"
                    btnDisabled={dayjs().diff(dayjs(entity.lastInvite), 'day') < 1}
                    disabledTooltipText="Invitation was sent!"
                    loading={isReinviteLoading}
                    onClick={() => {
                      reinvite(entity.id);
                    }}
                  />
                </>
              )}
            </Stack>
          </div>
        ) : null
      }
      open={!!entity}
      lgWidth="320px"
      xlWidth="390px"
      close={() => {
        onClose();
      }}
    />
  );
};

export default StudentPreview;
