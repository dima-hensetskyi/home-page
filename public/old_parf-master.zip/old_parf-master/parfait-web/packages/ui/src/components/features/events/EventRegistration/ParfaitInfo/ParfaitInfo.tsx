import { Box, Button, Stack, Typography } from '@mui/material';
import { Link } from 'react-router-dom';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import React from 'react';

import { List, ListItem } from '../styled-components';
import features from '../features';
import ParfaitLogo from '../../../../ParfaitLogo';
import useAuthContext from '../../../../containers/auth/useAuthContext';

const ParfaitInfo = () => {
  const { authorized } = useAuthContext();

  return (
    <>
      <Box
        sx={{
          mb: 3,
        }}
      >
        <ParfaitLogo />
      </Box>
      <Typography variant="subtitle1" gutterBottom component="div">
        Abilene High School is using Parfait to manage their college fair. Parfait also offers a college management
        companion application for colleges to manage their recruits.
      </Typography>
      <Typography variant="subtitle1" gutterBottom component="div">
        Features include:
      </Typography>
      <List>
        {features.map((feature, index) => {
          return (
            <ListItem key={index}>
              <Stack direction="row" spacing={1} sx={{ alignItems: 'center' }}>
                <CheckBoxIcon
                  style={{
                    color: '#1976D2',
                  }}
                />
                <Typography variant="body2" gutterBottom>
                  {feature}
                </Typography>
              </Stack>
            </ListItem>
          );
        })}
      </List>
      {!authorized && (
        <Button
          component={Link}
          to="/sign-up"
          variant="contained"
          size="large"
          sx={{
            mt: 3,
            width: 368,
          }}
        >
          Sign up for parfait
        </Button>
      )}
    </>
  );
};

export default ParfaitInfo;
