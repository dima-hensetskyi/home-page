import PasswordResetForm from './PasswordResetForm';

export default PasswordResetForm;
