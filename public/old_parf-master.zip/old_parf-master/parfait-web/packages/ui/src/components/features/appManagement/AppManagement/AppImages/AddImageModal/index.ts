import AddImageModal from './AddImageModal';

export default AddImageModal;
