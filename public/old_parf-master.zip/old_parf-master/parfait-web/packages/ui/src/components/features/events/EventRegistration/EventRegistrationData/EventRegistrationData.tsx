import React from 'react';
import { Box, Typography } from '@mui/material';
import dayjs from 'dayjs';
import styled from 'styled-components';
import { Fair } from '../../types';

type Props = {
  data: Fair;
};

const Table = styled.table``;
const Tbody = styled.tbody``;
const Tr = styled.tr`
  &:last-child td {
    padding-bottom: 0;
  }
`;
const Td = styled.td`
  padding-bottom: 12px;
  padding-left: 5px;
  vertical-align: top;
  &:first-child {
    padding-left: 0;
  }
`;

const EventRegistrationData = (props: Props) => {
  const { data } = props;

  return (
    <Typography variant="body2" component="div">
      <Table>
        <Tbody>
          <Tr>
            <Td>Date & Time:</Td>
            <Td>
              {dayjs(data.startDateAndTime).format('LL')} {dayjs(data.startDateAndTime).format('LT')}
              {' - '}
              {dayjs(data.endDateAndTime).format('LT')}
            </Td>
          </Tr>
          {data.organizer && (
            <Tr>
              <Td>Organizer:</Td>
              <Td>{data.organizer.name}</Td>
            </Tr>
          )}
          {data.locationName && (
            <Tr>
              <Td>Location:</Td>
              <Td>{data.locationName}</Td>
            </Tr>
          )}
          {data.address && (
            <Tr>
              <Td>Address:</Td>
              <Td>
                {data.address.address1} {data.address.address2} {data.address.city}, {data.address.stateProvince}{' '}
                {data.address.postalCode}
              </Td>
            </Tr>
          )}
          {data.fee && (
            <Tr>
              <Td>Fee:</Td>
              <Td>{data.fee}</Td>
            </Tr>
          )}
          {data.expectedAttendees && (
            <Tr>
              <Td>Expected attendees:</Td>
              <Td>{data.expectedAttendees}</Td>
            </Tr>
          )}
        </Tbody>
      </Table>
      <Box
        sx={{
          mt: 1.5,
          mb: 5,
        }}
      >
        {data.note}
      </Box>
    </Typography>
  );
};

export default EventRegistrationData;
