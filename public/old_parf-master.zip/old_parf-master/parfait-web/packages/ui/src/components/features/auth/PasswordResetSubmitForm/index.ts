import PasswordResetSubmitForm from './PasswordResetSubmitForm';

export default PasswordResetSubmitForm;
