import React from 'react';
import { Typography, Modal, IconButton } from '@mui/material';
import useAuthContext from '../../../containers/auth/useAuthContext';
import { useMutation, useQueryClient } from 'react-query';
import { API } from 'aws-amplify';
import styled from 'styled-components';
import CloseIcon from '@mui/icons-material/Close';
import { useSnackbar } from 'notistack';
import StudentForm from '../StudentForm';
import { FormValues } from '../types';
import { createStudentPending } from 'graphql/institutions';

type Props = {
  visible: boolean;
  onClose: () => void;
};

const Container = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 370px;
  background: #fff;
  box-shadow: 3px 5px -1px rgba(0, 0, 0, 0.2), 0px 5px 8px rgba(0, 0, 0, 0.14), 0px 1px 14px rgba(0, 0, 0, 0.12);
  border-radius: 4px;
  padding: 32px;
`;

export const ModalHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 24px;
`;

const CreateStudent = (props: Props) => {
  const { visible, onClose } = props;

  const queryClient = useQueryClient();
  const { tenant } = useAuthContext()!;
  const { enqueueSnackbar } = useSnackbar();

  const { institutionId } = tenant!;

  const onSubmit = useMutation(
    async (values: FormValues) => {
      const input: { [key: string]: string } = {
        familyName: values.familyName,
        givenName: values.givenName,
        graduationYear: values.graduationYear,
        institutionId,
      };

      if (values.emailAddress) {
        input.emailAddress = values.emailAddress;
      }

      if (values.phoneNumber) {
        input.phoneNumber = values.phoneNumber;
      }

      await API.graphql({
        query: createStudentPending,
        variables: {
          input,
        },
      });
    },
    {
      onError: (err: { errors: Array<Error> }) => {
        enqueueSnackbar(err?.errors[0]?.message, {
          variant: 'error',
        });
      },
      onSuccess: () => {
        enqueueSnackbar('Invitation sent!', {
          variant: 'success',
        });
        onClose();
      },
      onSettled: () => {
        queryClient.invalidateQueries('getStudents');
      },
      retry: false,
    },
  );

  const initialValues: FormValues = {
    phoneNumber: '',
    emailAddress: '',
    familyName: '',
    givenName: '',
    graduationYear: '',
  };

  return (
    <Modal
      open={visible}
      onClose={onClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Container>
        <ModalHeader>
          <Typography variant="h6">Add Student</Typography>
          <IconButton onClick={onClose}>
            <CloseIcon />
          </IconButton>
        </ModalHeader>
        <StudentForm initialValues={initialValues} onSubmit={onSubmit.mutateAsync} onClose={onClose} />
      </Container>
    </Modal>
  );
};

export default CreateStudent;
