import React, { useState } from 'react';
import { TimePicker as MuiTimePicker } from '@mui/x-date-pickers';
import TextField from '@mui/material/TextField';
import { useFormikContext } from 'formik';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs, { Dayjs } from 'dayjs';
import { FormValues } from '../types';

type Props = {
  label: string;
  name: 'startTime' | 'endTime';
};

const TimePicker = (props: Props) => {
  const { label, name } = props;

  const { setFieldValue, values, errors, touched } = useFormikContext<FormValues>();
  const val = values[name];
  const [value, setValue] = useState<Dayjs | null>(val ? dayjs(val, 'HH:mm') : null);

  const error = errors[name];
  const hasError = !!error && touched[name];

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <MuiTimePicker
        inputFormat="HH:mm"
        disableMaskedInput={true}
        label={label}
        value={value}
        minTime={name === 'endTime' ? dayjs(values['startTime'], 'HH:mm').add(5, 'm') : undefined}
        maxTime={
          name === 'startTime' && values['endTime'] ? dayjs(values['endTime'], 'HH:mm').subtract(5, 'm') : undefined
        }
        onChange={(newValue: Dayjs | null) => {
          setFieldValue(name, newValue ? newValue.format('HH:mm') : newValue);
          setValue(newValue);
        }}
        renderInput={(params) => (
          <TextField {...params} size="small" error={hasError} helperText={hasError ? error : null} />
        )}
      />
    </LocalizationProvider>
  );
};

export default TimePicker;
