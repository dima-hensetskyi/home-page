import React from 'react';
import EditIcon from '@mui/icons-material/Edit';
import styled from 'styled-components';

const Wrapper = styled.div`
  background: rgba(0, 0, 0, 0.6);
  border-radius: 4px;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const EditIconComponent = () => {
  return (
    <Wrapper>
      <EditIcon
        sx={{
          color: '#fff',
        }}
      />
    </Wrapper>
  );
};

export default EditIconComponent;
