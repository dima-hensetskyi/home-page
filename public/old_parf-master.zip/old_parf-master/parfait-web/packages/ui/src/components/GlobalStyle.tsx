import { createGlobalStyle } from 'styled-components';

export const GlobalStyle = createGlobalStyle`
  body {
    min-width: 1024px;
    overflow-x: auto;
  }
  
  .os-scrollbar .os-scrollbar-track {
    background: #e0e0e0 !important;
  }

  .os-scrollbar .os-scrollbar-handle {
    background: #c5c5c5 !important;
  }
`;

export default GlobalStyle;
