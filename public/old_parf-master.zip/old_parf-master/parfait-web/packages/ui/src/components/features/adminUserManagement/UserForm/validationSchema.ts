import * as Yup from 'yup';
import { checkPhoneNumber } from '../api';

export const userSchema = Yup.object().shape({
  givenName: Yup.string().min(1).required('First name is required.'),
  familyName: Yup.string().min(1).required('Last name is required.'),
  username: Yup.string()
    .required('Username must contain a minimum of three characters.')
    .matches(/^[a-z0-9]+$/i, 'Username can only be alphanumeric.')
    .min(3, 'Username must contain a minimum of three characters.'),
  email: Yup.string().required('Valid email is required.').email('Valid email is required.'),
  phoneNumber: Yup.string()
    .notRequired()
    .test('awsPhoneValidation', 'Invalid phone number', async (num) =>
      num ? new Promise((resolve) => checkPhoneNumber(num, resolve)) : true,
    )
    .nullable(),
});
