import { Box } from '@mui/material';
import React from 'react';
import styled from 'styled-components';

import Header from '../Header';
import NavigationMenu from '../NavigationMenu';
import { NavLinkType } from '../NavigationMenu/types';

const Wrapper = styled.div``;

const Content = styled.div`
  padding: 28px 32px;
`;

type PropsType = {
  menuLinks: Array<NavLinkType>;
  children: React.ReactNode;
};

const DashboardLayout: React.FC<PropsType> = ({ children, menuLinks }: PropsType) => {
  return (
    <Wrapper>
      <NavigationMenu menuLinks={menuLinks} />
      <Box sx={{ marginLeft: { xs: '60px', lg: '260px' }, position: 'relative', minHeight: '100vh' }}>
        <Header />
        <Content>{children}</Content>
      </Box>
    </Wrapper>
  );
};

export default DashboardLayout;
