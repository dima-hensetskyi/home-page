import styled from 'styled-components';

export const PrimaryIcon = styled.div`
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  width: 126px;
  height: 126px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;

  img {
    max-width: 95%;
    max-height: 95%;
  }

  input {
    display: none;
  }
`;

export const PrimaryIconWrapper = styled.div`
  display: flex;
`;
