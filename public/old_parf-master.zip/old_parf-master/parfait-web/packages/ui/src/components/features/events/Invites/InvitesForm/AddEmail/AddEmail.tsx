import React from 'react';
import { IconButton, Typography, Stack } from '@mui/material';
import { Field } from 'formik';
import styled from 'styled-components';
import CancelIcon from '@mui/icons-material/Cancel';
import { Formik, Form } from 'formik';
import { TextField as FormikTextField } from 'formik-mui';
import * as Yup from 'yup';

const Container = styled.div``;

const EmailsList = styled.div``;

const Email = styled.div`
  background: #ebebeb;
  display: inline-flex;
  border-radius: 16px;
  margin-right: 8px;
  margin-bottom: 8px;
  padding: 5px 8px 5px 6px;
  align-items: center;
`;

const EmailLabel = styled.span``;

const EmailWrapper = styled.div`
  position: relative;
`;

const AddEmailBtn = styled.div`
  position: absolute;
  right: 15px;
  top: 5px;
`;

type Props = {
  emails: Array<string>;
  setEmails: React.Dispatch<React.SetStateAction<Array<string>>>;
};

const AddEmail = (props: Props) => {
  const { emails, setEmails } = props;

  const deleteEmail = (email: string) => {
    setEmails((state) => {
      return state.filter((item) => {
        return item !== email;
      });
    });
  };

  return (
    <Formik
      initialValues={{ email: '' }}
      validationSchema={Yup.object().shape({
        email: Yup.string().required('Email is required.').email('Please provide valid email.').nullable(),
      })}
      onSubmit={(values, { resetForm }) => {
        if (
          !emails.find((email) => {
            return email === values.email;
          })
        ) {
          setEmails((state) => {
            return [...state, values.email];
          });
        }
        resetForm();
      }}
    >
      {({ submitForm }) => {
        return (
          <Form>
            <Container>
              <Stack spacing={1}>
                <EmailWrapper>
                  <Field
                    fullWidth
                    component={FormikTextField}
                    name="email"
                    label="Email addresses"
                    type="email"
                    size="small"
                  />
                  <AddEmailBtn>
                    <IconButton aria-label="Add email addresses" onClick={submitForm} edge="end">
                      <svg width="16" height="12" viewBox="0 0 16 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                          d="M0.295693 8.71181L3.29461 11.7118C3.43518 11.8506 3.61369 11.9446 3.8076 11.9819C4.00152 12.0193 4.20216 11.9984 4.38421 11.9218C4.56676 11.8468 4.72303 11.7194 4.83333 11.5557C4.94362 11.392 5.003 11.1992 5.00399 11.0018L5.00399 9.00181L8.0029 9.00181C10.1239 9.00181 12.158 8.15896 13.6577 6.65867C15.1575 5.15838 16 3.12355 16 1.00181C16 0.736597 15.8947 0.482243 15.7072 0.294706C15.5197 0.10717 15.2655 0.00181382 15.0004 0.0018138C14.7352 0.00181378 14.481 0.10717 14.2935 0.294706C14.106 0.482242 14.0007 0.736597 14.0007 1.00181C14.0007 2.59311 13.3688 4.11924 12.244 5.24445C11.1192 6.36967 9.59362 7.00181 8.0029 7.00181L5.00399 7.00181L5.00399 5.00181C5.003 4.80439 4.94362 4.61167 4.83333 4.44795C4.72303 4.28423 4.56676 4.15683 4.38421 4.08181C4.26557 4.02583 4.13548 3.99843 4.00435 4.00181C3.87279 4.00105 3.74237 4.02628 3.62058 4.07604C3.49879 4.12581 3.38801 4.19913 3.29461 4.29181L0.295693 7.29181C0.201998 7.38478 0.12763 7.49538 0.0768789 7.61724C0.0261282 7.73909 3.61073e-07 7.8698 3.49533e-07 8.00181C3.37992e-07 8.13382 0.0261281 8.26453 0.0768789 8.38639C0.12763 8.50825 0.201998 8.61885 0.295693 8.71181Z"
                          fill="#757575"
                        />
                      </svg>
                    </IconButton>
                  </AddEmailBtn>
                </EmailWrapper>
                <EmailsList>
                  {emails.map((email, index) => {
                    return (
                      <Email key={index}>
                        <EmailLabel>
                          <Typography variant="body2">
                            <span
                              style={{
                                fontSize: 13,
                                lineHeight: 1,
                                color: '#000',
                              }}
                            >
                              {email}
                            </span>
                          </Typography>
                        </EmailLabel>
                        <IconButton
                          aria-label="Delete email addresses"
                          onClick={() => {
                            deleteEmail(email);
                          }}
                          edge="end"
                          sx={{
                            paddingTop: 0,
                            paddingBottom: 0,
                          }}
                        >
                          <CancelIcon
                            style={{
                              color: '#AEAEAE',
                            }}
                          />
                        </IconButton>
                      </Email>
                    );
                  })}
                </EmailsList>
              </Stack>
            </Container>
          </Form>
        );
      }}
    </Formik>
  );
};

export default AddEmail;
