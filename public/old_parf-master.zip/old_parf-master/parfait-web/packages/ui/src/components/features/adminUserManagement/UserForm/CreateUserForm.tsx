import { useMutation, useQueryClient } from 'react-query';
import { useSnackbar } from 'notistack';
import React, { useState } from 'react';

import { checkTenantUser, createNewTenantUser } from '../api';
import { Loader } from '../../../Loader';
import { TenantUsersRequestVariablesType } from '../type';
import { UserForm, userFormVariablesType } from './UserForm';

type TypeProps = {
  onClose: () => void;
  queryId: (string | TenantUsersRequestVariablesType)[];
};

type newUserVariables = {
  email: string;
  familyName: string;
  givenName: string;
  role: string;
  username: string;
  phoneNumber?: string;
};

export const CreateUserForm: React.FC<TypeProps> = ({ onClose, queryId }: TypeProps) => {
  const [userFormVariables, setUserFormVariables] = useState<userFormVariablesType | null>(null);

  const queryClient = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();

  const createNewUser = useMutation(createNewTenantUser, {
    onError: () => {
      enqueueSnackbar('Something went wrong', {
        variant: 'error',
      });
    },
    onSuccess: () => {
      enqueueSnackbar('User successfully created!', {
        variant: 'success',
      });
      setUserFormVariables(() => null);
      onClose();
    },
    onSettled: () => {
      queryClient.invalidateQueries(queryId);
    },
  });

  const checkUser = useMutation(checkTenantUser, {
    onSuccess: (isAvailable, variables) => {
      isAvailable ? createUser(variables.user) : enqueueSnackbar('Username is not available', { variant: 'error' });
    },
  });

  const createUser = (values: userFormVariablesType | null) => {
    if (!values) return;
    const { email, familyName, givenName, phoneNumber, role, username } = values;

    let newUserVariables: newUserVariables = {
      email,
      familyName,
      givenName,
      role,
      username,
    };

    if ('phoneNumber' in values && phoneNumber) {
      const phoneNumber = `+1${values.phoneNumber.replace(/[^\d]/g, '')}`;
      newUserVariables = { ...newUserVariables, phoneNumber };
    }
    const vars = { input: newUserVariables };
    createNewUser.mutateAsync(vars);
  };

  const onSubmitForm = (values: userFormVariablesType) => {
    const { username, email } = values;
    setUserFormVariables(() => values);
    checkUser.mutateAsync({ email, username, user: values });
  };

  return createNewUser.isLoading || checkUser.isLoading ? (
    <Loader />
  ) : (
    <UserForm
      type="Create"
      onClose={onClose}
      initialFormValues={userFormVariables || undefined}
      onSubmit={onSubmitForm}
    />
  );
};
