import React from 'react';
import { Slider } from '@mui/material';
import styled from 'styled-components';

type Props = {
  min: number;
  max: number;
  step: number;
  value: number;
  iconPlus: JSX.Element;
  iconMinus: JSX.Element;
  onChange: (value: number) => void;
};

const Container = styled.div`
  display: flex;
  align-items: center;
  width: 100%;

  button {
    padding: 0;
    margin: 0;
    width: 25px;
    height: 25px;
    background: transparent;
    border: none;
    outline: none;
    font-size: 20px;

    &:hover {
      color: var(--primary-color);
    }
  }
`;

const ImageEditorControl = (props: Props) => {
  const { min, max, step, value, onChange, iconPlus, iconMinus } = props;

  return (
    <Container>
      <button
        type="button"
        disabled={value <= min}
        onClick={(): void => {
          onChange(value - step);
        }}
      >
        {iconMinus}
      </button>
      <Slider
        min={min}
        max={max}
        value={value}
        step={step}
        onChange={(event, val): void => {
          onChange(val as number);
        }}
      />
      <button
        type="button"
        disabled={value >= max}
        onClick={(): void => {
          onChange(value + step);
        }}
      >
        {iconPlus}
      </button>
    </Container>
  );
};

export default ImageEditorControl;
