import { useInfiniteQuery } from 'react-query';
import { fetchTenantsUsers } from '../../adminUserManagement/api';
import { TenantUsersRequestVariablesType } from '../../adminUserManagement/type';

export const useTenantUsers = (reqVars: TenantUsersRequestVariablesType) => {
  const queryId = ['GetTenantUsers', reqVars];
  return useInfiniteQuery(
    queryId,
    (data) => fetchTenantsUsers(data.pageParam ? { ...reqVars, nextToken: data.pageParam } : reqVars),
    {
      keepPreviousData: true,
      retry: false,
      getNextPageParam: (lastPage) => lastPage?.nextToken,
    },
  );
};
