import { TextAlignment } from '../../../../../../types/general';

export type ImageFormValues = {
  alignment: TextAlignment;
  message: string;
  imageAltText: string;
  order: number;
};

export type InstitutionTemporaryImage = {
  id: number;
  image: File;
  alignment: TextAlignment;
  message: string;
  imageAltText: string;
  order: number;
};
