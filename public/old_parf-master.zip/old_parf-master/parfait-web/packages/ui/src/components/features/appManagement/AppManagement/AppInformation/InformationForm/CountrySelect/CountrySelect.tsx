import React from 'react';
import isoCountryCodes from './country-codes';
import { MenuItem, Select, InputLabel, FormControl } from '@mui/material';
import { useFormikContext } from 'formik';
import { FormValues } from '../types';

const CountrySelect = () => {
  const { values, setFieldValue } = useFormikContext<FormValues>();

  return (
    <FormControl>
      <InputLabel id="test-select-label">Country</InputLabel>
      <Select
        labelId="test-select-label"
        size="small"
        label="Country"
        value={values.alphaTwoCode}
        onChange={(evt) => {
          const country = isoCountryCodes.find((country) => {
            return country.alphaTwoCode === evt.target.value;
          })!;

          setFieldValue('alphaTwoCode', country.alphaTwoCode);
          setFieldValue('country', country.name);
        }}
      >
        {isoCountryCodes.map((country) => (
          <MenuItem key={country.numeric} value={country.alphaTwoCode}>
            {country.name}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default CountrySelect;
