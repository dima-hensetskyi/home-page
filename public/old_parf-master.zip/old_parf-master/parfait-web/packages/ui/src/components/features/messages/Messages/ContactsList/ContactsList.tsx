import React from 'react';
import styled from 'styled-components';
import { Virtuoso } from 'react-virtuoso';
import ContactItem from './ContactItem';
import useMessagesContext from '../../../../containers/messages/usemMessagesContext';
import CustomScrollbar from '../CustomScrollbar';

const ListItem = styled.div`
  border-bottom: 1px solid #d1d5dc;
`;

const Wrapper = styled.div`
  background: #f5f5f5;
  border: 1px solid #d1d5dc;
  border-radius: 4px;
  overflow: hidden;
`;

const ContactsList = () => {
  const { activeContact, setActiveContact, chats, endReached, messagesHeight } = useMessagesContext();

  return (
    <Wrapper>
      <Virtuoso
        components={{
          // @ts-ignore
          Scroller: CustomScrollbar,
        }}
        overscan={200}
        style={{ height: messagesHeight }}
        endReached={endReached}
        data={chats}
        itemContent={(index, chat) => {
          return (
            <ListItem key={chat.id}>
              <ContactItem
                active={activeContact === chat.id}
                chat={chat}
                onClick={() => {
                  setActiveContact(chat.id);
                }}
              />
            </ListItem>
          );
        }}
      />
    </Wrapper>
  );
};

export default ContactsList;
