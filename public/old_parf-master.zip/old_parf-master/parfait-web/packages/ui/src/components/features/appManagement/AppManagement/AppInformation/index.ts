import AppInformation from './AppInformation';

export default AppInformation;
