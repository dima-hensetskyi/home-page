import { hightSchoolMessage, collegeInviteMessage } from './data';
export { hightSchoolMessage, collegeInviteMessage };
