import React, { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { LinearProgress, Alert, Stack } from '@mui/material';
import AuthHeader from '../AuthHeader';
import PasswordInput from '../PasswordInput';
import { Formik, Form, Field, FormikHelpers } from 'formik';
import { TextField as FormikTextField } from 'formik-mui';
import useAuthContext from '../../../containers/auth/useAuthContext';
import passwordResetSubmitFormSchema from './validationSchema';
import { Container, Error } from '../styledComponents';
import Button from '../Button';
import PasswordField from '../RegistrationForm/PasswordField';

const PasswordResetSubmitForm = () => {
  const [error, setError] = useState<string | null>(null);
  const { forgotPasswordSubmit, signIn } = useAuthContext();

  const [searchParams] = useSearchParams();
  const userName = searchParams.get('username');
  const account = searchParams.get('account');

  const initialValues = {
    code: '',
    password: '',
    passwordConfirm: '',
  };

  const onSubmit = async (values: typeof initialValues, { setSubmitting }: FormikHelpers<typeof initialValues>) => {
    const { code, password, passwordConfirm } = values;
    setError(null);

    if (password.trim() !== passwordConfirm.trim()) {
      setError('Confirm Password does not match New Password');
    } else {
      try {
        await forgotPasswordSubmit(userName!, code, password);
        await signIn(account!, userName!, password);
      } catch (e) {
        setError('Your email or password were incorrect.');
        setSubmitting(false);
        return;
      }
    }
  };

  return (
    <Container>
      <AuthHeader title="New Password" description="Please enter a new password for your account." />
      <Formik validationSchema={passwordResetSubmitFormSchema} initialValues={initialValues} onSubmit={onSubmit}>
        {({ isSubmitting }) => (
          <Form>
            <Stack spacing={2}>
              <Field fullWidth component={FormikTextField} name="code" label="Code" type="text" />
              <PasswordField label="New Password" />
              <PasswordInput fullWidth name="passwordConfirm" label="Confirm New Password" />
            </Stack>
            <Stack
              spacing={1}
              sx={{
                marginTop: '24px',
              }}
            >
              {error && (
                <Error>
                  <Alert severity="error">{error}</Alert>
                </Error>
              )}
              <div>
                {isSubmitting && <LinearProgress />}
                <Button type="submit">Save</Button>
              </div>
            </Stack>
          </Form>
        )}
      </Formik>
    </Container>
  );
};

export default PasswordResetSubmitForm;
