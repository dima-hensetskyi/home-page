import React from 'react';
import { Grid, Box } from '@mui/material';
import InformationForm from './InformationForm/InformationForm';
import CollegeInfo from './CollegeInfo';

const AppInformation = () => {
  return (
    <Box
      sx={{
        mt: 3,
        maxWidth: 900,
      }}
    >
      <Grid container spacing={3}>
        <Grid item xs={5}>
          <InformationForm />
        </Grid>
        <Grid item xs={7}>
          <CollegeInfo />
        </Grid>
      </Grid>
    </Box>
  );
};

export default AppInformation;
