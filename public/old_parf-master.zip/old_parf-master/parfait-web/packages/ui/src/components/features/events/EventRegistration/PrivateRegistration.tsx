import { API } from 'aws-amplify';
import { Field, Form, Formik } from 'formik';
import { createEventRegistrationByForm, updateEventRegistrationByForm, getEvent, getEventInvite } from 'graphql/events';
import { TextField as FormikTextField } from 'formik-mui';
import { Typography, Grid, Stack } from '@mui/material';
import { useParams, useSearchParams } from 'react-router-dom';
import { useQuery } from 'react-query';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useState } from 'react';
import { FormContainer, Container } from './styled-components';
import { GetEventResponse, GetEventInviteResponse } from '../types';
import { InstitutionInfo } from '../../auth/RegistrationForm/types';
import EventRegistrationData from './EventRegistrationData';
import FullPageLoader from '../../../FullPageLoader';
import ParfaitInfo from './ParfaitInfo';
import SchoolSelect from '../../auth/RegistrationForm/SchoolSelect';
import validationSchema from './validationSchema';

type FormValues = {
  name: string;
  email: string;
  school: string;
};

const PrivateRegistration = () => {
  const params = useParams();
  const [searchParams] = useSearchParams();
  const id = params.id;
  const eventInviteId = searchParams.get('eventInviteId');
  const email = searchParams.get('email');

  const [declinePressed, setDeclinePressed] = useState(false);
  const [registered, setRegistered] = useState(false);
  const [institution, setInstitution] = useState<InstitutionInfo | null>(null);

  const { data, status } = useQuery(['getEvent', id], async () => {
    const response = (await API.graphql({
      query: getEvent,
      variables: {
        id,
      },
    })) as GetEventResponse;

    return response.data.event;
  });

  const initialValues = {
    name: '',
    email: email!,
    school: '',
  };

  const onSubmit = async (values: FormValues) => {
    if (!institution) return undefined;

    const eventInvite = (await API.graphql({
      query: getEventInvite,
      variables: {
        eventId: id,
        id: eventInviteId,
      },
    })) as GetEventInviteResponse;

    /**
     * Update current registration If exist
     */
    if (eventInvite.data.getEventInvite.registration) {
      await API.graphql({
        query: updateEventRegistrationByForm,
        variables: {
          input: {
            //id: eventInviteId,
            id: eventInvite.data.getEventInvite.registration.id,
            eventId: id,
            status: declinePressed ? 'CANCELLED' : 'CONFIRMED',
          },
        },
      });
    } else {
      await API.graphql({
        query: createEventRegistrationByForm,
        variables: {
          input: {
            eventInviteId,
            eventId: id,
            status: declinePressed ? 'CANCELLED' : 'CONFIRMED',
            registeredEmail: values.email,
            registeredInstitutionId: institution.institutionId,
            registeredName: values.name,
            registeredInstitutionName: institution.institutionName!,
          },
        },
      });
    }

    setRegistered(true);
  };

  if (status === 'loading') {
    return <FullPageLoader />;
  }

  return (
    <Container>
      {data ? (
        <>
          <Typography
            variant="h6"
            component="div"
            sx={{
              mb: 0.5,
            }}
          >
            Your college has been invited to...
          </Typography>
          <Typography
            variant="h4"
            component="div"
            sx={{
              mb: 0.5,
            }}
          >
            {data.name}
          </Typography>
          <Typography
            variant="caption"
            display="block"
            gutterBottom
            sx={{
              mb: 5,
              maxWidth: 450,
              color: '#666',
            }}
          >
            {data.description}
          </Typography>
        </>
      ) : null}
      <Grid container spacing={4}>
        <Grid item md={6}>
          {data ? (
            <FormContainer>
              <EventRegistrationData data={data} />
              {registered ? (
                <Typography variant="subtitle1" gutterBottom component="div">
                  {declinePressed
                    ? `We’re sorry you are unable to attend ${data.name}!`
                    : `You have successfully registered for ${data.name}!`}
                </Typography>
              ) : (
                <Formik validationSchema={validationSchema} initialValues={initialValues} onSubmit={onSubmit}>
                  {({ submitForm, isSubmitting }) => (
                    <Form>
                      <Stack spacing={3}>
                        <Stack spacing={2}>
                          <Field fullWidth component={FormikTextField} name="name" label="Your name" type="text" />
                          <Field fullWidth component={FormikTextField} name="email" label="Email" type="text" />
                          <SchoolSelect
                            institutionInfo={institution}
                            setInstitutionInfo={setInstitution}
                            appType="university"
                          />
                        </Stack>
                        {data.status === 'CANCELLED' && (
                          <Typography variant="subtitle1" gutterBottom component="div">
                            Registration canceled!
                          </Typography>
                        )}
                        {data.status === 'REGISTRATION_CLOSED' && (
                          <Typography variant="subtitle1" gutterBottom component="div">
                            Registration closed!
                          </Typography>
                        )}
                        <Stack spacing={1} direction="row">
                          <LoadingButton
                            onClick={() => {
                              setDeclinePressed(false);
                              submitForm();
                            }}
                            fullWidth
                            variant="contained"
                            size="large"
                            loading={isSubmitting && !declinePressed}
                            disabled={data.status === 'CANCELLED' || data.status === 'REGISTRATION_CLOSED'}
                          >
                            Register
                          </LoadingButton>
                          <LoadingButton
                            onClick={() => {
                              setDeclinePressed(true);
                              submitForm();
                            }}
                            fullWidth
                            variant="outlined"
                            size="large"
                            loading={isSubmitting && declinePressed}
                            disabled={data.status === 'CANCELLED' || data.status === 'REGISTRATION_CLOSED'}
                          >
                            Decline
                          </LoadingButton>
                        </Stack>
                      </Stack>
                    </Form>
                  )}
                </Formik>
              )}
            </FormContainer>
          ) : null}
        </Grid>
        <Grid item md={6}>
          <ParfaitInfo />
        </Grid>
      </Grid>
    </Container>
  );
};

export default PrivateRegistration;
