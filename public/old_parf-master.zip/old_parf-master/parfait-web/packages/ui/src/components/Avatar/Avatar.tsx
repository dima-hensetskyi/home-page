import { Avatar, SxProps, Theme, Typography } from '@mui/material';
import React from 'react';

import { getAvatarColor, getNameInitial } from './utils';
import { S3Object } from '../../types/general';
import { useUserAvatar } from './useUserAvatar';
import theme from '../../theme';

type PropsType = {
  name?: string;
  sx?: SxProps<Theme>;
  avatar?: S3Object;
  id?: string;
};

export const AvatarComponent = ({ name, sx, avatar }: PropsType) => {
  const { data } = useUserAvatar(avatar);
  const bgcolor = name ? getAvatarColor(name) : null;
  const color = bgcolor ? theme.palette.getContrastText(bgcolor) : '#FFFFFF';

  const avatarProps = {
    sx: {
      bgcolor,
      // color,
      ...sx,
    },
    alt: name ? `${name} avatar` : 'User avatar',
  };

  const nameInitial = name && getNameInitial(name);

  return (
    <Avatar src={data} {...avatarProps}>
      {!data && nameInitial && (
        <Typography sx={{ color }} variant="overline">
          {nameInitial}
        </Typography>
      )}
    </Avatar>
  );
};
