import React from 'react';
import { Typography } from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';

import styled from 'styled-components';

const Container = styled.div`
  height: 200px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;

const MessagesLoading = () => {
  return (
    <Container>
      <CircularProgress
        sx={{
          mb: 2,
        }}
      />
      <Typography variant="body1" gutterBottom component="div">
        Loading chats...
      </Typography>
    </Container>
  );
};

export default MessagesLoading;
