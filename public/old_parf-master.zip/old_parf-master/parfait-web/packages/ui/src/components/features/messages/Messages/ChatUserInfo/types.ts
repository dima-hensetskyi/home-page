export type GetRecruitForUserResponse = {
  data: {
    recruit: Recruit;
  };
};

export type Recruit = {
  createdAt: string;
  id: string;
  recruitCohort: { name: string };
  recruitCohortId: string;
  status: string;
  user: { givenName: string; familyName: string };
  userId: string;
  assignedTenantUser: null | {
    id: string;
    username: string;
  };
};

export type QuestionCategory = 'ACADEMICS' | 'GENERAL' | 'INTEREST' | 'MAJORS';

export type Questions = Array<{
  category: QuestionCategory;
  id: string;
  name: string;
  question: string;
  type: 'SINGLE_INPUT' | 'MULTIPLE_CHOICE' | 'REGIONS';
}>;

export type UserAnswers = Array<{
  answers: string[];
  question: {
    id: string;
    name: string;
  };
}>;

export type UserInfoState = {
  questions: Questions;
  userAnswers: UserAnswers;
  recruit: Recruit | null;
  user: any;
};

export type GetQuestionsResponse = {
  data: {
    questions: {
      items: Questions;
    };
  };
};

export type UserAnswersResult = {
  data: {
    getUser: {
      userQuestions: UserAnswers;
    };
  };
};
