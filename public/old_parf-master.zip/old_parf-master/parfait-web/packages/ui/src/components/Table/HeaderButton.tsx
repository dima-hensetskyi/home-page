import { Box, TableSortLabel } from '@mui/material';
import { visuallyHidden } from '@mui/utils';
import React from 'react';
import { StyledTableCell } from './TableComponent.styled';
import { ItemsFromObj } from './types';

type PropsType<T extends object> = {
  headersArray: ItemsFromObj<T>;
  headerLabel?: string;
  orderBy: string;
  order: 'ASC' | 'DESC';
  sortedRows: string[] | [];
  onSortLabel?: () => void;
  onMouseSortLabel?: () => void;
};

export function HeaderButton<T extends object>({
  headersArray,
  headerLabel,
  orderBy,
  order,
  sortedRows,
  onSortLabel,
  onMouseSortLabel,
}: PropsType<T>) {
  const key = Object.entries(headersArray).find((item) => item[1] === headerLabel);
  const headerName = key && key[0];
  const isOrderedHeader = headerName === orderBy;
  const currentOrder = order === 'ASC' ? 'asc' : 'desc';
  const AlternativeOrder = currentOrder === 'asc' ? 'desc' : 'asc';
  const isSortedRow = sortedRows.some((header) => header === headerName) || isOrderedHeader;

  return (
    <StyledTableCell sx={{ py: { xs: '6px', lg: '16px' } }} key={headerLabel}>
      {isSortedRow ? (
        <TableSortLabel
          active={isOrderedHeader}
          direction={isOrderedHeader ? currentOrder : AlternativeOrder}
          onClick={() => isOrderedHeader && onSortLabel && onSortLabel()}
          onMouseEnter={() => isOrderedHeader && onMouseSortLabel && onMouseSortLabel()}
        >
          {headerLabel}
          {isOrderedHeader ? (
            <Box component="span" sx={visuallyHidden}>
              {currentOrder === 'desc' ? 'sorted descending' : 'sorted ascending'}
            </Box>
          ) : null}
        </TableSortLabel>
      ) : (
        <span>{headerLabel}</span>
      )}
    </StyledTableCell>
  );
}
