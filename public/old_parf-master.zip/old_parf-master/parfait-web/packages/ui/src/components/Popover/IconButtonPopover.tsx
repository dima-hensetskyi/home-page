import { Box, IconButton, Popover } from '@mui/material';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import React, { useState } from 'react';

type PropsType = {
  children: React.ReactNode;
};

export const IconButtonPopover: React.FC<PropsType> = ({ children }: PropsType) => {
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  return (
    <>
      <IconButton sx={{ width: '30px', height: '30px' }} onClick={handleClick} aria-label="Button for popover">
        <InfoOutlinedIcon fontSize="small"></InfoOutlinedIcon>
      </IconButton>
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
      >
        <Box sx={{ p: 2 }}>{children}</Box>
      </Popover>
    </>
  );
};
