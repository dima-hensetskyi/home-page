import RegistrationsView from './RegistrationsView';

export default RegistrationsView;
