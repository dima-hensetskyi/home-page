import { API } from 'aws-amplify';
import { getUser } from 'graphql/users';
import { GetQuestionsResponse, GetRecruitForUserResponse, UserAnswersResult } from './types';

export const getQuestions = /* GraphQL */ `
  query GetQuestions {
    questions: getQuestions {
      items {
        category
        id
        name
        question
        type
      }
    }
  }
`;

const getUserQuestions = /* GraphQL */ `
  query GetUser($id: ID!) {
    getUser(id: $id) {
      userQuestions {
        question {
          id
          name
        }
        answers
      }
      userResumeItems {
        id
        resumeItemId
        type
        name
        description
        organization
        startDate
        endDate
        createdAt
        updatedAt
      }
      userInstitutionAlmaMaters {
        id
        institutionId
        institution {
          id
          name
          tenantId
        }
        status
        name
        startDate
        endDate
        createdAt
        updatedAt
      }
    }
  }
`;

const getRecruitForUser = /* GraphQL */ `
  query GetRecruitForUser($userId: ID!) {
    recruit: getRecruitForUser(userId: $userId) {
      id
      status
      createdAt
      userId
      user {
        givenName
        familyName
      }
      recruitCohortId
      recruitCohort {
        name
      }
      assignedTenantUser {
        id
        username
      }
    }
  }
`;

export const fetchRecruit = async (chatUserId: string) => {
  try {
    const recruit = (await API.graphql({
      query: getRecruitForUser,
      variables: {
        userId: chatUserId,
      },
    })) as GetRecruitForUserResponse;

    return recruit.data.recruit;
  } catch {
    return null;
  }
};

export const fetchGetQuestions = async () => {
  const result = (await API.graphql({
    query: getQuestions,
  })) as GetQuestionsResponse;

  return result.data.questions.items;
};

export const fetchUserAnswers = async (chatUserId: string) => {
  const userAnswersResult = (await API.graphql({
    query: getUserQuestions,
    variables: {
      id: chatUserId,
    },
  })) as UserAnswersResult;
  return userAnswersResult.data.getUser.userQuestions;
};

export const fetchUser = async (chatUserId: string) => {
  const userResult = await API.graphql({
    query: getUser,
    variables: {
      id: chatUserId,
    },
  });
  // @ts-ignore
  return userResult.data.getUser;
};
