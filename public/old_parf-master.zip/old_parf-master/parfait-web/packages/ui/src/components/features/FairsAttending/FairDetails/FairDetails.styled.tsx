import { Box, styled, Typography } from '@mui/material';
import { Select } from 'formik-mui';

export const ListItem = styled(Box)(() => ({
  display: 'flex',
  gap: '32px',
})) as typeof Box;

export const ListItemTitle = styled(Typography)(() => ({
  minWidth: '140px',
  color: '#00000099',
})) as typeof Typography;

export const ListItemBody = styled(Typography)(() => ({
  flex: 1,
  maxWidth: '280px',
  color: '#000000DE',
  maxHeight: '124px',
  overflowY: 'auto',
})) as typeof Typography;
