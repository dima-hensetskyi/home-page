import SecondaryImages from './SecondaryImages';

export default SecondaryImages;
