import { SearchComponent } from './SearchComponent';
export { SearchComponent };
