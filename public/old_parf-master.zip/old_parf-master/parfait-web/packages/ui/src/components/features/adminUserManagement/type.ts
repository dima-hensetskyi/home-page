import { S3Object } from './../../../types/general';
import { userFormVariablesType } from './UserForm/UserForm';

export type TenantUserResponseType = {
  username: string;
  status: string;
  id: string;
  name: string;
  createdAt: string;
  givenName: string;
  familyName: string;
  updatedAt: string;
  email: string | undefined;
  phoneNumber: string;
  lastAuthentication: string | null;
  role: string;
  avatar: S3Object;
};

export type UpdateTenantUserResponseType = {
  updateTenantUser: TenantUserResponseType;
};

export type CreateTenantUserResponseType = {
  createTenantUser: TenantUserResponseType;
};

export type TenantUsersResponseType = {
  getTenantUsers: {
    items: Array<TenantUserResponseType>;
    nextToken: string;
  };
};

export type UserListItem = {
  username: string;
  status: string;
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  email: string | undefined;
  phoneNumber: string;
  lastAuthentication: string | null;
  role: string;
  fullDetail: TenantUserResponseType;
  avatar: S3Object;
};

export type UpdateUserInputType = {
  input: {
    id: string;
    status?: string;
    email?: string;
    phoneNumber?: string;
    role?: string;
    givenName?: string;
  };
};

export type CreateUserInputType = {
  input: {
    email: string;
    phoneNumber?: string;
    role: string;
    givenName: string;
    familyName: string;
    username: string;
  };
};

export type GetTenantUserAvailableInput = {
  username: string;
  email: string;
  user: userFormVariablesType;
};

export type GetTenantUserAvailableResponse = {
  getTenantUserAvailable: boolean;
};

export type TenantUsersRequestVariablesType = {
  limit?: number;
  sortDirection: 'ASC' | 'DESC';
  nextToken?: string | null;
};

export type GetTenantsUsersQuery = {
  pageParams: [];
  pages: Array<{ items: TenantUserResponseType[]; nextToken: string }>;
};

export type GetTenantsUsersQueryType = {
  items: TenantUserResponseType[];
  nextToken: null | string;
};
