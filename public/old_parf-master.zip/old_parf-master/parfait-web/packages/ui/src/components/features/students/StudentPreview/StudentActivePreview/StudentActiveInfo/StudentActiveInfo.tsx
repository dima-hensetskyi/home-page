import React from 'react';
import { useQuery } from 'react-query';
import { Box, Stack } from '@mui/material';
import { QuestionCategory, Questions, UserAnswers } from '../../../../messages/Messages/ChatUserInfo/types';
import { fetchGetQuestions, fetchUserAnswers, fetchUser } from '../../../../messages/Messages/ChatUserInfo/api';
import { AttributesData } from '../../../../../Attributes/Attributes';
import Attributes from '../../../../../Attributes';
import { StudentActive } from '../../../types';
import CircularProgress from '@mui/material/CircularProgress';

type Props = {
  entity: StudentActive;
};

type InstitutionAlmaMaters = {
  id: string;
  name: string;
  tenantId: string;
  address: {
    city: string;
    address1: string;
    stateProvince: string;
  };
};

const NO_DATA = '---';

const StudentActiveInfo = (props: Props) => {
  const { entity } = props;

  const { userId } = entity;

  const { data } = useQuery<{ questions: Questions; userAnswers: UserAnswers; user: any }>(
    ['StudentActiveInfo', userId],
    async () => {
      const [questions, answers, user] = await Promise.all([
        fetchGetQuestions(),
        fetchUserAnswers(userId),
        fetchUser(userId),
      ]);

      return {
        userAnswers: answers,
        questions,
        user,
      };
    },
  );

  if (!data) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center' }}>
        <CircularProgress size="20px" />
      </Box>
    );
  }

  const { questions, userAnswers, user } = data;

  const getAnswersByCategory = (
    category: QuestionCategory,
  ): Array<{
    label: string;
    value: string | number;
  }> => {
    const result: AttributesData = [];

    if (!data) return result;

    const questionsByCategory = questions.filter((question) => {
      return question.category === category;
    });

    return questionsByCategory.reduce((acc: AttributesData, question) => {
      const res = userAnswers.find((answers) => {
        return answers.question.id === question.id;
      });

      acc.push({
        label: question.name,
        value: res ? res!.answers.join(', ') : NO_DATA,
      });

      return acc;
    }, []);
  };

  const graduationQuestion = questions && questions.find((question) => question.name === 'Graduation Year');
  const graduationYear =
    graduationQuestion && userAnswers.find((answer) => answer.question.id === graduationQuestion?.id);

  const getUserInstitutionAlmaMaters = (): InstitutionAlmaMaters | null => {
    if (user.userInstitutionAlmaMaters.length > 0) {
      return user.userInstitutionAlmaMaters[user.userInstitutionAlmaMaters.length - 1];
    }

    return null;
  };

  const getUserInstitutionName = () => {
    const institution = getUserInstitutionAlmaMaters();

    if (institution) {
      return institution.name;
    }

    return NO_DATA;
  };

  const getUserInstitutionLocation = () => {
    const institution = getUserInstitutionAlmaMaters();

    if (institution && institution.address) {
      const result = [];

      if (institution.address.city) {
        result.push(institution.address.city);
      }
      if (institution.address.address1) {
        result.push(institution.address.address1);
      }
      return result.join(', ');
    }

    return NO_DATA;
  };

  return (
    <Stack spacing={3}>
      <Attributes
        title="App Stats"
        labelWidth={120}
        data={[
          {
            label: 'Favorites',
            value: entity.stats.favorites,
          },
          {
            label: 'Short list',
            value: entity.stats.shortLists,
          },
          {
            label: 'Fair scans',
            value: entity.stats.scans,
          },
        ]}
      />
      <Attributes
        labelWidth={120}
        title="Profile"
        data={[
          {
            label: 'Graduation year',
            value: graduationYear?.answers.join(',') || NO_DATA,
          },
          {
            label: 'Current school',
            value: getUserInstitutionName(),
          },
          {
            label: 'Location',
            value: getUserInstitutionLocation(),
          },
        ]}
      />
      <Attributes labelWidth={120} title="Academics" data={getAnswersByCategory('ACADEMICS')} />
      <Attributes
        labelWidth={120}
        title="Interests"
        data={[...getAnswersByCategory('INTEREST'), ...getAnswersByCategory('INTEREST')]}
      />
    </Stack>
  );
};

export default StudentActiveInfo;
