import { useQuery } from 'react-query';
import { EventRegistrationAssignmentsType } from '../../../../types/events';
import { getEventAssignments } from '../api';

export const useAssignStaff = (eventId: string, initialData: EventRegistrationAssignmentsType[]) => {
  const assignStaffVars = {
    eventRegistrationId: eventId,
  };

  const staffQueryId = ['GetEventAssignments', eventId];
  return useQuery(
    staffQueryId,
    (data) => getEventAssignments(data.pageParam ? { ...assignStaffVars, nextToken: data.pageParam } : assignStaffVars),
    {
      retry: false,
      // getNextPageParam: (lastPage) => lastPage?.nextToken,
      initialData: { items: initialData, nextToken: null },
    },
  );
};
