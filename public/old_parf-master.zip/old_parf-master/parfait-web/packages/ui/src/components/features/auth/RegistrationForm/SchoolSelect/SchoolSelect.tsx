import React, { useState, useEffect } from 'react';
import { Autocomplete } from '@mui/material';
import { useFormikContext } from 'formik';
import CircularProgress from '@mui/material/CircularProgress';
import { useDebounce } from 'react-use';
import { Field } from 'formik';
import { TextField as FormikTextField } from 'formik-mui';
import { API, graphqlOperation } from 'aws-amplify';
import { RegistrationFormValues } from '../types';
import { InstitutionInfo } from '../types';
import { getSearchInstitutions } from 'graphql/institutions';
import { getInstitutionWithEmailAddress } from 'graphql/users';
import { AutocompleteRenderInputParams } from '@mui/material/Autocomplete/Autocomplete';
import { emailRegExp } from 'config/regular-expressions';
import { AppType } from '../../../../../types/general';

type Props = {
  institutionInfo: InstitutionInfo | null;
  setInstitutionInfo: React.Dispatch<React.SetStateAction<InstitutionInfo | null>>;
  label?: string;
  zipCode?: string;
  appType: AppType;
};

type Institution = {
  id: string;
  name: string;
  reservedAccount: string;
};

type InstitutionSearchResponse = {
  data: {
    getSearchInstitutions: {
      items: Array<Institution>;
    };
  };
};

type GetInstitutionWithEmailAddress = {
  data: {
    getInstitutionWithEmailAddress: Institution;
  };
};

const SchoolSelect = (props: Props) => {
  const { institutionInfo, setInstitutionInfo, label = 'School', zipCode, appType } = props;

  const { values, setFieldValue } = useFormikContext<RegistrationFormValues>();
  const [loading, setLoading] = useState(false);
  const [institutions, setInstitutions] = useState<Array<Institution>>([]);
  const [search, setSearch] = useState('');

  const { email } = values;

  const isEmailValid = Boolean(String(email).toLowerCase().match(emailRegExp));

  useEffect(() => {
    if (institutionInfo) {
      setFieldValue('school', 'institutionInfo');
    } else {
      setFieldValue('school', '');
    }
  }, [institutionInfo]);

  /**
   * Fetch institutions options for search
   */
  useDebounce(
    async () => {
      if (search.length > 2 || (zipCode && zipCode.length === 5)) {
        try {
          setLoading(true);

          const resp = (await API.graphql(
            graphqlOperation(getSearchInstitutions, {
              filter: {
                institutionType: appType === 'highSchool' ? 'HIGH_SCHOOL' : 'COLLEGE',
                searchTerms: search.length > 2 ? search : '',
                postalCode: zipCode ? zipCode : '',
              },
              limit: '20',
            }),
          )) as InstitutionSearchResponse;

          setInstitutions(resp.data.getSearchInstitutions.items);
          setLoading(false);
        } catch (error) {
          setLoading(false);
        }
      } else {
        setInstitutions([]);
      }
    },
    200,
    [search, zipCode],
  );

  /**
   * Fetch institution by email
   */
  useDebounce(
    () => {
      const fetchInstitution = async () => {
        try {
          const resp = (await API.graphql(
            graphqlOperation(getInstitutionWithEmailAddress, { emailAddress: email }),
          )) as GetInstitutionWithEmailAddress;
          const institution = resp.data.getInstitutionWithEmailAddress;

          setInstitutionInfo({
            account: institution.reservedAccount,
            institutionName: institution.name,
            institutionId: institution.id,
          });
          setSearch(institution.name);
        } catch (error) {
          setInstitutionInfo(null);
          setSearch('');
        }
      };
      if (appType === 'university') {
        if (isEmailValid) {
          fetchInstitution();
        } else {
          setInstitutionInfo(null);
        }
      }
    },
    200,
    [email, isEmailValid, appType],
  );

  const renderInput = (params: AutocompleteRenderInputParams) => {
    return (
      <Field
        component={FormikTextField}
        {...params}
        label={label}
        name="school"
        InputProps={{
          ...params.InputProps,
          endAdornment: (
            <React.Fragment>
              {loading ? <CircularProgress color="inherit" size={20} /> : null}
              {params.InputProps.endAdornment}
            </React.Fragment>
          ),
        }}
      />
    );
  };

  const value = institutionInfo
    ? {
        id: institutionInfo.institutionId,
        name: institutionInfo.institutionName,
        reservedAccount: institutionInfo.account,
      }
    : null;

  return (
    <>
      <Autocomplete
        id="institution-select"
        autoHighlight
        loading={loading}
        filterOptions={(x) => x}
        options={institutions}
        onChange={(event: React.SyntheticEvent, value) => {
          if (value) {
            setInstitutionInfo({
              account: value.reservedAccount,
              institutionName: value.name,
              institutionId: value.id,
            });
          } else {
            setInstitutionInfo(null);
            setSearch('');
          }
        }}
        value={value}
        onInputChange={(event, value) => {
          if (event && event.type === 'change') {
            setSearch(value);
          }
        }}
        isOptionEqualToValue={(option, value) => option.name === value.name}
        getOptionLabel={(option) => option.name}
        renderInput={renderInput}
      />
    </>
  );
};

export default SchoolSelect;
