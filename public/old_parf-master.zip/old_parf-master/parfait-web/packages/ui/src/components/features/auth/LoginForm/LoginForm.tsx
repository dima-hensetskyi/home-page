import React, { useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { Link, LinearProgress, Alert, Stack, Typography } from '@mui/material';
import AuthHeader from '../AuthHeader';
import PasswordInput from '../PasswordInput';
import { Formik, Form, Field, FormikHelpers } from 'formik';
import { TextField as FormikTextField } from 'formik-mui';
import useAuthContext from '../../../containers/auth/useAuthContext';
import signInValidationSchema from './validationSchema';
import { Container, Error } from '../styledComponents';
import Button from '../Button';
import AccountField from './AccountField';

const LoginForm = () => {
  const [error, setError] = useState<string | null>(null);
  const { setIdentifiedAmplifyConfig, signIn, appType } = useAuthContext();

  const initialValues = {
    account: '',
    username: '',
    password: '',
  };

  const onSubmit = async (values: typeof initialValues, { setSubmitting }: FormikHelpers<typeof initialValues>) => {
    const { username, password, account } = values;
    setError(null);

    try {
      localStorage.clear();
      await setIdentifiedAmplifyConfig(account, username);
    } catch (error) {
      setError('Invalid account');
      setSubmitting(false);
      return;
    }

    try {
      await signIn(account, username, password);
    } catch (e) {
      setError('Username or password were incorrect.');
      setSubmitting(false);
      return;
    }
  };

  return (
    <Container>
      <AuthHeader
        title="Welcome back"
        description={
          appType === 'highSchool'
            ? 'Enter your high school account, username and password to sign in.'
            : 'Enter your school account, username, and password to sign in'
        }
      />
      <Formik validationSchema={signInValidationSchema} initialValues={initialValues} onSubmit={onSubmit}>
        {({ isSubmitting }) => (
          <Form>
            <Stack spacing={2}>
              <AccountField />
              <Field fullWidth component={FormikTextField} name="username" label="Username" type="text" />
              <PasswordInput fullWidth name="password" label="Password" />
            </Stack>
            <Typography
              variant="body2"
              color="#666"
              fontSize={12}
              sx={{
                marginLeft: '14px',
              }}
            >
              <Link component={RouterLink} to="/reset-password" underline="hover">
                Forgot password?
              </Link>
            </Typography>
            <Stack
              spacing={1}
              sx={{
                marginTop: '24px',
              }}
            >
              {error && (
                <Error>
                  {error === 'Username or password were incorrect.' ? (
                    <Alert severity="error">
                      We did not find an account that matches the information entered. Please try again or{' '}
                      <Link component={RouterLink} to="/sign-up" underline="hover">
                        Sign Up
                      </Link>{' '}
                      for a Parfait account
                    </Alert>
                  ) : (
                    <Alert severity="error">{error}</Alert>
                  )}
                </Error>
              )}
              <Stack sx={{ mt: '-4px' }}>
                <LinearProgress sx={{ visibility: isSubmitting ? 'visible' : 'hidden' }} />
                <Button type="submit">Sign in</Button>
              </Stack>
              <Typography variant="body2">
                Don’t have an account?{' '}
                <Link component={RouterLink} to="/sign-up" underline="hover">
                  Sign Up
                </Link>
              </Typography>
            </Stack>
          </Form>
        )}
      </Formik>
    </Container>
  );
};

export default LoginForm;
