import ImageEditorControl from './ImageEditorControl';

export default ImageEditorControl;
