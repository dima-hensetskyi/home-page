import React, { useState } from 'react';
import { Autocomplete, TextField } from '@mui/material';

type Props = {
  onChangeSearch: (search: string) => void;
};

const StudentsSearch = (props: Props) => {
  const { onChangeSearch } = props;

  const [search, setSearch] = useState('');

  return (
    <form
      action=""
      onSubmit={(event) => {
        event.preventDefault();
        onChangeSearch(search);
      }}
    >
      <Autocomplete
        size="small"
        sx={{
          width: 332,
          marginRight: 3,
        }}
        freeSolo
        inputValue={search}
        value={search}
        placeholder="Search"
        onInputChange={(evt: React.SyntheticEvent<Element, Event>, newInputValue: string) => {
          setSearch(newInputValue);
          if (!newInputValue) {
            setSearch('');
            onChangeSearch('');
          }
        }}
        options={[]}
        renderInput={(params) => {
          return <TextField sx={{ borderColor: 'green' }} {...params} label="Search" />;
        }}
      />
    </form>
  );
};

export default StudentsSearch;
