import React from 'react';
import { Stack, Typography, IconButton, Button } from '@mui/material';
import { Formik, Form, Field } from 'formik';
import { TextField as FormikTextField } from 'formik-mui';
import * as Yup from 'yup';
import LoadingButton from '@mui/lab/LoadingButton';
import { InstitutionTemporaryImage } from '../types';
import { InstitutionImage } from '../../../../../../../types/institutions';
import { BoxFrame, Header, Tips } from '../../../styled-components';
import { Row, CellImage, CellBody, CellControls, Img } from '../../../styled-components';
import AltTextTooltip from '../../AltTextTooltip';
import { isInstitutionImageType } from '../utils';

import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import FormatAlignLeftIcon from '@mui/icons-material/FormatAlignLeft';
import FormatAlignRightIcon from '@mui/icons-material/FormatAlignRight';
import Image from '../../Image';
import DeleteConfirm from './DeleteConfirm';
import LeaveFormConfirmation from '../../../../../../LeaveFormConfirmation';

const validationSchema = Yup.object().shape({
  message: Yup.string()
    .required('Field cannot be empty')
    .max(100, 'Field has a maximum limit of 100 characters.')
    .nullable(),
  imageAltText: Yup.string().max(100, 'Field has a maximum limit of 100 characters.').nullable(),
});

type Props = {
  image: InstitutionImage | InstitutionTemporaryImage;
  index: number;
  length: number;
  last: boolean;
  onSave: (image: InstitutionImage | InstitutionTemporaryImage) => void;
  onDelete: (image: InstitutionImage | InstitutionTemporaryImage) => Promise<void>;
  onMoveUp: (image: InstitutionImage) => void;
  onMoveDown: (image: InstitutionImage) => void;
};

const SecondaryImageForm = (props: Props) => {
  const { image, index, last, onSave, onDelete, length, onMoveUp, onMoveDown } = props;

  return (
    <BoxFrame>
      <Formik
        enableReinitialize
        initialValues={{
          alignment: image.alignment,
          message: image.message,
          imageAltText: image.imageAltText,
          order: image.order,
        }}
        onSubmit={async (values: any, { resetForm }) => {
          await onSave({ ...image, ...values });
          resetForm();
        }}
        validationSchema={validationSchema}
      >
        {({ setFieldValue, values, submitForm, isSubmitting }) => {
          return (
            <Form>
              <LeaveFormConfirmation />
              <Row>
                <CellImage>
                  <Typography
                    variant="subtitle1"
                    sx={{
                      mb: 1,
                    }}
                  >
                    Image {index + 2}
                  </Typography>
                  {isInstitutionImageType(image) ? (
                    <div>
                      <Image image={image.image} />
                    </div>
                  ) : (
                    <div>
                      <Img src={URL.createObjectURL(image.image)} alt="CellImage" />
                    </div>
                  )}
                </CellImage>
                <CellBody>
                  <Stack spacing={3}>
                    <Header>
                      <Typography
                        variant="subtitle2"
                        sx={{
                          mr: 2,
                        }}
                      >
                        Text Overlay
                      </Typography>
                      <IconButton
                        onClick={() => {
                          setFieldValue('alignment', 'LEFT');
                        }}
                      >
                        <FormatAlignLeftIcon
                          sx={{
                            color: values.alignment === 'LEFT' ? '#3788D8' : '#848484',
                          }}
                        />
                      </IconButton>
                      <IconButton
                        onClick={() => {
                          setFieldValue('alignment', 'RIGHT');
                        }}
                      >
                        <FormatAlignRightIcon
                          sx={{
                            color: values.alignment === 'RIGHT' ? '#3788D8' : '#848484',
                          }}
                        />
                      </IconButton>
                    </Header>
                    <Field
                      component={FormikTextField}
                      rows={2}
                      fullWidth
                      multiline
                      name="message"
                      label="Text Overlay"
                      placeholder="Add text to your image."
                    />
                    <div>
                      <AltTextTooltip />
                      <Field
                        component={FormikTextField}
                        rows={1}
                        fullWidth
                        multiline
                        name="imageAltText"
                        label="Alt text"
                        placeholder="Description of image. Ex: Students studying together with smiles on their faces."
                      />
                      <Tips>
                        <Typography
                          variant="subtitle2"
                          sx={{
                            color: '#666',
                            fontSize: '12px',
                          }}
                        >
                          100 characters limit
                        </Typography>
                      </Tips>
                    </div>
                  </Stack>
                </CellBody>
                <CellControls>
                  <Stack spacing={1}>
                    {isInstitutionImageType(image) ? (
                      <>
                        {index !== 0 && length > 1 ? (
                          <Button
                            variant="outlined"
                            size="small"
                            startIcon={<ArrowUpwardIcon />}
                            onClick={() => {
                              onMoveUp(image);
                            }}
                          >
                            Move Up
                          </Button>
                        ) : null}
                        {!last && length > 1 ? (
                          <Button
                            variant="outlined"
                            size="small"
                            startIcon={<ArrowDownwardIcon />}
                            onClick={() => {
                              onMoveDown(image);
                            }}
                          >
                            Move Down
                          </Button>
                        ) : null}
                      </>
                    ) : null}

                    <LoadingButton
                      variant="contained"
                      size="small"
                      endIcon={<ArrowForwardIcon />}
                      onClick={submitForm}
                      loading={isSubmitting}
                    >
                      Publish
                    </LoadingButton>
                    <DeleteConfirm onDelete={onDelete} image={image} />
                  </Stack>
                </CellControls>
              </Row>
            </Form>
          );
        }}
      </Formik>
    </BoxFrame>
  );
};

export default SecondaryImageForm;
