import React, { ChangeEvent, useState, useRef } from 'react';
import { Button, Modal, Typography, Stack, Box, IconButton } from '@mui/material';
import AvatarEditor from 'react-avatar-editor';
import CloseIcon from '@mui/icons-material/Close';
import CheckIcon from '@mui/icons-material/Check';
import styled from 'styled-components';
import { Container, ModalHeader, AvatarEditorWrapper, Label } from './styled-components';
import ImageEditorControl from './ImageEditorControl';
import {
  minScale,
  defaultScale,
  maxScale,
  scaleStep,
  minRotate,
  maxRotate,
  rotateStep,
  defaultRotate,
  quality,
  fillColor,
} from './ImageEditorControl/config';

type Props = {
  onAdd: (image: File) => void;
  children: React.ReactNode;
};

const OpenModal = styled.div`
  cursor: pointer;
`;

const AddImageModal = (props: Props) => {
  const { onAdd, children } = props;

  const [open, setOpen] = useState(false);

  const [scale, setScale] = useState<number>(defaultScale);
  const [rotate, setRotate] = useState<number>(defaultRotate);
  const [image, setImage] = useState<File | null>(null);

  const editorRef = useRef<AvatarEditor>(null);

  const onSubmit = (): void => {
    const editor = editorRef.current;

    if (!editor || !image) return;

    const canvas = editor.getImageScaledToCanvas();
    const context = canvas.getContext('2d');

    if (context) {
      context.globalCompositeOperation = 'destination-over';
      context.fillStyle = fillColor;
      context.fillRect(0, 0, canvas.width, canvas.height);
    }

    canvas.toBlob(
      async (blob) => {
        if (!blob) return;

        const newFile = new File([blob], image.name, { type: image.type });
        onAdd(newFile);
        setImage(null);
        setOpen(false);
      },
      image.type,
      quality,
    );
  };

  const handleNewImage = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.files?.[0]) {
      const file = event.target.files[0];
      setImage(file);
    }
  };

  const handleClose = () => {
    setOpen(false);
    setImage(null);
    setScale(defaultScale);
    setRotate(defaultRotate);
  };

  const showModal = () => {
    setOpen(true);
  };

  return (
    <>
      <OpenModal onClick={showModal}>{children}</OpenModal>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Container>
          <ModalHeader>
            <Typography variant="h6">Add university image</Typography>
            <IconButton onClick={handleClose}>
              <CloseIcon />
            </IconButton>
          </ModalHeader>
          <Box mb={2}>
            {image ? (
              <Stack spacing={2}>
                <AvatarEditorWrapper>
                  <AvatarEditor
                    image={image}
                    ref={editorRef}
                    width={300}
                    height={400}
                    border={30}
                    color={[0, 0, 0, 0.6]}
                    scale={scale / 10}
                    rotate={rotate}
                  />
                </AvatarEditorWrapper>
                <Stack spacing={1}>
                  <ImageEditorControl
                    min={minScale}
                    max={maxScale}
                    step={scaleStep}
                    onChange={setScale}
                    value={scale}
                    iconMinus={<>-</>}
                    iconPlus={<>+</>}
                  />
                  <ImageEditorControl
                    min={minRotate}
                    max={maxRotate}
                    step={rotateStep}
                    onChange={setRotate}
                    value={rotate}
                    iconMinus={<>↺</>}
                    iconPlus={<>↻</>}
                  />
                </Stack>
              </Stack>
            ) : (
              <Label>
                <Typography variant="body2" color="#1976d2">
                  Drag your file or click this area
                </Typography>
                <input type="file" accept="image/png,image/jpeg,image/jpg" onChange={handleNewImage} />
              </Label>
            )}
          </Box>
          <Stack direction="row" spacing={1}>
            <Button variant="contained" size="large" onClick={onSubmit} startIcon={<CheckIcon />}>
              Complete
            </Button>
            <Button variant="outlined" size="large" onClick={handleClose}>
              Cancel
            </Button>
          </Stack>
        </Container>
      </Modal>
    </>
  );
};

export default AddImageModal;
