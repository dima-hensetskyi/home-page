import FairScans from './FairScans';

export default FairScans;
