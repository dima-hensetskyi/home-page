import { Autocomplete, TextField } from '@mui/material';
import React, { useState } from 'react';
import { useDebounce } from 'react-use';

type PropsType = {
  onFetchAutoCompleteData: (searchTerms: string[]) => void;
  onEnterDown: (searchTerms: string[]) => void;
  onClearSearch: () => void;
  isAutoCompleteLoading: boolean;
  autoCompleteData: [] | string[];
};

export const SearchComponent: React.FC<PropsType> = ({
  onFetchAutoCompleteData,
  onClearSearch,
  onEnterDown,
  isAutoCompleteLoading,
  autoCompleteData,
}: PropsType) => {
  const [inputValue, setInputValue] = useState<Array<string>>([]);
  const currentInputValue = inputValue.join(' ');
  const isSearching = currentInputValue.length >= 3;

  const onInputChange = (evt: React.SyntheticEvent<Element, Event>, newInputValue: string) => {
    setInputValue(newInputValue.split(' '));
    if (!newInputValue) {
      onClearSearch();
    }
  };

  const setVariables = () => isSearching && onFetchAutoCompleteData(inputValue);

  useDebounce(setVariables, 900, [inputValue]);

  return (
    <Autocomplete
      onKeyDown={(evt) => {
        if (evt.key === 'Enter' && isSearching) {
          onEnterDown(inputValue);
        }
      }}
      loading={isAutoCompleteLoading}
      blurOnSelect={false}
      inputValue={currentInputValue}
      value={currentInputValue}
      freeSolo
      size="small"
      sx={{ width: '324px' }}
      // onChange={(evt, val) => val && setIsApply(true)}
      options={isSearching ? autoCompleteData : []}
      onInputChange={onInputChange}
      renderInput={(params) => <TextField sx={{ borderColor: 'green' }} {...params} label="Search" />}
    />
  );
};
