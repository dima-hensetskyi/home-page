import { Box, CircularProgress, Typography } from '@mui/material';
import { useInfiniteQuery, useQueryClient } from 'react-query';
import LoadingButton from '@mui/lab/LoadingButton';
import React from 'react';

import { FairsAttendingItemType } from '../types';
import { FairsFilterContainer } from '../FairsFilter';
import { FairsSearch } from '../FairsSearch';
import { getCorrectString, getCorrectDate } from '../../utils';
import { getFairsAttendingList } from '../api';
import { getFairsList } from '../utils';
import { Loader } from '../../../Loader';
import { TableComponent, TableTopControlPanel } from '../../../Table';
import { useFairsAttendingContext } from '../FairsAttendingContext';

type PropsType = {
  onActiveFairChange: (newVal: FairsAttendingItemType | null) => void;
};

export const FairsAttendingTable: React.FC<PropsType> = ({ onActiveFairChange }: PropsType) => {
  const { reqVars, setReqVars } = useFairsAttendingContext();
  const AlternativeOrder = reqVars?.sortDirection === 'ASC' ? 'DESC' : 'ASC';
  const queryIdWithAltSort = ['getFairsAttending', { ...reqVars, sortDirection: AlternativeOrder }];
  const queryClient = useQueryClient();

  const { data, isFetching, isLoading, hasNextPage, fetchNextPage } = useInfiniteQuery(
    ['getFairsAttending', reqVars],
    async (data) => getFairsAttendingList(data.pageParam ? { ...reqVars, nextToken: data.pageParam } : reqVars),
    {
      keepPreviousData: true,
      retry: false,
      getNextPageParam: (lastPage) => lastPage?.nextToken,
    },
  );

  const pages = data?.pages || [];
  const fairs = pages.map((page) => page?.items || []).flat(1);

  return (
    <>
      <TableTopControlPanel title="Fairs attending">
        <CircularProgress
          size={30}
          sx={{ visibility: isFetching && !isLoading && reqVars?.filter ? 'visible' : 'hidden' }}
        />
        <FairsFilterContainer />
        <FairsSearch />
      </TableTopControlPanel>
      {isLoading ? (
        <Loader />
      ) : (
        <>
          <TableComponent
            tableHeaders={{
              name: 'College Fair',
              status: 'Status',
              date: 'Date',
              locationName: 'Location',
              staffAssigned: 'Staff Assigned',
              expectedAttendees: 'Expected Attendees',
            }}
            tableDataItems={fairs ? getFairsList(fairs) : []}
            orderBy="date"
            sortOrder={reqVars?.sortDirection}
            onSortLabel={() => setReqVars({ ...reqVars, sortDirection: AlternativeOrder })}
            onMouseSortLabel={() => {
              if (!queryClient.getQueryData(queryIdWithAltSort)) {
                queryClient.prefetchInfiniteQuery(queryIdWithAltSort, () =>
                  getFairsAttendingList({ ...reqVars, sortDirection: AlternativeOrder }),
                );
              }
            }}
            // columnsWidth={{
            //   name: '32%',
            //   status: '12%',
            //   createdAt: '12%',
            //   locationName: '13%',
            //   staffAssigned: '21%',
            //   expectedAttendees: '10%',
            // }}
            tableCustomRenderers={{
              name: (fair) => (
                <Typography
                  sx={{ color: (theme) => theme.palette.primary.main, ':hover': { cursor: 'pointer' } }}
                  onClick={() => onActiveFairChange(fair)}
                  variant="body2"
                >
                  {fair?.name}
                </Typography>
              ),
              staffAssigned: (fair) => (
                <Typography
                  variant="body2"
                  sx={{ maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
                >
                  {fair.staffAssigned.map((user) => user.tenantUser.name).join(', ')}
                </Typography>
              ),
              status: (fair) => getCorrectString(fair.status),
              date: (fair) => getCorrectDate(fair?.date),
              locationName: (fair) =>
                `${fair?.fullDetail?.event?.address?.city || ''} ${
                  fair?.fullDetail?.event?.address?.stateProvince || ''
                }`,
            }}
          />
          <Box sx={{ display: 'flex', visibility: hasNextPage ? 'visible' : 'hidden', justifyContent: 'flex-end' }}>
            <LoadingButton
              loading={isFetching}
              sx={{
                fontSize: '15px',
                lineHeight: '26px',
                letterSpacing: '0.46px',
              }}
              variant="contained"
              onClick={() => fetchNextPage()}
            >
              SHOW MORE
            </LoadingButton>
          </Box>
        </>
      )}
    </>
  );
};
