import CustomScrollbar from './CustomScrollbar';

export default CustomScrollbar;
