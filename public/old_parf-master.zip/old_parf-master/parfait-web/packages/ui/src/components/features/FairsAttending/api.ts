import { API, graphqlOperation } from 'aws-amplify';
import { GraphQLResult } from '@aws-amplify/api';
import {
  createEventRegistrationAssignment,
  deleteEventRegistrationAssignment,
  getEventRegistrationAssignments,
  getEventRegistrationsByTenant,
} from 'graphql/events';
import {
  CreateEventAssignmentResponse,
  EventAssignmentInput,
  EventRegistrationAssignmentInput,
  EventRegistrationAssignmentResponse,
  EventRegistrationsByTenantInputType,
  GetEventRegistrationsByTenantResponseType,
} from '../../../types/events';

export const getFairsAttendingList = async (vars: EventRegistrationsByTenantInputType) => {
  const result = (await API.graphql(
    graphqlOperation(getEventRegistrationsByTenant, vars),
  )) as GraphQLResult<GetEventRegistrationsByTenantResponseType>;
  return result.data?.events;
};

export const getEventAssignments = async (vars: EventRegistrationAssignmentInput) => {
  const result = (await API.graphql(
    graphqlOperation(getEventRegistrationAssignments, vars),
  )) as GraphQLResult<EventRegistrationAssignmentResponse>;
  return result.data?.getEventRegistrationAssignments;
};

export const createEventAssignment = async (vars: EventAssignmentInput) => {
  const result = (await API.graphql(
    graphqlOperation(createEventRegistrationAssignment, vars),
  )) as GraphQLResult<CreateEventAssignmentResponse>;
  return result.data;
};

export const deleteEventAssignment = async (vars: EventAssignmentInput) => {
  const result = (await API.graphql(
    graphqlOperation(deleteEventRegistrationAssignment, vars),
  )) as GraphQLResult<boolean>;
  return result.data;
};
