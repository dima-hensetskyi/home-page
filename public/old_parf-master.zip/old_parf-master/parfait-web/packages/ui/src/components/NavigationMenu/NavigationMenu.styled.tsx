import { Link, NavLink } from 'react-router-dom';
import styled from 'styled-components';

import defStyles from 'config/styles';

const { darkGrey, primaryLight, darkGreyLight, tuna } = defStyles.customColors;

export const NavMenu = styled.nav`
  max-width: 60px;
  background-color: ${darkGrey};
  height: 100vh;
  box-sizing: border-box;
  padding: 20px 0px 33px 0px;
  position: relative;
  left: 0;
  color: #ffffff;
  text-align: center;

  @media (min-width: 1200px) {
    min-width: 260px;
    width: 100%;
    text-align: start;
  }
`;

export const NavMenuItem = styled(NavLink)`
  text-decoration: none;
  display: flex;
  position: relative;
  padding: 16px 20px;
  text-transform: uppercase;
  background: ${(props) => (props['aria-current'] ? primaryLight : darkGreyLight)};
  width: 100%;
  justify-content: center;

  &.${'active'} {
    background-color: ${primaryLight};
  }

  :hover {
    background-color: ${tuna};
  }

  @media (min-width: 1200px) {
    padding: 16px 33px;
    justify-content: flex-start;
  }
`;

export const Logo = styled.div`
  margin-bottom: 15px;
  display: flex;
  justify-content: center;
  svg {
    &.${'logo-icon'} {
      display: none;
    }
  }
  @media (min-width: 1200px) {
    padding: 0 33px;
    justify-content: flex-start;
    svg {
      width: 109px;
      &.${'short-logo-icon'} {
        display: none;
      }

      &.${'logo-icon'} {
        display: block;
      }
    }
  }
`;

export const HelpLink = styled(Link)`
  display: flex;
  align-items: center;
  margin: 0;
  text-decoration: none;
  position: absolute;
  bottom: 32px;
  text-align: center;
  flex-direction: row;
  width: 100%;
  justify-content: center;

  @media (min-width: 1200px) {
    margin: 0 30px;
    width: auto;
  }

  :hover {
    opacity: 0.8;
  }
`;
