export const sortData = ({
  tableData,
  orderBy,
  reverse,
}: {
  tableData: typeof tableDataItems;
  orderBy: string;
  reverse: boolean;
}) => {
  if (!orderBy) {
    return tableData;
  }

  const sortedData = tableData.sort((a: T, b: T) => {
    return a[orderBy as keyof T] > b[orderBy as keyof T] ? 1 : -1;
  });

  if (reverse) {
    sortedData.reverse();
  }

  return sortedData;
};
