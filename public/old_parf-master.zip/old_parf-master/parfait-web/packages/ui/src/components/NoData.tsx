import { Box, BoxProps, Typography } from '@mui/material';
import React from 'react';
import WarningIcon from '@mui/icons-material/Warning';

type PropsType = BoxProps & {
  title?: string;
};

export const NoData: React.FC<PropsType> = ({ title = 'No data found', ...props }: PropsType) => {
  return (
    <Box {...props} sx={{ ...props.sx, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <WarningIcon sx={{ color: (theme) => theme.palette.warning.main, mr: '17px' }} />{' '}
      <Typography variant="subtitle1">{title}</Typography>
    </Box>
  );
};
