import React from 'react';
import { Typography } from '@mui/material';
import ContactsList from './ContactsList';
import Chat from './Chat';
import ChatUserInfo from './ChatUserInfo';
import MessagesContainer from '../../../containers/messages/MessagesContainer';
import MessagesLoading from './MessagesLoading';
import MessagesEmpty from './MessagesEmpty';
import { Container, Row, ColChatList, ColChatMessages, ColChatUserInfo } from './styled-components';

const Messages = () => {
  return (
    <Container>
      <Typography variant="h4" color="#000" sx={{ mb: 2 }}>
        Messages
      </Typography>
      <MessagesContainer>
        {({ activeId, loaded, empty, messagesHeight, onMessagesStatusRead }) => {
          return loaded ? (
            <>
              {empty ? (
                <MessagesEmpty />
              ) : (
                <Row>
                  <ColChatList>
                    <ContactsList />
                  </ColChatList>
                  <ColChatMessages>
                    {activeId ? (
                      <Chat
                        onMessageRead={(id) => {
                          onMessagesStatusRead(id);
                        }}
                        chatId={activeId}
                        height={messagesHeight}
                      />
                    ) : (
                      <div>Please select contact</div>
                    )}
                  </ColChatMessages>
                  <ColChatUserInfo>
                    <ChatUserInfo />
                  </ColChatUserInfo>
                </Row>
              )}
            </>
          ) : (
            <MessagesLoading />
          );
        }}
      </MessagesContainer>
    </Container>
  );
};

export default Messages;
