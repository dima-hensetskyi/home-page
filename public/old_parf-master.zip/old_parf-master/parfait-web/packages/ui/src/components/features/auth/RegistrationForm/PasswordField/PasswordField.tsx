import React, { useState } from 'react';
import { useFormikContext, getIn } from 'formik';
import styled from 'styled-components';
import PasswordInput from '../../PasswordInput';

const List = styled.div`
  font-size: 12px;
  padding-left: 14px;
  margin: 3px 0 0 0 !important;
`;

const ListItem = styled.div`
  line-height: 1;
  margin-bottom: 12px;
`;
const successColor = '#66bb6a';
const errorColor = '#d3302f';

type Props = {
  label?: string;
};

const PasswordField = (props: Props) => {
  const [showRequirements, setShowRequirements] = useState(false);

  const { values, errors, touched, setTouched } = useFormikContext();

  const value: string = getIn(values, 'password');

  const isValidLength = (): boolean => {
    return value.length > 7;
  };
  const isContainNumber = (): boolean => {
    return value.match(/\d/) !== null;
  };
  const isContainUppercase = (): boolean => {
    return value.match(/[A-Z]/) !== null;
  };
  const isContainLowercase = (): boolean => {
    return value.match(/[a-z]/) !== null;
  };

  const requirementsIsMeet = isValidLength() && isContainNumber() && isContainUppercase() && isContainLowercase();

  return (
    <>
      <PasswordInput
        onFocus={() => {
          setShowRequirements(true);
        }}
        onBlur={() => {
          setShowRequirements(false);
          //setTouched('password');
          setTouched({ ...touched, password: true });
        }}
        fullWidth
        name="password"
        label="Password"
        {...props}
      />
      {showRequirements && !requirementsIsMeet && (
        <List>
          <ListItem
            style={{
              color: isValidLength() ? successColor : errorColor,
            }}
          >
            Minimum 8 characters.
          </ListItem>
          <ListItem
            style={{
              color: isContainNumber() ? successColor : errorColor,
            }}
          >
            Contains at least 1 number.
          </ListItem>
          <ListItem
            style={{
              color: isContainUppercase() ? successColor : errorColor,
            }}
          >
            Contains at least 1 uppercase letter.
          </ListItem>
          <ListItem
            style={{
              color: isContainLowercase() ? successColor : errorColor,
            }}
          >
            Contains at least 1 lowercase letter.
          </ListItem>
        </List>
      )}
    </>
  );
};

export default PasswordField;
