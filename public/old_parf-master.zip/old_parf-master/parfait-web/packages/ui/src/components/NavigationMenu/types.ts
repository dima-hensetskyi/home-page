export type NavLinkType = {
  title: string;
  to: string;
  role?: string;
};
