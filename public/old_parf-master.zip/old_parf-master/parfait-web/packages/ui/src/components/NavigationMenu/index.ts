import NavigationMenu from './NavigationMenu';

export default NavigationMenu;
