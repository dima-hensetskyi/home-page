import { Box, Button, Divider, FormControl, InputLabel, MenuItem, Select, TextField, Typography } from '@mui/material';
import { Form, Formik, Field } from 'formik';
import { TextField as FormikTextField } from 'formik-mui';
import InputMask from 'react-input-mask';
import React from 'react';

import { AvatarComponent } from '../../../Avatar';
import { getCorrectString } from '../utils';
import { RoleInformationButton } from './RoleInformationButton';
import { S3Object } from '../../../../types/general';
import { userSchema } from './validationSchema';

type TypeProps = {
  avatar?: S3Object;
  initialFormValues?: userFormVariablesType;
  onClose: () => void;
  onSubmit: (values: userFormVariablesType) => void;
  type: 'Update' | 'Create';
};

const userStatus = ['INACTIVE', 'ACTIVE'];
const userRoles = ['ADMIN', 'USER'];

const newUserInitialVariables = {
  givenName: '',
  familyName: '',
  username: '',
  email: '',
  phoneNumber: '',
  status: '',
  role: 'USER',
};

export type userFormVariablesType = typeof newUserInitialVariables;

export const UserForm: React.FC<TypeProps> = ({
  onClose,
  onSubmit,
  initialFormValues = newUserInitialVariables,
  type = 'Create',
  avatar,
}: TypeProps) => {
  const isUpdate = type === 'Update';
  return (
    <Formik
      validationSchema={userSchema}
      initialValues={initialFormValues}
      enableReinitialize
      onSubmit={(vals, { setSubmitting }) => {
        const isFormChanged = JSON.stringify(initialFormValues) !== JSON.stringify(vals);
        isFormChanged ? onSubmit(vals) : setSubmitting(false);
      }}
    >
      {({ values, handleBlur, handleChange }) => (
        <Box sx={{ display: 'flex', gap: '16px' }}>
          <AvatarComponent
            avatar={avatar}
            sx={{ width: '40px', height: '40px' }}
            name={
              values.givenName.length > 3 && values.familyName.length > 3
                ? `${values.givenName} ${values.familyName}`
                : undefined
            }
          ></AvatarComponent>
          <Form style={{ width: '100%' }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', flex: 1, with: '100%', gap: '16px' }}>
              <Field
                component={FormikTextField}
                fullWidth
                id="givenName"
                label="First Name"
                name="givenName"
                size="small"
                type="text"
              />
              <Field
                component={FormikTextField}
                fullWidth
                id="familyName"
                label="Last Name"
                name="familyName"
                size="small"
                type="text"
              />
              <Field
                component={FormikTextField}
                fullWidth
                id="email"
                label="Email"
                name="email"
                placeholder="email@school.edu/org/com"
                size="small"
                type="text"
              />
              <Field
                component={FormikTextField}
                fullWidth
                disabled={isUpdate}
                id="username"
                label="Username"
                name="username"
                size="small"
                type="text"
              />
              <InputMask
                alwaysShowMask={false}
                mask="(999) 999-9999"
                onBlur={handleBlur}
                onChange={handleChange}
                type="tel"
                value={values.phoneNumber}
              >
                {(inputProps: { value: string; onChange: () => void }) => (
                  <Field
                    {...inputProps}
                    component={FormikTextField}
                    fullWidth
                    id="phoneNumber"
                    label="Mobile number"
                    name="phoneNumber"
                    size="small"
                    type="text"
                  />
                )}
              </InputMask>
              <Divider sx={{ my: '8px' }} />
              {isUpdate &&
                (values.status === 'INVITED' ? (
                  <TextField
                    disabled
                    id="status"
                    name="status"
                    size="small"
                    label={'App Status'}
                    value={getCorrectString(values.status)}
                  />
                ) : (
                  <FormControl size="small" fullWidth>
                    <InputLabel>App Status</InputLabel>
                    <Select id="status" name="status" onChange={handleChange} value={values.status} label="App Status">
                      {userStatus.map((status) => (
                        <MenuItem key={status} value={status}>
                          {getCorrectString(status)}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                ))}
              <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: '5px', alignItems: 'center' }}>
                <FormControl size="small" fullWidth>
                  <InputLabel>Role</InputLabel>
                  <Select
                    color="primary"
                    id="role"
                    name="role"
                    onChange={handleChange}
                    value={values.role}
                    label="Role"
                  >
                    {userRoles.map((role) => (
                      <MenuItem key={role} value={role}>
                        {role === 'USER' ? 'Staff' : getCorrectString(role)}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                <RoleInformationButton />
              </Box>
              <Divider sx={{ my: '8px' }} />
              {isUpdate && (
                <>
                  <Typography variant="body2" sx={{ color: (theme) => theme.palette.primary.main, cursor: 'pointer' }}>
                    Reset user’s password
                  </Typography>
                  <Divider sx={{ my: '8px' }} />
                </>
              )}
              <Box sx={{ display: 'flex', gap: '8px' }}>
                <Button size="medium" variant="contained" type="submit">
                  {isUpdate ? 'Save Changes' : 'INVITE USER'}
                </Button>
                {isUpdate && (
                  <Button size="medium" variant="outlined" onClick={onClose}>
                    Cancel
                  </Button>
                )}
              </Box>
            </Box>
          </Form>
        </Box>
      )}
    </Formik>
  );
};
