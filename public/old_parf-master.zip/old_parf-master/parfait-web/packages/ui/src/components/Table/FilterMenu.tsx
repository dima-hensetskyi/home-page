import { IconButton, Menu, Tooltip } from '@mui/material';
import React, { useState } from 'react';

import { FilterIcon } from '../../icons';

type PropsType = {
  isMenuOpen: boolean;
  isApplyFilter?: boolean;
  setMenuOpen: React.Dispatch<React.SetStateAction<boolean>>;
  children?: React.ReactNode;
};

export const FilterMenu: React.FC<PropsType> = ({ children, setMenuOpen, isMenuOpen, isApplyFilter }: PropsType) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl && isMenuOpen);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setMenuOpen(true);
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <>
      <Tooltip title="Data filtering">
        <IconButton
          size="large"
          sx={{ marginRight: '15px', fill: `${open || isApplyFilter ? '#1976D2' : 'rgba(0, 0, 0, 0.54)'}` }}
          onClick={handleClick}
          aria-controls={open ? 'account-menu' : undefined}
          aria-haspopup="true"
          aria-expanded={open ? 'true' : undefined}
        >
          <FilterIcon style={{ width: '21px', height: '18px', fill: 'inherit' }} />
        </IconButton>
      </Tooltip>
      <Menu
        anchorEl={isMenuOpen ? anchorEl : null}
        id="account-menu"
        open={open}
        onClose={handleClose}
        // onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            minWidth: '268px',
            maxWidth: '268px',
            overflow: 'visible',
            boxShadow:
              '0px 5px 5px -3px rgba(0, 0, 0, 0.2), 0px 8px 10px 1px rgba(0, 0, 0, 0.14), 0px 3px 14px 2px rgba(0, 0, 0, 0.12)',
            borderRadius: '4px',
            padding: '24px',
          },
        }}
        transformOrigin={{ horizontal: 'left', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'left', vertical: 'bottom' }}
      >
        {children}
      </Menu>
    </>
  );
};
