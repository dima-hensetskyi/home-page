import AltTextTooltip from './AltTextTooltip';

export default AltTextTooltip;
