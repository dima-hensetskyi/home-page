import { InstitutionImage } from '../../../../../../types/institutions';
import { InstitutionTemporaryImage } from './types';

export const isInstitutionImageType = (
  image: InstitutionImage | InstitutionTemporaryImage,
): image is InstitutionImage => {
  return (image as InstitutionImage).institutionId !== undefined;
};
