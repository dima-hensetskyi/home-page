import { useInfiniteQuery } from 'react-query';
import React, { useState } from 'react';

import { EventRegistrationsByTenantInputType } from '../../../../types/events';
import { getFairsAttendingList } from '../api';
import { getSearchingFairsList } from '../utils';
import { SearchComponent } from '../../../Search';
import { useFairsAttendingContext } from '../FairsAttendingContext';

export const FairsSearch = () => {
  const { setReqVars, reqVars, onClearReqVars } = useFairsAttendingContext();
  const [searchVariables, setSearchVariables] = useState<EventRegistrationsByTenantInputType | undefined>(undefined);

  const { data, isFetching } = useInfiniteQuery(
    ['getFairsAttending', searchVariables],
    () => {
      if (searchVariables) {
        const vars = { ...searchVariables };
        delete vars.nextToken;
        return getFairsAttendingList(vars);
      }
    },
    {
      enabled: !!searchVariables,
      retry: false,
      keepPreviousData: true,
    },
  );

  const onFetchAutoCompleteData = (searchTerms: string[]) =>
    setSearchVariables({ ...reqVars, filter: { ...reqVars.filter, searchTerms } });

  const onSearch = (searchTerms: string[]) => {
    const vars = { ...reqVars };
    delete vars.nextToken;

    setReqVars({
      ...vars,
      filter: { ...vars.filter, searchTerms },
    });
  };

  const onClearSearch = () => {
    if (reqVars?.filter?.searchTerms) {
      onClearReqVars('search');
    }
  };

  const pages = data?.pages || [];
  const pageList = pages[pages.length - 1]?.items || [];

  return (
    <SearchComponent
      autoCompleteData={getSearchingFairsList(pageList || [])}
      onFetchAutoCompleteData={onFetchAutoCompleteData}
      isAutoCompleteLoading={isFetching}
      onEnterDown={onSearch}
      onClearSearch={onClearSearch}
    />
  );
};
