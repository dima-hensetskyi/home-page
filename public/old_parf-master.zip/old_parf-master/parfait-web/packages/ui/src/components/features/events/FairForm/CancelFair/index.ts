import CancelFair from './CancelFair';

export default CancelFair;
