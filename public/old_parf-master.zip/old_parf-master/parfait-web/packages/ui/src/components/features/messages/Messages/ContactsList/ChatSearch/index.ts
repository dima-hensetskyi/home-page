import ChatSearch from './ChatSearch';

export default ChatSearch;
