import { useMutation, useQueryClient } from 'react-query';
import { EventAssignmentInput, EventRegistrationAssignmentsType } from '../../../../types/events';
import { TenantUserResponseType } from '../../adminUserManagement/type';
import { createEventAssignment } from '../api';

export const useCreateAssignStaff = (eventId: string, tenantUsers: TenantUserResponseType[]) => {
  const queryClient = useQueryClient();
  const staffQueryId = ['GetEventAssignments', eventId];

  return useMutation(async (vars: EventAssignmentInput) => createEventAssignment(vars), {
    onMutate: async (vars: EventAssignmentInput) => {
      // await queryClient.cancelQueries(['getFairsAttending', context.reqVars]);
      await queryClient.cancelQueries(staffQueryId);
      const oldData = queryClient.getQueryData<{
        items: EventRegistrationAssignmentsType[];
        nextToken: string | null;
      }>(staffQueryId);
      const tenantUser = tenantUsers.find((user) => user.id === vars.input.tenantUserId);
      if (oldData && tenantUser) {
        const newItem = {
          eventRegistrationId: tenantUser?.id + eventId,
          tenantUserId: vars.input.tenantUserId,
          tenantUser,
          createdAt: Date.now(),
        };
        const staff = { ...oldData, items: [...oldData.items, newItem] };
        queryClient.setQueryData(staffQueryId, staff);
      }
      return { oldData };
    },
    onError: (_err, _variables, context) => {
      if (context?.oldData) {
        const oldData = context?.oldData;
        queryClient.setQueryData(staffQueryId, oldData);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries(staffQueryId);
    },
  });
};
