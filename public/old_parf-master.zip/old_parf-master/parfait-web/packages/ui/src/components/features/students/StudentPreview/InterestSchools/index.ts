import InterestSchools from './InterestSchools';

export default InterestSchools;
