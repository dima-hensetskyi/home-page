import React from 'react';
import dayjs from 'dayjs';
import styled from 'styled-components';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import { Typography } from '@mui/material';

dayjs.extend(customParseFormat);

type Props = {
  date: string;
};

const Wrapper = styled.div`
  display: flex;
  justify-content: center;
  margin-top: 16px;
`;

const MessagesDate = (props: Props) => {
  const { date } = props;

  const todayDate = dayjs().format('DD.MM.YYYY');
  const yesterdayDate = dayjs().subtract(1, 'days').format('DD.MM.YYYY');
  const resultDate = dayjs(date, 'DD.MM.YYYY').format('DD.MM.YYYY');

  let result: string;

  if (todayDate == resultDate) {
    result = 'Today';
  } else if (yesterdayDate == resultDate) {
    result = 'Yesterday';
  } else {
    result = dayjs(date, 'DD.MM.YYYY').format('MMMM DD, YYYY');
  }

  return (
    <Wrapper>
      <Typography variant="caption" align="center" color="#666">
        {result}
      </Typography>
    </Wrapper>
  );
};

export default MessagesDate;
