import { API, graphqlOperation } from 'aws-amplify';
import { GraphQLResult } from '@aws-amplify/api';

import { updateTenantUserPreferences } from 'graphql/tenants';
import { UpdateTenantUserPreferencesInput, UpdateTenantUserPreferencesInputResponseType } from '../../../types/tenant';

export const UpdateTenantUserPreference = async (vars: UpdateTenantUserPreferencesInput) => {
  const result = (await API.graphql(
    graphqlOperation(updateTenantUserPreferences, vars),
  )) as GraphQLResult<UpdateTenantUserPreferencesInputResponseType>;
  return result.data?.updateTenantUserPreferences;
};
