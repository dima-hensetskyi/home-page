import React from 'react';

type Props = {
  status: string;
};

const statuses: { [key: string]: string } = {
  PENDING: 'Pending',
  SHORT_LIST: 'Short list',
  FAVORITE: 'Favorite',
  BOOKMARK: 'Bookmark',
  DECLINED: 'Declined',
};

const SchoolsStatus = (props: Props) => {
  const { status } = props;

  return <span>{statuses[status]}</span>;
};

export default SchoolsStatus;
