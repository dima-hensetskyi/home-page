import StudentRequestPreview from './StudentPendingPreview';

export default StudentRequestPreview;
