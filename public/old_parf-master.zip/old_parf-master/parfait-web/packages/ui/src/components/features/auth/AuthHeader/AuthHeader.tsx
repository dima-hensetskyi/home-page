import React from 'react';
import { Typography, Stack } from '@mui/material';
import useAuthContext from '../../../containers/auth/useAuthContext';

type Props = {
  title: string;
  description: string;
};

const AuthHeader = (props: Props) => {
  const { title, description } = props;

  const { appType } = useAuthContext();

  return (
    <Stack
      spacing={0.5}
      sx={{
        marginBottom: '24px',
      }}
    >
      <Typography variant="overline">
        {appType === 'highSchool' ? 'High School Management' : 'College Management'}
      </Typography>
      <Typography variant="h4" color="#000">
        {title}
      </Typography>
      <Typography variant="body2" color="#666" fontSize={12}>
        {description}
      </Typography>
    </Stack>
  );
};

export default AuthHeader;
