import { Box, Button } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';

import React from 'react';

type PropsType = {
  onFetchPrev: () => void;
  onFetchNext: () => void;
  prev?: boolean;
  next?: boolean;
  isLoading?: boolean;
};

export const PaginationComponent: React.FC<PropsType> = ({
  onFetchPrev,
  onFetchNext,
  prev,
  next,
  isLoading = false,
}) => {
  if (!prev && !next) return null;
  return (
    <Box sx={{ display: 'flex', with: 100, justifyContent: 'flex-end', gap: '10px' }}>
      <LoadingButton loading={isLoading} disabled={!prev} onClick={() => prev && onFetchPrev()} variant="outlined">
        Previous
      </LoadingButton>
      <LoadingButton loading={isLoading} disabled={!next} onClick={() => next && onFetchNext()} variant="contained">
        Next
      </LoadingButton>
    </Box>
  );
};
