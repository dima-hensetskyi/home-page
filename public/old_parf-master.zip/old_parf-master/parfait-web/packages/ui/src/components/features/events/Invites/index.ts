import Invites from './Invites';

export default Invites;
