import EventRegistrationData from './EventRegistrationData';

export default EventRegistrationData;
