import { Typography } from '@mui/material';
import HelpIcon from '@mui/icons-material/Help';
import { Link, useLocation } from 'react-router-dom';
import React from 'react';

import { LogoIcon } from '../../icons';
import { LogoShort } from '../../icons';
import { NavIcon } from './NavIcon';
import { NavLinkType } from './types';
import { NavMenu, Logo, NavMenuItem, HelpLink } from './NavigationMenu.styled';
import useAuthContext from '../containers/auth/useAuthContext';
type PropsType = {
  menuLinks: Array<NavLinkType>;
};

const NavigationMenu: React.FC<PropsType> = ({ menuLinks }: PropsType) => {
  const { userRole } = useAuthContext();
  const location = useLocation();

  return (
    <div style={{ position: 'fixed' }}>
      <NavMenu>
        <Logo>
          <Link to="/">
            <LogoIcon className="logo-icon" />
            <LogoShort className="short-logo-icon" />
          </Link>
        </Logo>
        {menuLinks.map((link) => {
          if (link.role && link.role !== userRole) {
            return null;
          }

          const isActive = location.pathname.includes(link.to.split('/')[1]);

          return (
            <NavMenuItem className={`menu-nav-link ${isActive ? 'active' : ''}`} key={link.title} to={link.to}>
              <NavIcon iconName={link.title} />
              <Typography
                sx={{
                  fontWeight: 500,
                  fontSize: '15px',
                  lineHeight: '26px',
                  color: '#FFFFFF',
                  display: { xs: 'none', lg: 'block' },
                }}
              >
                {link.title}
              </Typography>
            </NavMenuItem>
          );
        })}
        <HelpLink to="/terms-and-conditions">
          <HelpIcon
            fontSize="small"
            sx={{ color: 'primary.light', width: '16px', height: '16px', marginRight: { xs: '0', lg: '8px' } }}
          />
          <Typography variant="body2" sx={{ color: 'primary.light', display: { xs: 'none', lg: 'block' } }}>
            Help & Getting started
          </Typography>
        </HelpLink>
      </NavMenu>
    </div>
  );
};

export default NavigationMenu;
