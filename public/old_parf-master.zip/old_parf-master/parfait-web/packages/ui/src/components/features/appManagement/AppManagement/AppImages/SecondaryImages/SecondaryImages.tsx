import React from 'react';
import { Button, Stack } from '@mui/material';
import styled from 'styled-components';
import config from 'config/aws-config';
import { v4 as uuidv4 } from 'uuid';
import { useQuery, useQueryClient } from 'react-query';
import { useSnackbar } from 'notistack';
import AddImageModal from '../AddImageModal';
import SecondaryImageForm from './SecondaryImageForm';
import {
  createInstitutionImage,
  deleteInstitutionImage,
  getInstitutionImages,
  updateInstitutionImage,
} from 'graphql/institutions';
import { API, graphqlOperation, Storage } from 'aws-amplify';
import useAuthContext from '../../../../../containers/auth/useAuthContext';
import {
  CreateInstitutionImageResponse,
  GetInstitutionImages,
  InstitutionImage,
  UpdateInstitutionImageResponse,
} from '../../../../../../types/institutions';
import { InstitutionTemporaryImage } from './types';
import { isInstitutionImageType } from './utils';
import SecondaryImagesLoading from './SecondaryImagesLoading';

const List = styled.div``;

type Images = Array<InstitutionImage | InstitutionTemporaryImage>;

export const updateInstitutionImagesOrder = /* GraphQL */ `
  mutation UpdateInstitutionImagesOrder($input: UpdateInstitutionImagesOrderInput!) {
    updateInstitutionImagesOrder(input: $input)
  }
`;

const SecondaryImages = () => {
  const { tenant, user } = useAuthContext()!;
  const queryClient = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();
  const { institutionId } = tenant!;

  const { data: images, status } = useQuery<Images>(
    ['getInstitutionImages', institutionId],
    async () => {
      const result = (await API.graphql(
        graphqlOperation(getInstitutionImages, { institutionId, limit: 25, nextToken: '' }),
      )) as GetInstitutionImages;

      return result.data.institutionImages.items;
    },
    {
      staleTime: Infinity,
      refetchOnWindowFocus: false,
    },
  );

  const savedImages = images
    ? (images.filter((image) => {
        return isInstitutionImageType(image);
      }) as Array<InstitutionImage>)
    : [];

  const onAdd = (image: File) => {
    queryClient.setQueryData<Images>(['getInstitutionImages', institutionId], (images) => {
      if (!images) return [];

      const newImage: InstitutionTemporaryImage = {
        id: Date.now(),
        image,
        alignment: 'LEFT',
        message: '',
        imageAltText: '',
        order: images.length + 1,
      };
      return [...images, newImage] as Images;
    });
  };

  const saveOrder = async (newOrderImages: Images) => {
    const savedImages = newOrderImages
      ? (newOrderImages.filter((image) => {
          return isInstitutionImageType(image);
        }) as Array<InstitutionImage>)
      : [];

    const imagesOrdered = savedImages.map((image) => {
      return {
        id: image.id,
        institutionId: image.institutionId,
        order: image.order,
      };
    });

    try {
      await API.graphql(
        graphqlOperation(updateInstitutionImagesOrder, {
          input: {
            items: imagesOrdered,
          },
        }),
      );
      enqueueSnackbar('Images order successfully updated!', {
        variant: 'success',
      });
    } catch {
      enqueueSnackbar('Images images order successfully updated!', {
        variant: 'error',
      });
    }
  };

  const onMoveUp = async (institutionImage: InstitutionImage) => {
    const { order } = institutionImage;

    queryClient.setQueryData<Images>(['getInstitutionImages', institutionId], () => {
      if (!images) return [];

      const newOrderImages = images.map((image) => {
        if (image.order === order - 1) {
          return {
            ...image,
            order: image.order + 1,
          };
        }

        if (image.order === order) {
          return {
            ...image,
            order: image.order - 1,
          };
        }

        return image;
      });

      saveOrder(newOrderImages);
      return newOrderImages;
    });
  };

  const onMoveDown = async (institutionImage: InstitutionImage) => {
    const { order } = institutionImage;

    queryClient.setQueryData<Images>(['getInstitutionImages', institutionId], () => {
      if (!images) return [];

      const newOrderImages = images.map((image) => {
        if (image.order === order + 1) {
          return {
            ...image,
            order: image.order - 1,
          };
        }

        if (image.order === order) {
          return {
            ...image,
            order: image.order + 1,
          };
        }

        return image;
      });

      saveOrder(newOrderImages);
      return newOrderImages;
    });
  };

  const onDelete = async (institutionImage: InstitutionImage | InstitutionTemporaryImage) => {
    if (isInstitutionImageType(institutionImage)) {
      await API.graphql(
        graphqlOperation(deleteInstitutionImage, {
          input: {
            id: institutionImage.id,
            institutionId,
          },
        }),
      );
      await Storage.remove(institutionImage.image.key);
    }

    queryClient.setQueryData<Images>(['getInstitutionImages', institutionId], () => {
      if (!images) return [];

      return images.filter((image) => {
        return image.id !== institutionImage.id;
      });
    });
  };

  const onSave = async (institutionImage: InstitutionImage | InstitutionTemporaryImage) => {
    if (!user) return;

    if (isInstitutionImageType(institutionImage)) {
      try {
        const result = (await API.graphql(
          graphqlOperation(updateInstitutionImage, {
            input: {
              id: institutionImage.id,
              institutionId,
              image: institutionImage.image,
              message: institutionImage.message,
              alignment: institutionImage.alignment,
              imageAltText: institutionImage.imageAltText,
              order: institutionImage.order,
              published: true,
            },
          }),
        )) as UpdateInstitutionImageResponse;

        const updatedImage = result.data.updateInstitutionImage;

        queryClient.setQueryData<Images>(['getInstitutionImages', institutionId], () => {
          if (!images) return [];

          return images.map((image) => {
            if (image.id === updatedImage.id) {
              return updatedImage;
            }

            return image;
          });
        });

        enqueueSnackbar('Changes successfully published!', {
          variant: 'success',
        });
      } catch {
        enqueueSnackbar('Unexpected error while saving changes!', {
          variant: 'error',
        });
      }
    } else {
      const file = institutionImage.image;
      const key = `tenants/${user.pool.storage.identityPoolId!}/${uuidv4()}-${file.name}`;

      const imageUploadResult = await Storage.put(key, file, {
        contentType: file.type,
        level: 'public',
      });

      const s3object = {
        bucket: config.s3.BUCKET,
        region: config.s3.REGION,
        key: imageUploadResult.key,
        accessLevel: 'PUBLIC',
      };

      try {
        const result = (await API.graphql(
          graphqlOperation(createInstitutionImage, {
            input: {
              institutionId,
              image: s3object,
              message: institutionImage.message,
              alignment: institutionImage.alignment,
              imageAltText: institutionImage.imageAltText,
              order: institutionImage.order,
            },
          }),
        )) as CreateInstitutionImageResponse;

        queryClient.setQueryData<Images>(['getInstitutionImages', institutionId], () => {
          if (!images) return [];

          return images.map((image) => {
            if (image.id === institutionImage.id) {
              return result.data.createInstitutionImageResult;
            }

            return image;
          });
        });

        enqueueSnackbar('Changes successfully published!', {
          variant: 'success',
        });
      } catch {
        enqueueSnackbar('Unexpected error while saving changes!', {
          variant: 'error',
        });
      }
    }
  };

  if (status === 'loading' || !images) {
    return (
      <>
        <SecondaryImagesLoading />
      </>
    );
  }

  return (
    <Stack spacing={3}>
      <List>
        {images
          .sort((a, b) => {
            return a.order - b.order;
          })
          .map((image, index) => {
            return (
              <SecondaryImageForm
                onSave={onSave}
                onDelete={onDelete}
                onMoveUp={onMoveUp}
                onMoveDown={onMoveDown}
                image={image}
                key={index}
                index={index}
                last={savedImages.length - 1 === index}
                length={images.length}
              />
            );
          })}
      </List>
      {images.length < 25 && (
        <AddImageModal onAdd={onAdd}>
          <Button size="large" variant="contained">
            Add image
          </Button>
        </AddImageModal>
      )}
    </Stack>
  );
};

export default SecondaryImages;
