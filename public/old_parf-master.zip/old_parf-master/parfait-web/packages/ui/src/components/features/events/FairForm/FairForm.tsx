import React from 'react';
import { Formik, Form, Field } from 'formik';
import { Grid, Stack } from '@mui/material';
import { TextField as FormikTextField } from 'formik-mui';
import dayjs from 'dayjs';
import DatePicker from './DatePicker';
import Organizer from './Organizer';
import InviteType from './InviteType';
import { FormValues } from './types';
import { validationSchema } from './validationSchema';
import TimePicker from './TimePicker';
import EventStatus from './EventStatus';
import CancelFair from './CancelFair';

type Props =
  | {
      initialValues: FormValues;
      onSubmit: (values: FormValues, dateFrom: string, dateTo: string) => Promise<void>;
      type: 'create';
    }
  | {
      initialValues: FormValues;
      onSubmit: (values: FormValues, dateFrom: string, dateTo: string) => Promise<void>;
      type: 'edit';
      onClose: () => void;
      id: string;
    };

const FairForm = (props: Props) => {
  const { initialValues, onSubmit, type } = props;

  return (
    <div>
      <Formik
        validationSchema={validationSchema}
        initialValues={initialValues}
        onSubmit={async (values: FormValues) => {
          const dateFrom = dayjs(`${values.date} ${values.startTime}`).format();
          const dateTo = dayjs(`${values.date} ${values.endTime}`).format();

          onSubmit(values, dateFrom, dateTo);
        }}
      >
        {() => {
          return (
            <Form id="fair-form">
              <Grid container spacing={4}>
                <Grid item xs={6}>
                  <Stack spacing={2}>
                    <Field
                      fullWidth
                      component={FormikTextField}
                      name="name"
                      label="Fair name"
                      type="text"
                      size="small"
                    />
                    <DatePicker />
                    <Stack direction="row" spacing={1}>
                      <TimePicker name="startTime" label="Start time" />
                      <TimePicker name="endTime" label="End" />
                    </Stack>
                    <Organizer />
                    <Field
                      fullWidth
                      component={FormikTextField}
                      name="fee"
                      label="Fee"
                      type="number"
                      size="small"
                      placeholder="Optional fee"
                    />
                    <Stack spacing={2}>
                      <Field
                        fullWidth
                        component={FormikTextField}
                        name="address1"
                        label="Address 1"
                        type="text"
                        size="small"
                      />
                      <Field
                        fullWidth
                        component={FormikTextField}
                        name="address2"
                        label="Address 2"
                        type="text"
                        size="small"
                      />
                      <Field fullWidth component={FormikTextField} name="city" label="City" type="text" size="small" />
                      <Stack direction="row" spacing={1}>
                        <Field
                          fullWidth
                          component={FormikTextField}
                          name="stateProvince"
                          label="State"
                          type="text"
                          size="small"
                        />
                        <Field
                          fullWidth
                          component={FormikTextField}
                          name="postalCode"
                          label="Zip code"
                          type="text"
                          size="small"
                        />
                      </Stack>
                    </Stack>
                    <Field
                      fullWidth
                      component={FormikTextField}
                      name="locationName"
                      label="Location"
                      type="text"
                      size="small"
                      placeholder="Ex: High School Gymnasium"
                    />
                    <Field
                      fullWidth
                      component={FormikTextField}
                      name="expectedAttendees"
                      label="Expected Attendees"
                      type="number"
                      size="small"
                    />
                  </Stack>
                </Grid>
                <Grid item xs={6}>
                  <Stack spacing={2}>
                    {type === 'create' && <InviteType />}
                    <Field
                      component={FormikTextField}
                      rows={4}
                      fullWidth
                      multiline
                      name="description"
                      label="Description"
                    />
                    <Field
                      component={FormikTextField}
                      rows={2}
                      fullWidth
                      multiline
                      name="note"
                      label="Note"
                      placeholder="Special Instructions, ect."
                    />
                    <EventStatus />
                    {type === 'edit' && (
                      <>
                        <CancelFair eventId={props.id} onClose={props.onClose} />
                      </>
                    )}
                  </Stack>
                </Grid>
              </Grid>
            </Form>
          );
        }}
      </Formik>
    </div>
  );
};

export default FairForm;
