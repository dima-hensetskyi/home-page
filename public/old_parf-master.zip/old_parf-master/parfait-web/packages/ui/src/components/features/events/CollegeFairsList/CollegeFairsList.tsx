import { API } from 'aws-amplify';
import { Typography, Link, Stack, Box } from '@mui/material';
import { useInfiniteQuery } from 'react-query';
import dayjs from 'dayjs';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useState } from 'react';

import { FairResponse } from '../types';
import { getEvents } from 'graphql/events';
import { Loader } from '../../../Loader';
import { TableComponent } from '../../../Table';
import ClipboardCopy from '../../../ClipboardCopy';
import EditFair from '../EditFair';
import Invites from '../Invites';
import RegistrationsView from '../RegistrationsView';
import { Fair } from '../../../../types/events';

const CollegeFairsList = () => {
  const [editEntity, setEditEntity] = useState<Fair | null>(null);

  const { data, isFetching, isLoading, hasNextPage, fetchNextPage } = useInfiniteQuery(
    'getEvents',
    async (data) => {
      const result = (await API.graphql({
        query: getEvents,
        variables: {
          nextToken: data.pageParam,
          limit: 10,
        },
      })) as FairResponse;

      return result.data.events;
    },
    {
      keepPreviousData: true,
      retry: false,
      getNextPageParam: (lastPage) => lastPage?.nextToken,
    },
  );

  const pages = data?.pages || [];
  const fairs = pages.map((page) => page?.items || []).flat(1);

  return isLoading ? (
    <Loader />
  ) : (
    <>
      <TableComponent
        tableHeaders={{
          name: 'College Fair',
          inviteType: 'Type',
          link: 'Link (Open Fairs)',
          date: 'Date',
          invites: 'Invites',
          registered: 'Registered',
        }}
        tableDataItems={
          fairs
            ? fairs.map((item) => {
                return {
                  name: {
                    name: item.name,
                    id: item.id,
                  },
                  inviteType: item.inviteType,
                  link: item.id,
                  date: dayjs(item.startDateAndTime).format('MM/DD/YYYY'),
                  invites: 'Invites',
                  registered: 'Registered',
                };
              })
            : []
        }
        columnsWidth={{
          name: '20%',
          inviteType: '20%',
          link: '20%',
          date: '20%',
          invites: '10%',
          registered: '10%',
        }}
        tableCustomRenderers={{
          name: (fair) => {
            return (
              <>
                <Typography
                  sx={{ color: (theme) => theme.palette.primary.main, ':hover': { cursor: 'pointer' } }}
                  onClick={() => {
                    if (!data) return;

                    const entity = fairs.find((item) => {
                      return item.id === fair.name.id;
                    })!;
                    setEditEntity(entity);
                  }}
                  variant="body2"
                >
                  {fair.name.name}
                </Typography>
              </>
            );
          },
          inviteType: (fair) => {
            return <>{fair.inviteType === 'INVITE_ONLY' ? 'Invite only' : 'Open'}</>;
          },
          link: (fair) => {
            const link = `${location.origin}/event-registration/${fair.link}`;
            return (
              <>
                {fair.inviteType === 'OPEN' && (
                  <Stack spacing={1} direction="row" alignItems="flex-start">
                    <Link href={link} target="_blank">
                      {link}
                    </Link>
                    <ClipboardCopy text={link} />
                  </Stack>
                )}
              </>
            );
          },
          date: (fair) => {
            return fair.date;
          },
          invites: (fair) => {
            return (
              <>
                {fair.inviteType === 'INVITE_ONLY' && <Invites inviteId={fair.name.id} inviteName={fair.name.name} />}
              </>
            );
          },
          registered: (fair) => {
            return fair.inviteType === 'OPEN' ? <RegistrationsView inviteId={fair.name.id} /> : null;
          },
        }}
      />
      <Box sx={{ display: 'flex', visibility: hasNextPage ? 'visible' : 'hidden', justifyContent: 'flex-end' }}>
        <LoadingButton
          loading={isFetching}
          sx={{
            fontSize: '15px',
            lineHeight: '26px',
            letterSpacing: '0.46px',
          }}
          variant="contained"
          onClick={() => fetchNextPage()}
        >
          SHOW MORE
        </LoadingButton>
      </Box>
      {editEntity && (
        <EditFair
          entity={editEntity}
          onClose={() => {
            setEditEntity(null);
          }}
        />
      )}
    </>
  );
};

export default CollegeFairsList;
