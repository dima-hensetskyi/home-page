import React, { useState } from 'react';
import { LinearProgress, Alert, Stack } from '@mui/material';
import AuthHeader from '../AuthHeader';
import { Formik, Form, Field, FormikHelpers } from 'formik';
import { TextField as FormikTextField } from 'formik-mui';
import useAuthContext from '../../../containers/auth/useAuthContext';

import passwordResetSchema from './validationSchema';
import { Container, Error } from '../styledComponents';
import Button from '../Button';

const PasswordResetForm = () => {
  const [error, setError] = useState<string | null>(null);
  const { setIdentifiedAmplifyConfig, forgotPassword } = useAuthContext();

  const initialValues = {
    account: '',
    username: '',
  };

  const { appType } = useAuthContext();

  const onSubmit = async (values: typeof initialValues, { setSubmitting }: FormikHelpers<typeof initialValues>) => {
    const { username, account } = values;
    setError(null);

    try {
      await setIdentifiedAmplifyConfig(account, username);
    } catch (error) {
      setError('Invalid account');
      setSubmitting(false);
      return;
    }

    try {
      await forgotPassword(account, username);
    } catch (e) {
      setError('Invalid account');
      setSubmitting(false);
      return;
    }
  };

  return (
    <Container>
      <AuthHeader
        title="Forgot Password?"
        description={
          appType === 'highSchool'
            ? 'Please enter your high school account and username'
            : 'Please enter your school account and username.'
        }
      />
      <Formik validationSchema={passwordResetSchema} initialValues={initialValues} onSubmit={onSubmit}>
        {({ isSubmitting }) => (
          <Form>
            <Stack spacing={2}>
              <Field fullWidth component={FormikTextField} name="account" label="Account" type="text" />
              <Field fullWidth component={FormikTextField} name="username" label="Username" type="text" />
            </Stack>
            <Stack
              spacing={1}
              sx={{
                marginTop: '24px',
              }}
            >
              {error && (
                <Error>
                  <Alert severity="error">{error}</Alert>
                </Error>
              )}
              <div>
                {isSubmitting && <LinearProgress />}
                <Button type="submit">SUBMIT</Button>
              </div>
            </Stack>
          </Form>
        )}
      </Formik>
    </Container>
  );
};

export default PasswordResetForm;
