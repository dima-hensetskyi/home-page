import React, { ChangeEvent, useState } from 'react';
import { Button, Modal, Typography, Stack, Box, IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import CheckIcon from '@mui/icons-material/Check';
import styled from 'styled-components';
import { Container, ModalHeader, PrimaryIcon, Label } from './styled-components';

type Props = {
  onAdd: (image: File) => void;
  children: React.ReactNode;
};

const OpenModal = styled.div`
  cursor: pointer;
`;

const AddIconModal = (props: Props) => {
  const { onAdd, children } = props;

  const [open, setOpen] = useState(false);

  const [image, setImage] = useState<File | null>(null);

  const onSubmit = (): void => {
    if (!image) return;

    onAdd(image);
    setOpen(false);
  };

  const handleNewImage = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.files?.[0]) {
      const file = event.target.files[0];
      setImage(file);
    }
  };

  const handleClose = () => {
    setOpen(false);
    setImage(null);
  };

  const showModal = () => {
    setOpen(true);
  };

  return (
    <>
      <OpenModal onClick={showModal}>{children}</OpenModal>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Container>
          <ModalHeader>
            <Typography variant="h6">Edit primary icon</Typography>
            <IconButton onClick={handleClose}>
              <CloseIcon />
            </IconButton>
          </ModalHeader>
          <Box mb={3}>
            {image ? (
              <PrimaryIcon>
                <img src={URL.createObjectURL(image)} alt="CellImage" />
              </PrimaryIcon>
            ) : (
              <Label>
                <Typography variant="body2" color="#1976d2">
                  Drag your file or click this area
                </Typography>
                <input type="file" accept="image/png,image/jpeg,image/jpg" onChange={handleNewImage} />
              </Label>
            )}
          </Box>
          <Stack direction="row" spacing={1}>
            <Button variant="contained" size="large" onClick={onSubmit} startIcon={<CheckIcon />}>
              Complete
            </Button>
            <Button variant="outlined" size="large" onClick={handleClose}>
              Cancel
            </Button>
          </Stack>
        </Container>
      </Modal>
    </>
  );
};

export default AddIconModal;
