import StudentsList from './StudentsList';

export default StudentsList;
