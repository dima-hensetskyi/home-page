import React from 'react';
import { useQueryClient } from 'react-query';
import { AvatarComponent } from '../../../../../../Avatar';
import { AuthenticatedTenantUserResponse } from '../../../../../../../types/tenant';

const TenantAvatar = () => {
  const queryClient = useQueryClient();
  const authenticatedUser = queryClient.getQueryData('AuthenticatedTenantUser') as AuthenticatedTenantUserResponse;
  const {
    getAuthenticatedTenantUser: { avatar },
  } = authenticatedUser;

  return <AvatarComponent sx={{ width: '32px', height: '32px' }} avatar={avatar} />;
};

export default TenantAvatar;
