import React from 'react';
import { API, graphqlOperation } from 'aws-amplify';
import { useQuery } from 'react-query';
import { Typography, Link, CircularProgress, Box } from '@mui/material';
import styled from 'styled-components';
import { fetchCollegeInfo } from 'graphql/institutions';
import useAuthContext from '../../../../../containers/auth/useAuthContext';
import { CollegeInfoResponse, CollegeInfo } from '../../../../../../types/institutions';

const InfoField = styled.div`
  background: #f5f5f5;
  border: 1px solid #d8d8d8;
  border-radius: 4px;
  padding-bottom: 24px;
`;

const Pre = styled.pre`
  margin-bottom: 0;
  margin-top: 0;
`;

const CollegeInfo = () => {
  const { tenant } = useAuthContext();

  const { institutionId } = tenant!;

  const { data: collegeInfo } = useQuery<CollegeInfo>(['fetchCollegeInfo', institutionId], async () => {
    const result = (await API.graphql(
      graphqlOperation(fetchCollegeInfo, {
        id: institutionId,
      }),
    )) as CollegeInfoResponse;

    return result.data.collegeInfo.info;
  });

  return (
    <div>
      <Typography
        variant="body2"
        sx={{
          mb: 1.5,
        }}
      >
        College information has been gathered from the U.S. Department of Education. If the following information is
        incorrect, please email <Link href="mailto:support@joinparfait.com">support@joinparfait.com</Link> to open a
        support ticket.
      </Typography>
      {collegeInfo ? (
        <InfoField>
          <div>
            {collegeInfo.map((info, index) => {
              return (
                <Pre key={index}>
                  <Typography variant="body2">{JSON.stringify(info, null, 2).replace(/[{}]/g, '')}</Typography>
                </Pre>
              );
            })}
          </div>
        </InfoField>
      ) : (
        <Box sx={{ display: 'flex', justifyContent: 'center' }}>
          <CircularProgress />
        </Box>
      )}
    </div>
  );
};

export default CollegeInfo;
