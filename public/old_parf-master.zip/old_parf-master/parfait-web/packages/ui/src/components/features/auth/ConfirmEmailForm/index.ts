import ConfirmEmailForm from './ConfirmEmailForm';

export default ConfirmEmailForm;
