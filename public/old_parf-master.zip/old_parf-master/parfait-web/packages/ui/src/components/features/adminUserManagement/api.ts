import {
  CreateTenantUser,
  GetTenantUserAvailable,
  GetTenantUsers,
  reinviteTenantUser,
  updateTenantUser,
} from 'graphql/tenants';
import { API, graphqlOperation } from 'aws-amplify';
import { GraphQLResult } from '@aws-amplify/api';
import { validateAWSPhone } from 'graphql/general';

import {
  CreateTenantUserResponseType,
  CreateUserInputType,
  GetTenantUserAvailableInput,
  GetTenantUserAvailableResponse,
  TenantUsersRequestVariablesType,
  TenantUsersResponseType,
  UpdateTenantUserResponseType,
  UpdateUserInputType,
} from './type';
import { ReinviteTenantUserInputType } from '../../../types/tenant';

export const fetchTenantsUsers = async (variables: TenantUsersRequestVariablesType) => {
  const result = (await API.graphql(
    graphqlOperation(GetTenantUsers, variables),
  )) as GraphQLResult<TenantUsersResponseType>;
  const data = result.data?.getTenantUsers;
  return data;
};

export const checkTenantUser = async (variables: GetTenantUserAvailableInput) => {
  const result = (await API.graphql(
    graphqlOperation(GetTenantUserAvailable, variables),
  )) as GraphQLResult<GetTenantUserAvailableResponse>;
  const data = result.data?.getTenantUserAvailable;
  return data;
};

export const createNewTenantUser = async (vars: CreateUserInputType) => {
  const result = (await API.graphql(
    graphqlOperation(CreateTenantUser, vars),
  )) as GraphQLResult<CreateTenantUserResponseType>;
  return result.data;
};

export const UpdateTenantUser = async (vars: UpdateUserInputType) => {
  const result = (await API.graphql(
    graphqlOperation(updateTenantUser, vars),
  )) as GraphQLResult<UpdateTenantUserResponseType>;
  return result.data;
};

export const reinviteUser = async (vars: ReinviteTenantUserInputType) => {
  const result = (await API.graphql(
    graphqlOperation(reinviteTenantUser, vars),
  )) as GraphQLResult<UpdateTenantUserResponseType>;
  return result.data;
};

type EmptyObject = {
  [K in any]: boolean;
};

const validatedNums: EmptyObject = {};

export const checkPhoneNumber = async (val: string, resolve: (value: boolean) => void) => {
  const num = val && `+1${val.replace(/[^\d]/g, '')}`;
  const key = num as keyof typeof validatedNums;
  validatedNums[key] && resolve(true);

  if (num.length >= 12 && validatedNums[key] === undefined) {
    try {
      const isNumberValid = await API.graphql(graphqlOperation(validateAWSPhone, { phone: num }));
      validatedNums[key] = true;
      resolve(!!isNumberValid);
    } catch {
      validatedNums[key] = false;
      resolve(false);
    }
  }
  resolve(false);
};
