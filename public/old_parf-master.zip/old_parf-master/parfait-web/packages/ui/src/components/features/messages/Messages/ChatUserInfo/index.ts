import ChatUserInfo from './ChatUserInfo';

export default ChatUserInfo;
