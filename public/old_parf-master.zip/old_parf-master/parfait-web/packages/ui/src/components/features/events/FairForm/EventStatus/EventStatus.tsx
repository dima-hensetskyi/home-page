import React from 'react';
import { FormControl, InputLabel, MenuItem, Select } from '@mui/material';
import { useFormikContext } from 'formik';

import { FormValues } from '../types';

const statuses = [
  {
    key: 'REGISTRATION_ACTIVE',
    label: 'Open',
  },
  {
    key: 'REGISTRATION_CLOSED',
    label: 'Closed',
  },
];

const canceledStatuses = [
  {
    key: 'CANCELLED',
    label: 'Canceled',
  },
];

const EventStatus = () => {
  const { values, setFieldValue } = useFormikContext<FormValues>();

  return (
    <FormControl size="small">
      <InputLabel id="event-status">Registration Status</InputLabel>
      <Select
        disabled={values.status === 'CANCELLED'}
        size="small"
        labelId="event-status"
        label="Registration Status"
        value={values.status}
        onChange={(evt) => {
          setFieldValue('status', evt.target.value);
        }}
      >
        {(values.status !== 'CANCELLED' ? statuses : canceledStatuses).map(({ key, label }) => (
          <MenuItem key={key} value={key}>
            {label}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default EventStatus;
