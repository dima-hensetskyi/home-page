import React, { useState } from 'react';
import {
  BoxFrame,
  Row,
  CellImage,
  CellBody,
  CellControls,
  Header,
  Tips,
  Img,
  PrimaryImageWrapper,
  ImgPicker,
} from '../../styled-components';
import { Typography, Stack } from '@mui/material';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { Field, Form, Formik, FormikHelpers } from 'formik';
import { TextField as FormikTextField } from 'formik-mui';
import LoadingButton from '@mui/lab/LoadingButton';
import * as Yup from 'yup';
import config from 'config/aws-config';
import { v4 as uuidv4 } from 'uuid';
import { API, Auth, graphqlOperation, Storage } from 'aws-amplify';
import { useQuery, useQueryClient } from 'react-query';
import AltTextTooltip from '../AltTextTooltip';
import AddImageModal from '../AddImageModal';
import { getCollege, updateCollege } from 'graphql/institutions';
import {
  CollegePrimaryImage,
  GetInstitutionPrimaryImage,
  UpdateCollegeResponse,
} from '../../../../../../types/institutions';
import useAuthContext from '../../../../../containers/auth/useAuthContext';
import Image from '../Image';
import ImagePlaceholder from './ImagePlaceholder';
import EditIcon from '../EditIcon';
import { useSnackbar } from 'notistack';
import LeaveFormConfirmation from '../../../../../LeaveFormConfirmation';

const validationSchema = Yup.object().shape({
  imageAltText: Yup.string().max(100, 'Field has a maximum limit of 100 characters.').nullable(),
});

type FormikValues = {
  imageAltText: string;
};

const PrimaryImage = () => {
  const [image, setImage] = useState<File | null>(null);
  const { user, tenant } = useAuthContext()!;
  const queryClient = useQueryClient();
  const { enqueueSnackbar } = useSnackbar();

  const { institutionId } = tenant!;

  const { data: primaryImage } = useQuery<CollegePrimaryImage>(['CollegePrimaryImage', institutionId], async () => {
    const result = (await API.graphql(
      graphqlOperation(getCollege, {
        id: institutionId,
      }),
    )) as GetInstitutionPrimaryImage;

    return result.data.institutionPrimaryImage;
  });

  const initialValues = primaryImage
    ? {
        imageAltText: primaryImage.primaryImageAltText,
      }
    : {
        imageAltText: 'Description of image. Ex: Students studying together with smiles on their faces.',
      };

  const onSubmit = async (values: FormikValues, { resetForm }: FormikHelpers<FormikValues>) => {
    if (!user) return;

    let s3object;

    if (image) {
      const key = `tenants/${user.pool.storage.identityPoolId!}/${uuidv4()}-${image.name}`;

      const imageUploadResult = await Storage.put(key, image, {
        contentType: image.type,
        level: 'public',
      });

      s3object = {
        bucket: config.s3.BUCKET,
        region: config.s3.REGION,
        key: imageUploadResult.key,
        accessLevel: 'PUBLIC',
      };
    }

    const input: { [key: string]: any } = {
      primaryImageAltText: values.imageAltText,
    };

    if (s3object) {
      input.primaryImage = s3object;
    }

    try {
      const result = (await API.graphql(
        graphqlOperation(updateCollege, {
          input,
        }),
      )) as UpdateCollegeResponse;

      queryClient.setQueryData(['CollegePrimaryImage', institutionId], result.data.updateCollege);

      enqueueSnackbar('Changes successfully published!', {
        variant: 'success',
      });
    } catch {
      enqueueSnackbar('Unexpected error while saving changes!', {
        variant: 'error',
      });
    }

    resetForm();
  };

  return (
    <BoxFrame>
      <Formik enableReinitialize initialValues={initialValues} onSubmit={onSubmit} validationSchema={validationSchema}>
        {({ submitForm, isSubmitting }) => {
          return (
            <Form>
              <LeaveFormConfirmation />
              <Row>
                <CellImage>
                  <Typography
                    variant="subtitle1"
                    sx={{
                      mb: 1,
                    }}
                  >
                    Primary Image
                  </Typography>
                  <PrimaryImageWrapper>
                    {image ? (
                      <div>
                        <Img src={URL.createObjectURL(image)} alt="CellImage" />
                      </div>
                    ) : (
                      <>
                        {primaryImage && primaryImage.primaryImage ? (
                          <Image image={primaryImage.primaryImage} />
                        ) : (
                          <ImagePlaceholder />
                        )}
                      </>
                    )}
                    <ImgPicker>
                      <AddImageModal
                        onAdd={(image) => {
                          setImage(image);
                        }}
                      >
                        <EditIcon />
                      </AddImageModal>
                    </ImgPicker>
                  </PrimaryImageWrapper>
                </CellImage>
                <CellBody>
                  <Stack spacing={3}>
                    <Header>
                      <Typography
                        variant="subtitle2"
                        sx={{
                          mr: 2,
                        }}
                      >
                        Text Overlay
                      </Typography>
                    </Header>
                    <Field
                      component={FormikTextField}
                      rows={2}
                      fullWidth
                      multiline
                      name="message"
                      label="Text Overlay"
                      placeholder="Add text to your image."
                      value="Parfait automatically adds the name of your university as overlay text on the primary image."
                      disabled
                      sx={{
                        background: '#f5f5f5',
                        color: '#000',
                      }}
                    />
                    <div>
                      <AltTextTooltip />
                      <Field
                        component={FormikTextField}
                        rows={1}
                        fullWidth
                        multiline
                        name="imageAltText"
                        label="Alt text"
                        placeholder="Description of image. Ex: Students studying together with smiles on their faces."
                      />
                      <Tips>
                        <Typography
                          variant="subtitle2"
                          sx={{
                            color: '#666',
                            fontSize: '12px',
                          }}
                        >
                          100 characters limit
                        </Typography>
                      </Tips>
                    </div>
                  </Stack>
                </CellBody>
                <CellControls>
                  <Stack spacing={1}>
                    <LoadingButton
                      variant="contained"
                      size="small"
                      endIcon={<ArrowForwardIcon />}
                      onClick={submitForm}
                      loading={isSubmitting}
                      disabled={!primaryImage}
                    >
                      Publish
                    </LoadingButton>
                  </Stack>
                </CellControls>
              </Row>
            </Form>
          );
        }}
      </Formik>
    </BoxFrame>
  );
};

export default PrimaryImage;
