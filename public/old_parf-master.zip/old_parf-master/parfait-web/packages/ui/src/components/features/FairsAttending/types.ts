import {
  EventRegistrationAssignmentsType,
  EventRegistrationByTenantType,
  EventRegistrationsByTenantInputType,
  EventRegistrationStatus,
} from '../../../types/events';

export type FairsAttendingItemType = {
  name: string;
  status: EventRegistrationStatus;
  date: string;
  locationName: string;
  staffAssigned: EventRegistrationAssignmentsType[];
  expectedAttendees: number | null;
  id: string;
  fullDetail: EventRegistrationByTenantType;
};

export type FairsFilterVars = {
  statuses: EventRegistrationStatus[];
};

export type FairsAttendingContextType = {
  reqVars: EventRegistrationsByTenantInputType;
  setReqVars: (newVars: EventRegistrationsByTenantInputType) => void;
  onClearReqVars: (deleteVariables: 'filter' | 'search') => void;
};
