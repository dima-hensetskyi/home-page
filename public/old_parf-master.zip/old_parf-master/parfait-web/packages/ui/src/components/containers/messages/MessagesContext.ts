import { createContext } from 'react';
import { MessagesContextType } from './types';

const MessagesContext = createContext<MessagesContextType | null>(null);

export default MessagesContext;
