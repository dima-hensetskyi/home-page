import styled from 'styled-components';

export const Loader = styled.div`
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f5f5;
`;

export const Container = styled.div`
  border-radius: 4px;
  border: 1px solid #d8d8d8;
  background: #f5f5f5;
  text-align: center;
  padding: 24px;
  position: relative;
`;
