export const minScale = 1;
export const defaultScale = 10;
export const maxScale = 30;
export const scaleStep = 1;

export const minRotate = -180;
export const maxRotate = 180;
export const rotateStep = 1;
export const defaultRotate = 0;

export const quality = 0.85;
export const type = 'image/jpeg';
export const fillColor = '#fff';
