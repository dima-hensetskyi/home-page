import ImagePlaceholder from './ImagePlaceholder';

export default ImagePlaceholder;
