import { createInvites, getInvites, getInviteWithCode, resendInvite, updateInvite } from 'graphql/invites';
import { API, graphqlOperation } from 'aws-amplify';
import { GraphQLResult } from '@aws-amplify/api';

import {
  CreateInvitesInputType,
  CreateInvitesResponseType,
  GetInvitesResponseType,
  GetInvitesVarsType,
  GetInvitesWithCodeVarsType,
  GetInviteWithCodeResponseType,
  ResendInviteInputType,
  UpdateInvitationResponseType,
  UpdateInvitationVarsType,
} from '../../../types/invites';

export const getInvitesList = async (vars: GetInvitesVarsType) => {
  const result = (await API.graphql(graphqlOperation(getInvites, vars))) as GraphQLResult<GetInvitesResponseType>;
  return result.data?.getInvites;
};

export const createNewInvites = async (vars: CreateInvitesInputType) => {
  const result = (await API.graphql(graphqlOperation(createInvites, vars))) as GraphQLResult<CreateInvitesResponseType>;
  return result.data;
};

export const resendInvitation = async (vars: ResendInviteInputType) => {
  const result = (await API.graphql(graphqlOperation(resendInvite, vars))) as GraphQLResult<CreateInvitesResponseType>;
  return result.data;
};

export const getInviteItemWithCode = async (vars: GetInvitesWithCodeVarsType) => {
  const result = (await API.graphql(
    graphqlOperation(getInviteWithCode, vars),
  )) as GraphQLResult<GetInviteWithCodeResponseType>;
  return result.data?.getInviteWithCode;
};

export const updateInvitationItem = async (vars: UpdateInvitationVarsType) => {
  const result = (await API.graphql(
    graphqlOperation(updateInvite, vars),
  )) as GraphQLResult<UpdateInvitationResponseType>;
  return result.data;
};

export const updateInvitation = async (code: string) => {
  const invitation = await getInviteItemWithCode({ inviteCode: code });

  if (invitation) {
    await updateInvitationItem({
      input: {
        id: invitation?.id,
        status: 'ACCEPTED' as const,
      },
    });
  }
};
