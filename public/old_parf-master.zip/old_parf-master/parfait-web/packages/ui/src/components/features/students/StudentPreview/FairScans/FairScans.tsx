import React, { useState } from 'react';
import { useInfiniteQuery } from 'react-query';
import styled from 'styled-components';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import TableBody from '@mui/material/TableBody';
import { Box, Typography, Stack, TableSortLabel } from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import dayjs from 'dayjs';
import { API } from 'aws-amplify';
import { NoData } from '../../../../NoData';
import LoadingButton from '@mui/lab/LoadingButton';
import { getRecruitFairScansForUser } from 'graphql/recruits';

type Props = {
  userId: string;
};

type FairScansResponse = {
  data: {
    scans: {
      items: Array<FairScan>;
      nextToken: string | null;
    };
  };
};

type FairScan = {
  id: string;
  createdAt: string;
  recruit: {
    tenant: {
      name: 'Southern Methodist University';
    };
  };
};

const Wrapper = styled.div`
  tr:nth-of-type(even) td {
    background-color: #f5f5f5;
  }
`;

const FairScans = (props: Props) => {
  const { userId } = props;

  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [activeSort, setActiveSort] = useState<boolean>(false);

  const { data, isFetching, hasNextPage, fetchNextPage } = useInfiniteQuery(
    ['getRecruitFairScansForUser', sortDirection],
    async (data) => {
      const result = (await API.graphql({
        query: getRecruitFairScansForUser,
        variables: {
          userId,
          sortDirection: sortDirection.toUpperCase(),
          nextToken: data.pageParam,
          limit: 10,
        },
      })) as FairScansResponse;

      return result.data.scans;
    },
    {
      keepPreviousData: true,
      retry: false,
      getNextPageParam: (lastPage) => lastPage?.nextToken,
    },
  );

  const pages = data?.pages || [];
  const fairScans = pages.map((page) => page?.items || []).flat(1);

  return (
    <Stack spacing={1.5}>
      <Typography variant="h6" gutterBottom component="div">
        College Fair Scans
      </Typography>
      {!data ? (
        <Box sx={{ display: 'flex', justifyContent: 'center' }}>
          <CircularProgress size="20px" />
        </Box>
      ) : (
        <Wrapper>
          <TableContainer sx={{ maxHeight: '230px', mb: 2.5 }}>
            <Table
              stickyHeader
              aria-label="sticky table"
              sx={{
                border: '1px solid #e0e0e0',
              }}
            >
              <TableHead>
                <TableRow>
                  <TableCell
                    key="school"
                    align="left"
                    width="50%"
                    sx={{
                      background: '#e0e0e0',
                      paddingTop: 0.5,
                      paddingBottom: 0.5,
                    }}
                  >
                    School
                  </TableCell>
                  <TableCell
                    key="date"
                    align="left"
                    width="50%"
                    sx={{
                      background: '#e0e0e0',
                      paddingTop: 0.5,
                      paddingBottom: 0.5,
                    }}
                  >
                    <TableSortLabel
                      active={activeSort}
                      direction={sortDirection}
                      onClick={() => {
                        if (!activeSort) {
                          setActiveSort(true);
                        }
                        if (sortDirection === 'asc') {
                          setSortDirection('desc');
                        } else {
                          setSortDirection('asc');
                        }
                      }}
                    >
                      Date
                    </TableSortLabel>
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {fairScans && fairScans.length > 0 ? (
                  fairScans.map((record) => {
                    return (
                      <TableRow key={record.id}>
                        <TableCell
                          key="school"
                          align="left"
                          sx={{
                            paddingTop: 0.75,
                            paddingBottom: 0.75,
                          }}
                        >
                          {record.recruit.tenant.name}
                        </TableCell>
                        <TableCell
                          key="date"
                          align="left"
                          sx={{
                            paddingTop: 0.75,
                            paddingBottom: 0.75,
                          }}
                        >
                          {dayjs(record.createdAt).format('DD/MM/YYYY')}
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={4}>
                      <NoData
                        sx={{
                          width: '100%',
                        }}
                      />
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <Box sx={{ display: 'flex', visibility: hasNextPage ? 'visible' : 'hidden', justifyContent: 'flex-end' }}>
            <LoadingButton
              loading={isFetching}
              sx={{
                fontSize: '15px',
                lineHeight: '26px',
                letterSpacing: '0.46px',
              }}
              variant="contained"
              onClick={() => fetchNextPage()}
            >
              SHOW MORE
            </LoadingButton>
          </Box>
        </Wrapper>
      )}
    </Stack>
  );
};

export default FairScans;
