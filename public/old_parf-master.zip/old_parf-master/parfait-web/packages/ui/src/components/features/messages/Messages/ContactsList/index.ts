import ContactsList from './ContactsList';

export default ContactsList;
