import React from 'react';
import styled from 'styled-components';
import { imageHeight } from '../../../styled-components';
import { Typography } from '@mui/material';

const Wrapper = styled.div`
  height: ${imageHeight}px;
  background: #f5f5f5;
  border: 1px dashed #1976d2;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const ImagePlaceholder = () => {
  return (
    <Wrapper>
      <Typography variant="body2" color="#1976d2">
        Select primary image
      </Typography>
    </Wrapper>
  );
};

export default ImagePlaceholder;
