import { Box } from '@mui/material';
import React from 'react';

import { Container } from './styled-components';

type PropsType = {
  children: React.ReactNode;
};

export const LandingPageLayout: React.FC<PropsType> = ({ children }) => {
  return (
    <Box>
      <Container>{children}</Container>
    </Box>
  );
};
