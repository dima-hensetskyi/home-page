import React from 'react';
import { Typography, Tooltip } from '@mui/material';
import styled from 'styled-components';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';

const Wrapper = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 12px;
`;

const AltTextTooltip = () => {
  return (
    <Wrapper>
      <Typography variant="subtitle2">Alt text for image</Typography>
      <Tooltip
        sx={{
          marginLeft: '6px',
        }}
        title="Add alt image text to support accessibility for visually impaired users."
      >
        <InfoOutlinedIcon />
      </Tooltip>
    </Wrapper>
  );
};

export default AltTextTooltip;
