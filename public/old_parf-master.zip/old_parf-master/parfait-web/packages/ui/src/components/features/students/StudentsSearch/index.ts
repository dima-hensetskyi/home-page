import StudentsSearch from './StudentsSearch';

export default StudentsSearch;
