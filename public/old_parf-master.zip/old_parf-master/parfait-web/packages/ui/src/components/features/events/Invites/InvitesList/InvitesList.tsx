import { API } from 'aws-amplify';
import { Box, Typography } from '@mui/material';
import { useInfiniteQuery } from 'react-query';
import CircularProgress from '@mui/material/CircularProgress';
import LoadingButton from '@mui/lab/LoadingButton';
import React from 'react';
import styled from 'styled-components';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { getEventInvites } from 'graphql/events';

import { NoData } from '../../../../NoData';

const Wrapper = styled.div`
  tr:nth-of-type(even) td {
    background-color: #f5f5f5;
  }
`;

type Props = {
  eventId: string;
};

type EventInvite = {
  createdAt: string;
  email: string;
  eventId: string;
  id: string;
  status: 'INVITED' | 'REGISTERED' | 'DECLINED';
  updatedAt: string;
  registration: null | {
    registeredInstitutionName: string;
    registeredName: string;
    status: 'CONFIRMED' | 'CANCELLED';
  };
};

type GetEventInvites = {
  data: {
    invites: {
      items: Array<EventInvite>;
      nextToken: null | string;
    };
  };
};

const columns = [
  { id: 'email', label: 'Email' },
  { id: 'name', label: 'Name' },
  { id: 'college', label: 'College' },
  { id: 'reg', label: 'Reg.' },
];

const InvitesList = (props: Props) => {
  const { eventId } = props;

  const { data, isFetching, isLoading, hasNextPage, fetchNextPage } = useInfiniteQuery(
    ['getEventInvites', eventId],
    async (data) => {
      const result = (await API.graphql({
        query: getEventInvites,
        variables: {
          eventId: eventId,
          nextToken: data.pageParam,
          limit: 10,
        },
      })) as GetEventInvites;

      return result.data.invites;
    },
    {
      keepPreviousData: true,
      retry: false,
      getNextPageParam: (lastPage) => lastPage?.nextToken,
    },
  );

  const pages = data?.pages || [];
  const eventInvites = pages.map((page) => page?.items || []).flat(1);

  return isLoading ? (
    <Box sx={{ display: 'flex', justifyContent: 'center' }}>
      <CircularProgress size="20px" />
    </Box>
  ) : (
    <Wrapper>
      <Typography
        variant="subtitle1"
        sx={{
          mb: 1,
        }}
      >
        Current invites
      </Typography>
      <TableContainer sx={{ maxHeight: 240, mb: 2.5 }}>
        <Table
          stickyHeader
          aria-label="sticky table"
          sx={{
            border: '1px solid #e0e0e0',
          }}
        >
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell
                  key={column.id}
                  align="left"
                  sx={{
                    background: '#e0e0e0',
                    paddingTop: 0.5,
                    paddingBottom: 0.5,
                  }}
                >
                  {column.label}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {eventInvites && eventInvites.length > 0 ? (
              eventInvites.map((record) => {
                return (
                  <TableRow key={record.id}>
                    <TableCell
                      key="email"
                      align="left"
                      sx={{
                        paddingTop: 0.75,
                        paddingBottom: 0.75,
                      }}
                    >
                      {record.email}
                    </TableCell>
                    <TableCell
                      key="name"
                      align="left"
                      sx={{
                        paddingTop: 0.75,
                        paddingBottom: 0.75,
                      }}
                    >
                      {record.registration ? record.registration.registeredName : '-'}
                    </TableCell>
                    <TableCell
                      key="college"
                      align="left"
                      sx={{
                        paddingTop: 0.75,
                        paddingBottom: 0.75,
                      }}
                    >
                      {record.registration ? record.registration.registeredInstitutionName : '-'}
                    </TableCell>
                    <TableCell
                      key="status"
                      align="left"
                      sx={{
                        paddingTop: 0.75,
                        paddingBottom: 0.75,
                      }}
                    >
                      {record.registration ? (
                        <>
                          {record.registration.status === 'CONFIRMED' ? 'Registered' : ''}
                          {record.registration.status === 'CANCELLED' ? 'Declined' : ''}
                        </>
                      ) : (
                        'Invited'
                      )}
                    </TableCell>
                  </TableRow>
                );
              })
            ) : (
              <TableRow>
                <TableCell colSpan={4}>
                  <NoData
                    sx={{
                      width: '100%',
                    }}
                  />
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <Box sx={{ display: 'flex', visibility: hasNextPage ? 'visible' : 'hidden', justifyContent: 'flex-end' }}>
        <LoadingButton
          loading={isFetching}
          sx={{
            fontSize: '15px',
            lineHeight: '26px',
            letterSpacing: '0.46px',
          }}
          variant="contained"
          onClick={() => fetchNextPage()}
        >
          SHOW MORE
        </LoadingButton>
      </Box>
    </Wrapper>
  );
};

export default InvitesList;
