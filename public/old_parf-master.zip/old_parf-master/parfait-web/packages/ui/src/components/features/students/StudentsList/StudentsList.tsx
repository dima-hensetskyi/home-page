import React, { useState } from 'react';
import { useInfiniteQuery } from 'react-query';
import { API } from 'aws-amplify';
import { Loader } from '../../../Loader';
import TableComponent from '../../../Table/TableComponent';
import { Box, Typography } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { Student, GetStudentsResponse, FilterValue } from '../types';
import StudentPreview from '../StudentPreview';
import { getStudents } from 'graphql/institutions';
import { ModelSortDirection } from '../../../../types/general';

type Props = {
  search: string;
  filter: FilterValue;
};

const StudentsList = (props: Props) => {
  const { search, filter } = props;

  const [entityPreview, setEntityPreview] = useState<Student | null>(null);
  const [sort, setSort] = useState<ModelSortDirection>('ASC');

  const { data, isFetching, isLoading, hasNextPage, fetchNextPage, refetch } = useInfiniteQuery(
    ['getStudents', search, filter, sort],
    async (data) => {
      const filterParams: { [key: string]: string | Array<string> } = {};

      if (search) {
        filterParams.searchTerms = search;
      }

      if (filter.year.length > 0) {
        filterParams.graduationYears = filter.year;
      }

      const result = (await API.graphql({
        query: getStudents,
        variables: {
          nextToken: data.pageParam,
          limit: 10,
          filter: filterParams,
          sortDirection: sort,
        },
      })) as GetStudentsResponse;

      return result.data.students;
    },
    {
      keepPreviousData: true,
      retry: false,
      getNextPageParam: (lastPage) => lastPage?.nextToken,
    },
  );

  const pages = data?.pages || [];
  const students = pages.map((page) => page?.items || []).flat(1);

  return isLoading ? (
    <Loader />
  ) : (
    <>
      <TableComponent
        sortOrder={sort}
        orderBy="student"
        onSortLabel={() => {
          setSort((state) => {
            return state === 'ASC' ? 'DESC' : 'ASC';
          });
        }}
        loading={isFetching}
        tableHeaders={{
          student: 'Student',
          status: 'Status',
          graduationYear: 'Year',
          favorites: 'Favorites',
          shortList: 'Short list',
          fairScans: 'Fair scans',
        }}
        tableDataItems={
          students
            ? students.map((student) => {
                return {
                  student: {
                    familyName: student.familyName,
                    givenName: student.givenName,
                    id: student.id,
                  },
                  status: student.type === 'StudentPending' ? 'Pending' : 'Active',
                  graduationYear: student.graduationYear,
                  favorites: student.type === 'StudentActive' ? student.stats.favorites : '-',
                  shortList: student.type === 'StudentActive' ? student.stats.shortLists : '-',
                  fairScans: student.type === 'StudentActive' ? student.stats.scans : '-',
                };
              })
            : []
        }
        columnsWidth={{
          student: '30%',
          status: '20%',
          graduationYear: '20%',
          favorites: '10%',
          shortList: '10%',
          fairScans: '10%',
        }}
        tableCustomRenderers={{
          student: (record) => {
            return (
              <>
                <Typography
                  sx={{ color: (theme) => theme.palette.primary.main, ':hover': { cursor: 'pointer' } }}
                  onClick={() => {
                    if (!data) return;

                    const entity = students.find((item) => {
                      return item.id === record.student.id;
                    })!;

                    setEntityPreview(entity);
                  }}
                  variant="body2"
                >
                  {record.student.givenName} {record.student.familyName}
                </Typography>
              </>
            );
          },
          status: (record) => {
            return <>{record.status}</>;
          },
          graduationYear: (record) => {
            return <>{record.graduationYear}</>;
          },
          favorites: (record) => {
            return <>{record.favorites}</>;
          },
          shortList: (record) => {
            return <>{record.shortList}</>;
          },
          fairScans: (record) => {
            return <>{record.fairScans}</>;
          },
        }}
      />
      <Box sx={{ display: 'flex', visibility: hasNextPage ? 'visible' : 'hidden', justifyContent: 'flex-end' }}>
        <LoadingButton
          loading={isFetching}
          sx={{
            fontSize: '15px',
            lineHeight: '26px',
            letterSpacing: '0.46px',
          }}
          variant="contained"
          onClick={() => fetchNextPage()}
        >
          SHOW MORE
        </LoadingButton>
      </Box>
      <StudentPreview
        entity={entityPreview}
        onClose={() => {
          setEntityPreview(null);
        }}
        refetch={() => {
          refetch();
        }}
      />
    </>
  );
};

export default StudentsList;
