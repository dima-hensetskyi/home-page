import { FairDetails } from './FairDetails';
export { FairDetails };
