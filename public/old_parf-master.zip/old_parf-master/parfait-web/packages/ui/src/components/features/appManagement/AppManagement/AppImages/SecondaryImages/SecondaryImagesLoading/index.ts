import SecondaryImagesLoading from './SecondaryImagesLoading';

export default SecondaryImagesLoading;
