import React, { useState } from 'react';
import LoadingButton from '@mui/lab/LoadingButton';
import { Dialog, Typography, DialogTitle, Box, Stack, Button } from '@mui/material';
import { InstitutionImage } from '../../../../../../../../types/institutions';
import { InstitutionTemporaryImage } from '../../types';

type Props = {
  onDelete: (image: InstitutionImage | InstitutionTemporaryImage) => Promise<void>;
  image: InstitutionImage | InstitutionTemporaryImage;
};

const DeleteConfirm = (props: Props) => {
  const { onDelete, image } = props;

  const [modalVisible, setModalVisible] = useState<boolean>(false);
  const [deleteLoading, setDeleteLoading] = useState<boolean>(false);

  const onDeleteClick = async () => {
    try {
      setDeleteLoading(true);
      await onDelete(image);
      setModalVisible(false);
      setDeleteLoading(false);
    } catch (e) {
      setDeleteLoading(false);
    }
  };
  return (
    <>
      <Button
        variant="outlined"
        size="small"
        color="error"
        onClick={() => {
          setModalVisible(true);
        }}
      >
        Delete
      </Button>
      <Dialog onClose={() => setModalVisible(false)} open={modalVisible}>
        <DialogTitle>Delete?</DialogTitle>
        <Box
          sx={{
            margin: 3,
            mt: 0,
          }}
        >
          <Typography variant="body2">
            Are you sure you want to delete this image and associated text? This action cannot be undone.
          </Typography>
          <Stack direction="row" spacing={2} sx={{ mt: 2 }}>
            <LoadingButton
              variant="contained"
              size="small"
              color="error"
              loading={deleteLoading}
              onClick={onDeleteClick}
            >
              Delete
            </LoadingButton>
            <Button
              variant="outlined"
              onClick={() => {
                setModalVisible(false);
              }}
            >
              CANCEL
            </Button>
          </Stack>
        </Box>
      </Dialog>
    </>
  );
};

export default DeleteConfirm;
