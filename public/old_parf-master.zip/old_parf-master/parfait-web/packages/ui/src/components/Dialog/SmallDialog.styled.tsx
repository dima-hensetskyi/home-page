import { Dialog } from '@mui/material';
import styled from 'styled-components';

export const StyledDialog = styled(Dialog)`
  width: 390px;
  right: 0 !important;
  left: auto !important;
  height: 100%;
  z-index: 998 !important;
`;
