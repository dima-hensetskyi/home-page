import * as Yup from 'yup';

export const validationSchema = Yup.object().shape({
  name: Yup.string().required('Name is required.').nullable(),
  schoolURL: Yup.string().required('Web Address is required').url('Please enter a valid url.').nullable(),
  address1: Yup.string().required('Address is required.').nullable(),
  stateProvince: Yup.string().required('State is required.').nullable(),
  country: Yup.string().required('Country is required.').nullable(),
  postalCode: Yup.string().required('Postal Code is required.').nullable(),
  city: Yup.string().required('City is required.').nullable(),
});
