import InvitesList from './InvitesList';

export default InvitesList;
