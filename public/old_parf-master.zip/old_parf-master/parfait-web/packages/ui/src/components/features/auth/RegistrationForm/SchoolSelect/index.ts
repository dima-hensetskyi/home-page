import SchoolSelect from './SchoolSelect';

export default SchoolSelect;
