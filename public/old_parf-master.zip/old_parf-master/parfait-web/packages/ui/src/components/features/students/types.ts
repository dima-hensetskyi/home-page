export type FormValues = {
  phoneNumber: string;
  emailAddress: string;
  familyName: string;
  givenName: string;
  graduationYear: string;
  startDate?: string;
  endDate?: string;
};

export type Student = StudentPending | StudentActive;

export type FilterValue = { year: Array<string> };

type Institution = { [key: string]: string | null }; // TODO

type StudentUserAccess = 'NEW' | 'REQUEST' | 'GRANTED' | 'DECLINED';

export type StudentPending = {
  id: string;
  type: 'StudentPending';
  institutionId: string;
  institution: Institution;
  phoneNumber?: string;
  emailAddress?: string;
  familyName: string;
  givenName: string;
  graduationYear: string;
  startDate?: string;
  endDate?: string;
  createdAt: string;
  updatedAt: string;
  lastInvite: string;
};

export type StudentActive = {
  id: string;
  type: 'StudentActive';
  userId: string;

  familyName: string;
  givenName: string;
  phoneNumber: string;
  emailAddress: string;

  institutionId: string;
  institution: Institution;
  access: StudentUserAccess;
  graduationYear: string;
  startDate?: string;
  endDate?: string;
  createdAt: string;
  updatedAt: string;

  stats: {
    bookmarks: number;
    favorites: number;
    shortLists: number;
    scans: number;
  };
};

export type GetStudentsResponse = {
  data: {
    students: {
      items: Array<Student>;
      nextToken: string | null;
    };
  };
};
