export type FormValues = {
  emails: Array<string>;
};
