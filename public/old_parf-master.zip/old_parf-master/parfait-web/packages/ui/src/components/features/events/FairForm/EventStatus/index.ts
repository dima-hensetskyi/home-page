import EventStatus from './EventStatus';

export default EventStatus;
