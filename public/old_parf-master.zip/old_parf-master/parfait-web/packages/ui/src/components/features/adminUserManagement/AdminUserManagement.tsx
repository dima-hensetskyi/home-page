import { Box, Tab, Tabs, Typography } from '@mui/material';
import React, { useState } from 'react';
import { UsersView } from './UsersView';

type TabPanelProps = {
  children?: React.ReactNode;
  index: number;
  value: number;
};

const TabPanel: React.FC<TabPanelProps> = ({ children, value, index, ...other }: TabPanelProps) => {
  if (value !== index) return null;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ py: '25px' }}>{children}</Box>}
    </div>
  );
};

export const AdminUserManagement = () => {
  const [value, setValue] = useState(0);
  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ display: 'flex', flex: '1', flexDirection: 'column' }}>
      <Typography variant="h4">Manage Account</Typography>
      <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
        <Tab label="Users" />
        <Tab label="Pricing" />
        <Tab label="Billing" />
      </Tabs>
      <TabPanel value={value} index={0}>
        <UsersView />
      </TabPanel>
      <TabPanel value={value} index={1}>
        Pricing
      </TabPanel>
      <TabPanel value={value} index={2}>
        Billing
      </TabPanel>
    </Box>
  );
};
