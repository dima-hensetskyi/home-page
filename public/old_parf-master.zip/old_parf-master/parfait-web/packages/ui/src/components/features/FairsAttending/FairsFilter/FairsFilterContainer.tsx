import { useToggle } from 'react-use';
import React from 'react';

import { FairsFilter } from './FairsFilter';
import { FilterMenu } from '../../../Table';
import { useFairsAttendingContext } from '../FairsAttendingContext';

export const FairsFilterContainer: React.FC = () => {
  const [isMenuOpen, setMenuOpen] = useToggle(false);
  const { reqVars } = useFairsAttendingContext();
  const isFiltering = !!reqVars?.filter?.statuses;

  const menuProps = {
    isMenuOpen,
    setMenuOpen,
    isApplyFilter: isFiltering,
  };

  const filterProps = {
    setMenuOpen,
  };

  return (
    <FilterMenu {...menuProps}>
      <FairsFilter {...filterProps} />
    </FilterMenu>
  );
};
