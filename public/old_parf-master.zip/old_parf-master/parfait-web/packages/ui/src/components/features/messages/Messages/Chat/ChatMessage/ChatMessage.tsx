import React, { useEffect } from 'react';
import styled from 'styled-components';
import { Typography } from '@mui/material';
import dayjs from 'dayjs';
import { API } from 'aws-amplify';
import { updateChatMessage } from 'graphql/chat';
import { Message } from '../../../../../containers/messages/types';
import { AvatarComponent } from '../../../../../Avatar';

const Container = styled.div`
  display: flex;
  padding-left: 8px;
  padding-right: 16px;
`;

const Body = styled.div`
  background: #f5f5f5;
  border-radius: 8px;
  padding: 8px;
  width: 273px;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.75rem;
`;

const Date = styled.div``;

const UserName = styled.div``;

const Message = styled.div`
  word-break: break-word;
`;

type Props = {
  message: Message;
  chatId: string;
  onMessageRead?: () => void;
};

const ChatMessage = (props: Props) => {
  const { message, onMessageRead, chatId } = props;

  const isTenant = message.type === 'TENANT';

  useEffect(() => {
    const assyncSetAsRead = async () => {
      await API.graphql({
        query: updateChatMessage,
        variables: {
          input: {
            id: message.id,
            chatId,
            status: 'READ',
          },
        },
      });
      if (onMessageRead) {
        onMessageRead();
      }
    };

    if ((message.type === 'USER' && message.status === 'SENT') || message.status === 'DELIVERED') {
      assyncSetAsRead();
    }
  }, [message, chatId]);

  const date = (
    <Date>
      {!message.hideTime && (
        <Typography variant="caption" sx={{ color: '#00000099' }}>
          {dayjs(message.createdAt).format('hh:mm A')}
        </Typography>
      )}
    </Date>
  );

  const userName = (
    <UserName>
      {!message?.isGroupMessage && (
        <Typography variant="subtitle2">
          {isTenant ? message.tenantUser.displayName : message.user.displayName}
        </Typography>
      )}
    </UserName>
  );

  const body = (
    <Body
      style={{
        marginLeft: isTenant ? '0' : '8px',
        marginRight: isTenant ? '8px' : '0',
      }}
    >
      <Header>
        {isTenant ? (
          <>
            {date}
            {userName}
          </>
        ) : (
          <>
            {userName}
            {date}
          </>
        )}
      </Header>
      <Message>
        <Typography variant="body2">{message.content}</Typography>
      </Message>
    </Body>
  );
  return (
    <Container
      style={{
        justifyContent: isTenant ? 'flex-end' : 'flex-start',
        paddingTop: message?.isGroupMessage ? '8px' : '16px',
      }}
    >
      {isTenant ? (
        <>
          {body}
          <AvatarComponent
            avatar={message.tenantUser?.avatar}
            name={message.tenantUser.name}
            sx={{ width: '32px', height: '32px', visibility: !message?.isGroupMessage ? 'visible' : 'hidden' }}
          />
        </>
      ) : (
        <>
          <AvatarComponent
            avatar={message.user?.avatar}
            name={message.user.name}
            sx={{ width: '32px', height: '32px', visibility: !message?.isGroupMessage ? 'visible' : 'hidden' }}
          />
          {body}
        </>
      )}
    </Container>
  );
};

export default ChatMessage;
