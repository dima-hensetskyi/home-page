import ClipboardCopy from './ClipboardCopy';

export default ClipboardCopy;
