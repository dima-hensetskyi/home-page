import { Fair } from '../../../types/events';

export type FairResponse = {
  data: {
    events: {
      items: Array<Fair>;
      nextToken: string | null;
    };
  };
};

export type GetEventResponse = {
  data: {
    event: Fair;
  };
};

export type GetEventInviteResponse = {
  data: {
    getEventInvite: {
      email: string;
      eventInviteByEmail: string;
      id: string;
      registration: {
        id: string;
        status: string;
      } | null;
    };
  };
};
