import * as Yup from 'yup';

export const confirmEmailSchema = Yup.object().shape({
  linkedInUrl: Yup.string().url('Please enter a valid url.').nullable(),
  staffProfileURL: Yup.string().url('Please enter a valid url.').nullable(),
});
