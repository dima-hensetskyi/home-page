type PickByInputValues = { [key: string]: string | number | null | undefined };
type PickByOutputValues = { [key: string]: string | number | null };

export const pickBy = (object: PickByInputValues): PickByOutputValues => {
  const result: PickByOutputValues = {};

  Object.entries(object).map(([key, value]) => {
    if (value) {
      result[key] = value;
    } else {
      result[key] = null;
    }
  });

  return result;
};
