import { Invite } from './../../../../types/invites';

export const getCorrectInvite = (invite: Invite) => {
  const { id, emailAddress, status, lastInvite } = invite;
  return {
    emailAddress,
    date: lastInvite,
    status,
    id,
    invite,
  };
};

export const getCorrectInvitesList = (arr: Invite[] | []) => arr.map((invite) => getCorrectInvite(invite));
