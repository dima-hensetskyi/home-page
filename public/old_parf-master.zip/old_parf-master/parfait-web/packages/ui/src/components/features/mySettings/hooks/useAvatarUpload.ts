import { Auth, Storage } from 'aws-amplify';
import { useMutation } from 'react-query';
import config from 'config/aws-config';

export type VarsType = {
  id: string;
  image: File | null;
};

export const useAvatarUpload = () => {
  return useMutation(async ({ id, image }: VarsType) => {
    if (image) {
      const key = id;
      const result = await Storage.put(key, image, {
        contentType: image.type,
        level: 'protected',
      });

      if (result) {
        const credentials = await Auth.currentUserCredentials();
        const identityId = credentials.identityId;

        const s3object = {
          bucket: config.s3.BUCKET,
          region: config.s3.REGION,
          key: result.key,
          accessLevel: 'PROTECTED' as const,
          identityId,
        };

        return s3object;
      }
    }
  });
};
