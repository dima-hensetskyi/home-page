import React, { useState } from 'react';
import { Link as RouterLink, useSearchParams } from 'react-router-dom';
import { Link, LinearProgress, Alert, Stack, Typography, Tooltip } from '@mui/material';
import AuthHeader from '../AuthHeader';
import { Formik, Form, Field, FormikHelpers } from 'formik';
import { TextField as FormikTextField } from 'formik-mui';
import dayjs from 'dayjs';
import useAuthContext from '../../../containers/auth/useAuthContext';
import { getRegistrationValidationSchema } from './validationSchema';
import SchoolSelect from './SchoolSelect';
import { InstitutionInfo } from './types';
import PasswordField from './PasswordField';
import { Container, Error } from '../styledComponents';
import Button from '../Button';
import { isValidZipCode } from './utils';
import FormControlLabel from '@mui/material/FormControlLabel';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import IOSSwitch from './IOSSwitch';

const accountExistError =
  'A Parfait account already exists for your school. We emailed the Account Administrator and let them know you have requested an invitation.';

const RegistrationForm = () => {
  const [registrationError, setRegistrationError] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [displaySchoolInput, setDisplaySchoolInput] = useState(false);
  const [institutionInfo, setInstitutionInfo] = useState<InstitutionInfo | null>(null);

  const { signUp, appType } = useAuthContext();
  const [searchParams] = useSearchParams();
  const code = searchParams.get('code');

  const initialValues = {
    name: '',
    email: '',
    school: '',
    userName: '',
    password: '',
    zipCode: '',
    displaySchoolInput,
  };

  const generateCustomAccountName = (values: typeof initialValues): string => {
    if (values.email.indexOf('.edu') !== -1) {
      return values.email.split('@')[0];
    }

    return dayjs().format('MMDDHHmmss');
  };

  const onSubmit = async (values: typeof initialValues, { setSubmitting }: FormikHelpers<typeof initialValues>) => {
    if (appType === 'university') {
      if (institutionInfo) {
        try {
          await signUp(
            values.name,
            values.email,
            values.userName,
            values.password,
            institutionInfo.account,
            institutionInfo.institutionName,
            institutionInfo.institutionId,
            code,
          );
        } catch {
          setRegistrationError(accountExistError);
          setSubmitting(false);
        }
      } else {
        setRegistrationError('Please select a school!');
        setSubmitting(false);
      }
    }

    if (appType === 'highSchool') {
      try {
        if (displaySchoolInput) {
          await signUp(
            values.name,
            values.email,
            values.userName,
            values.password,
            generateCustomAccountName(values),
            values.school,
          );
        } else {
          if (institutionInfo) {
            await signUp(
              values.name,
              values.email,
              values.userName,
              values.password,
              generateCustomAccountName(values),
              institutionInfo.institutionName,
              institutionInfo.institutionId,
            );
          } else {
            setRegistrationError('Please select a school!');
            setSubmitting(false);
          }
        }
      } catch {
        setRegistrationError(accountExistError);
        setSubmitting(false);
      }
    }
  };

  return (
    <Container>
      <AuthHeader
        title="Welcome!"
        description={
          appType === 'highSchool'
            ? 'Create your high school account and start connecting with students.'
            : 'Create your college account to start connecting to students today'
        }
      />
      <Formik
        validationSchema={getRegistrationValidationSchema(appType)}
        initialValues={initialValues}
        onSubmit={onSubmit}
      >
        {({ isSubmitting, handleBlur, setFieldValue, touched, setTouched, values }) => (
          <Form>
            <Stack spacing={2}>
              <Stack spacing={2}>
                {appType === 'highSchool' && (
                  <>
                    <Stack direction="row" alignItems="center">
                      <FormControlLabel
                        control={<IOSSwitch sx={{ m: 1 }} />}
                        label={
                          <Typography variant="body2">
                            {displaySchoolInput ? 'Switch to school select' : 'Switch to input the school name'}
                          </Typography>
                        }
                        onChange={() => {
                          setDisplaySchoolInput((state) => !state);
                          setFieldValue('displaySchoolInput', !values.displaySchoolInput);
                          setFieldValue('school', '');
                          setTouched({ ...touched, school: false });
                        }}
                        checked={displaySchoolInput}
                      />
                      <Tooltip
                        sx={{
                          marginLeft: '6px',
                        }}
                        title={
                          displaySchoolInput
                            ? 'You can find a specific school in the list'
                            : "If you didn't find a specific school in the list, you can enter it here"
                        }
                      >
                        <InfoOutlinedIcon />
                      </Tooltip>
                    </Stack>
                    {displaySchoolInput ? (
                      <Field fullWidth component={FormikTextField} name="school" label="School" type="text" />
                    ) : (
                      <>
                        <Field
                          fullWidth
                          component={FormikTextField}
                          name="zipCode"
                          label="Zipcode"
                          type="text"
                          onBlur={(event: any) => {
                            handleBlur(event);
                            if (isValidZipCode(event.target.value)) {
                              setZipCode(event.target.value);
                            } else {
                              setZipCode('');
                            }
                          }}
                        />
                        <SchoolSelect
                          institutionInfo={institutionInfo}
                          setInstitutionInfo={setInstitutionInfo}
                          zipCode={zipCode}
                          appType={appType}
                        />
                      </>
                    )}
                  </>
                )}
                <Field fullWidth component={FormikTextField} name="name" label="Name" type="text" />
                <Field
                  fullWidth
                  component={FormikTextField}
                  name="email"
                  label="Email"
                  type="email"
                  placeholder="you@school.edu/org/com"
                />
                {appType === 'university' && (
                  <SchoolSelect
                    institutionInfo={institutionInfo}
                    setInstitutionInfo={setInstitutionInfo}
                    zipCode={zipCode}
                    appType={appType}
                  />
                )}
                <Field fullWidth component={FormikTextField} name="userName" label="Username" type="text" />
                <PasswordField />
              </Stack>
              <Stack spacing={1}>
                <Typography variant="body2">
                  By signing up, I agree to the Parfait{' '}
                  <Link component={RouterLink} to="/terms-and-conditions" underline="hover">
                    Privacy Policy
                  </Link>
                  {` and `}
                  <Link component={RouterLink} to="/terms-and-conditions" underline="hover">
                    Terms of Service
                  </Link>
                </Typography>
                {registrationError && (
                  <Error>
                    <Alert severity="error">{registrationError}</Alert>
                  </Error>
                )}
                <div>
                  {isSubmitting && <LinearProgress />}
                  <Button type="submit">Sign up</Button>
                </div>
                <Typography variant="body2">
                  Already have an account?{' '}
                  <Link component={RouterLink} to="/sign-in" underline="hover">
                    Sign In
                  </Link>
                </Typography>
              </Stack>
            </Stack>
          </Form>
        )}
      </Formik>
    </Container>
  );
};

export default RegistrationForm;
