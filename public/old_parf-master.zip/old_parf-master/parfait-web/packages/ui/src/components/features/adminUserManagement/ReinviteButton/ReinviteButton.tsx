import { CircularProgress, Typography } from '@mui/material';
import { useMutation } from 'react-query';
import { useSnackbar } from 'notistack';
import React, { useState } from 'react';

import { getCorrectString } from '../utils';
import { reinviteUser } from '../api';
import { UserListItem } from '../type';

type PropsType = {
  user: UserListItem;
};

export const ReinviteButton: React.FC<PropsType> = ({ user }: PropsType) => {
  const [reinviteId, setReinviteId] = useState<string | null>(null);
  const { enqueueSnackbar } = useSnackbar();

  const reinvite = useMutation(reinviteUser, {
    onError: () => {
      enqueueSnackbar('Something went wrong', {
        variant: 'error',
      });
    },
    onSuccess: () => {
      enqueueSnackbar('Invitation sent!', {
        variant: 'success',
      });
    },
    onSettled: () => {
      setReinviteId(null);
    },
  });

  return (
    <>
      {getCorrectString(user.status)}
      {user.status === 'INVITED' &&
        (reinviteId === user.id && reinvite.isLoading ? (
          <CircularProgress
            sx={{ width: '20px !important', position: 'absolute', height: '20px !important', ml: '10px' }}
          />
        ) : (
          <Typography
            sx={{
              color: (theme) => theme.palette.primary.main,
              cursor: 'pointer',
              display: 'inline',
              px: 0,
              mx: 0,
            }}
            variant="body2"
            onClick={() => {
              if (!reinvite.isLoading) {
                setReinviteId(user.id);
                reinvite.mutateAsync({ input: { id: user.id } });
              }
            }}
          >
            ...Invite Again
          </Typography>
        ))}
    </>
  );
};
