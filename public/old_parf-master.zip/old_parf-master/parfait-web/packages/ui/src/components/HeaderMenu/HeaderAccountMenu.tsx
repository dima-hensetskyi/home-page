import { AccountCircle, Logout, Settings } from '@mui/icons-material';
import { Button, Divider, ListItemIcon, Menu, MenuItem, Tooltip, Typography } from '@mui/material';
import { useBoolean } from 'react-use';
import { useNavigate } from 'react-router-dom';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import React, { useState } from 'react';
import SupervisorAccountIcon from '@mui/icons-material/SupervisorAccount';

import { AuthenticatedTenantUserResponse } from '../../types/tenant';
import { AvatarComponent } from '../Avatar';
import { BasicDialog } from '../Dialog';
import { getFullUserName } from '../Header/utils';
import { MySettings } from '../features';
import useAuthContext from '../containers/auth/useAuthContext';

type PropsType = {
  authenticatedTenantUser: AuthenticatedTenantUserResponse;
};

const HeaderAccountMenu: React.FC<PropsType> = ({ authenticatedTenantUser }: PropsType) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const { signOut, userRole } = useAuthContext();
  const [isSettingsOpen, setSettingsOpen] = useBoolean(false);
  const {
    getAuthenticatedTenantUser: { avatar, id },
  } = authenticatedTenantUser;

  const open = Boolean(anchorEl);
  const navigate = useNavigate();

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <>
      <Tooltip title="Account settings">
        <Button
          size="small"
          variant="text"
          sx={{ color: 'rgba(0, 0, 0, 0.6)' }}
          endIcon={<KeyboardArrowDownIcon />}
          onClick={handleClick}
          aria-controls={open ? 'account-menu' : undefined}
          aria-haspopup="true"
          aria-expanded={open ? 'true' : undefined}
        >
          {avatar?.key ? (
            <AvatarComponent avatar={avatar} sx={{ marginRight: '10px', width: '30px', height: '30px' }} />
          ) : (
            <AccountCircle sx={{ marginRight: '10px', fontSize: '35px' }} />
          )}
          <Typography variant="subtitle1" sx={{ textTransform: 'none' }}>
            {getFullUserName(authenticatedTenantUser)}
          </Typography>
        </Button>
      </Tooltip>
      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            minWidth: '270px',
            overflow: 'visible',
            filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
            mt: 1.5,
            '& .MuiAvatar-root': {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            '&:before': {
              content: '""',
              display: 'block',
              position: 'absolute',
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: 'background.paper',
              transform: 'translateY(-50%) rotate(45deg)',
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
        <MenuItem>
          <AvatarComponent avatar={avatar} /> My account
        </MenuItem>
        <Divider />
        {userRole === 'Admin' && (
          <MenuItem onClick={() => navigate('manage-account')}>
            <ListItemIcon>
              <SupervisorAccountIcon fontSize="small" />
            </ListItemIcon>
            Admin Account
          </MenuItem>
        )}
        <MenuItem onClick={() => setSettingsOpen(true)}>
          <ListItemIcon>
            <Settings fontSize="small" />
          </ListItemIcon>
          Settings
        </MenuItem>
        <MenuItem
          onClick={(evt) => {
            evt.preventDefault;
            signOut();
          }}
        >
          <ListItemIcon>
            <Logout fontSize="small" />
          </ListItemIcon>
          Log Out
        </MenuItem>
      </Menu>
      <BasicDialog
        paperSx={{ minWidth: '472px', maxWidth: '472px' }}
        titleBoxSx={{ p: '32px', pb: 0 }}
        bodySx={{ p: '32px', pt: '24px' }}
        title="My settings"
        open={isSettingsOpen}
        onClose={() => setSettingsOpen(false)}
      >
        <MySettings onClose={() => setSettingsOpen(false)} />
      </BasicDialog>
    </>
  );
};

export default HeaderAccountMenu;
