export type RegistrationFormValues = {
  name: string;
  email: string;
  school: string;
  userName: string;
  password: string;
  zipCode: string;
};

export type InstitutionInfo = {
  account: string;
  institutionName: string;
  institutionId: string;
};
