import { defineConfig } from 'tsup';
import svgrPlugin from 'esbuild-plugin-svgr';

export default defineConfig({
  entry: ['src/index.ts', 'src/components/index.ts'],
  esbuildPlugins: [svgrPlugin()],
});
