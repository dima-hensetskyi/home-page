import React, { useState, useEffect } from "react";
import { Route } from "react-router-dom";
import { Auth } from "aws-amplify";
import { useHistory } from "react-router-dom";
import UnauthLoading from "./unauth/unauthLoading";

const PrivateRoute = ({ component: Component, ...rest }) => {
  const history = useHistory();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    async function onLoad() {
      try {
        await Auth.currentSession();
        setIsAuthenticated(true);
      } catch (e) {
        console.error(e);
        // history.push("/");
      }
    }

    onLoad();
  }, [history]);

  return (
    <Route
      {...rest}
      render={(props) =>
        isAuthenticated ? <Component {...rest} {...props} /> : <UnauthLoading />
      }
    />
  );
};

export default PrivateRoute;
