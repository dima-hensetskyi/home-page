import React, { useState, useEffect } from "react";
import Avatar from "@material-ui/core/Avatar";
import Button from "@material-ui/core/Button";
import CssBaseline from "@material-ui/core/CssBaseline";
import TextField from "@material-ui/core/TextField";
import Link from "@material-ui/core/Link";
import Grid from "@material-ui/core/Grid";
import Box from "@material-ui/core/Box";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import Container from "@material-ui/core/Container";
import Copyright from "../../copyright";
import { useHistory } from "react-router-dom";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";

const useStyles = makeStyles(theme => ({
  "@global": {
    body: {
      backgroundColor: theme.palette.common.white
    }
  },
  paper: {
    marginTop: theme.spacing(8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center"
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main
  },
  form: {
    width: "100%", // Fix IE 11 issue.
    marginTop: theme.spacing(3)
  },
  submit: {
    margin: theme.spacing(3, 0, 2)
  },
  helpText: { color: "red" }
}));

export default function AccountInfo(props) {
  const classes = useStyles();
  const history = useHistory();

  const [textFieldState, setTextFieldState] = useState({
    givenName: "",
    familyName: "",
    email: "",
    password: ""
  });

  useEffect(() => {
    if (props.accountInfo) {
      setTextFieldState({
        givenName: props.accountInfo.givenName,
        familyName: props.accountInfo.familyName,
        email: props.accountInfo.email,
        password: props.accountInfo.password
      });
    }
  }, [props.accountInfo]);

  const handleTextFieldChange = field => event => {
    setTextFieldState({ ...textFieldState, [field]: event.target.value });
  };

  const handleSignupClick = () => {
    props.handleAccountInfoSubmit(textFieldState);
  };

  const handleFieldFocus = () => {
    props.clearErrorState();
  };

  return (
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <div className={classes.paper}>
        <Avatar className={classes.avatar}>
          <AccountCircleIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          Sign up
        </Typography>
        <div className={classes.form}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                onChange={handleTextFieldChange("givenName")}
                onFocus={handleFieldFocus}
                error={Boolean(props.errorState)}
                autoComplete="fname"
                name="givenName"
                variant="outlined"
                required
                fullWidth
                id="givenName"
                label="First Name"
                autoFocus
                value={textFieldState.givenName}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                onChange={handleTextFieldChange("familyName")}
                onFocus={handleFieldFocus}
                error={Boolean(props.errorState)}
                variant="outlined"
                required
                fullWidth
                id="familyName"
                label="Last Name"
                name="familyName"
                autoComplete="lname"
                value={textFieldState.familyName}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                onChange={handleTextFieldChange("email")}
                onFocus={handleFieldFocus}
                error={Boolean(props.errorState)}
                variant="outlined"
                required
                fullWidth
                id="email"
                label="Email Address"
                name="email"
                autoComplete="email"
                value={textFieldState.email}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                onChange={handleTextFieldChange("password")}
                onFocus={handleFieldFocus}
                error={Boolean(props.errorState)}
                variant="outlined"
                required
                fullWidth
                name="password"
                label="Password"
                type="password"
                id="password"
                autoComplete="current-password"
                value={textFieldState.password}
              />
            </Grid>
          </Grid>
          {Boolean(props.errorState) && (
            <div className={classes.helpText}>{props.errorMessage}</div>
          )}
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className={classes.submit}
            onClick={handleSignupClick}
          >
            Let's get started
          </Button>
          <Grid container justify="flex-end">
            <Grid item>
              <Link
                onClick={() => history.push("/")}
                style={{ cursor: "pointer" }}
                variant="body2"
              >
                Already have an account? Sign in
              </Link>
            </Grid>
          </Grid>
        </div>
      </div>
      <Box mt={5}>
        <Copyright />
      </Box>
    </Container>
  );
}
