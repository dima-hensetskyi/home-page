import React from "react";
import Typography from "@material-ui/core/Typography";
import Link from "@material-ui/core/Link";

export default function Copyright(props) {
  return (
    <Typography
      variant="body2"
      color="textSecondary"
      align="center"
      style={{ ...props.style }}
    >
      {"Copyright © "}
      <Link color="inherit" href="https://joinparfait.com/">
        Parfait
      </Link>{" "}
      {new Date().getFullYear()}
      {"."}
    </Typography>
  );
}
