import React from "react";
import "react-big-calendar/lib/css/react-big-calendar.css";
import { useHistory } from "react-router-dom";
import AddIcon from "@material-ui/icons/Add";
import Fab from "@material-ui/core/Fab";
import Paper from "@material-ui/core/Paper";
import MUIDataTable from "mui-datatables";

export default function EventsList(props) {
  const history = useHistory();

  const columns = ["Name", "Company", "City", "State"];

  const data = [
    ["Joe James", "Test Corp", "Yonkers", "NY"],
    ["John Walsh", "Test Corp", "Hartford", "CT"],
    ["Bob Herm", "Test Corp", "Tampa", "FL"],
    ["James Houston", "Test Corp", "Dallas", "TX"],
    ["James Houston", "Test Corp", "Dallas", "TX"],
    ["James Houston", "Test Corp", "Dallas", "TX"]
  ];

  const options = { rowsPerPage: 5 };

  const handleAddClick = event => {
    history.push("/events/addEvent");
  };

  return (
    <div style={{ height: "100%" }}>
      <MUIDataTable
        title={"Events"}
        data={data}
        columns={columns}
        options={options}
      />
      <Fab
        color="primary"
        onClick={handleAddClick}
        aria-label="add"
        style={{ float: "right" }}
      >
        <AddIcon />
      </Fab>
    </div>
  );
}
