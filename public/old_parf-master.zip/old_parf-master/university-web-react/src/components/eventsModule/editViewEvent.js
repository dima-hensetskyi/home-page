import React, { useEffect, useState } from "react";
import Link from "@material-ui/core/Link";
import { makeStyles } from "@material-ui/core/styles";
import ChevronLeftIcon from "@material-ui/icons/ChevronLeft";
import { useHistory } from "react-router-dom";
import EventForm from "./eventForm";
import Amplify, { API, Auth } from "aws-amplify";
import Paper from "@material-ui/core/Paper";
import { CircularProgress } from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  backButton: {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    width: "100%"
  }
}));

export default function EditViewEvent(props) {
  const classes = useStyles();
  const history = useHistory();

  const [event, setEvent] = useState();

  const [isLoading, setIsLoading] = useState(false);
  const [errorState, setErrorState] = useState();
  const [errorMessage, setErrorMessage] = useState(
    "An unknown error has occurred."
  );

  useEffect(() => {
    const fetchEvent = async () => {
      const event = await API.get(
        `events`,
        `/events/${props.match.params.eventId}`
      );
      setEvent(event);
      setIsLoading(false);
    };

    setIsLoading(true);
    fetchEvent();
  }, [props.match.params]);

  return (
    <Paper
      style={{
        height: "100%",
        display: "flex",
        flexDirection: "column"
      }}
    >
      <Link
        className={classes.backButton}
        onClick={() => {
          history.push("/events");
        }}
      >
        <ChevronLeftIcon />
        {`Back to events`}
      </Link>
      {isLoading && (
        <div
          style={{
            alignSelf: "center",
            justifySelf: "center",
            marginTop: "10%"
          }}
        >
          <CircularProgress size={90} />
          <div>Loading event...</div>
        </div>
      )}
      {!isLoading && <EventForm editable event={event} />}
    </Paper>
  );
}
