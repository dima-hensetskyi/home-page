import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { useHistory } from "react-router-dom";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Checkbox from "@material-ui/core/Checkbox";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { API, Auth } from "aws-amplify";
import { ERROR_STATE_REQUEST } from "../../constants";

const useStyles = makeStyles(theme => ({
  backButton: {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    alignSelf: "flex-start"
  }
}));

export default function EventForm(props) {
  const classes = useStyles();
  const history = useHistory();

  const [isLoading, setIsLoading] = useState(false);
  const [errorState, setErrorState] = useState();
  const [errorMessage, setErrorMessage] = useState(
    "An unknown error has occurred."
  );

  const [eventType, setEventType] = useState("College Event");
  const [isInviteOnly, setIsInviteOnly] = useState(false);
  const [textFieldState, setTextFieldState] = useState({
    title: "",
    description: "",
    address: "",
    location: ""
  });

  useEffect(() => {
    if (props.event) {
      setTextFieldState({
        title: "",
        description: props.event.description,
        address: props.event.address,
        location: props.event.location
      });
      setEventType(props.event.eventType);
      setIsInviteOnly(props.event.invitationOnly);
    }
  }, [props.event]);

  const handleTextFieldChange = field => event => {
    setTextFieldState({ ...textFieldState, [field]: event.target.value });
  };

  const handleSubmitClick = () => {
    API.post("events", "/events", {
      body: {
        tenantId: Auth.user.attributes["custom:tenantId"],
        eventType: eventType,
        title: textFieldState.title,
        description: textFieldState.description,
        address: textFieldState.address,
        location: textFieldState.location,
        invitationOnly: isInviteOnly
      }
    })
      .then(res => {
        setIsLoading(false);
      })
      .catch(error => {
        setErrorState(ERROR_STATE_REQUEST);
        setErrorMessage(error.message);
        setIsLoading(false);
      });
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        height: "100%"
      }}
    >
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "flex-start",
          height: "80%"
        }}
      >
        <FormControl className={classes.formControl} style={{ margin: "10px" }}>
          <InputLabel>Event Type</InputLabel>
          <Select
            value={eventType}
            onChange={e => setEventType(e.target.value)}
          >
            <MenuItem value={"College Fair"}>College Fair</MenuItem>
          </Select>
        </FormControl>
        <div
          style={{ display: "flex", marginTop: "10px", marginBottom: "10px" }}
        >
          <TextField
            onChange={handleTextFieldChange("title")}
            value={textFieldState.title}
            label="Title"
            variant="outlined"
            style={{ marginLeft: "10px", marginRight: "10px" }}
          />
          <TextField
            onChange={handleTextFieldChange("description")}
            value={textFieldState.description}
            label="Description"
            variant="outlined"
            style={{ marginLeft: "10px", marginRight: "10px" }}
          />
        </div>
        <div
          style={{ display: "flex", marginTop: "10px", marginBottom: "10px" }}
        >
          <TextField
            style={{ marginLeft: "10px", marginRight: "10px" }}
            onChange={handleTextFieldChange("address")}
            value={textFieldState.address}
            label="Address"
            variant="outlined"
          />
          <TextField
            style={{ marginLeft: "10px", marginRight: "10px" }}
            onChange={handleTextFieldChange("location")}
            value={textFieldState.location}
            label="Location"
            variant="outlined"
          />
        </div>
        <FormControlLabel
          control={
            <Checkbox
              checked={isInviteOnly}
              onChange={e => setIsInviteOnly(e.target.checked)}
              value="isInviteOnly"
              color="primary"
            />
          }
          style={{ margin: "10px" }}
          label="Invite Only"
        />
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          width: "95%",
          margin: "10px"
        }}
      >
        <Button
          variant="outlined"
          color="secondary"
          label="Cancel"
          onClick={() => history.push("/events")}
        >
          Cancel
        </Button>
        <Button
          variant="contained"
          color="primary"
          label="Submit"
          onClick={handleSubmitClick}
        >
          Submit
        </Button>
      </div>
    </div>
  );
}
