import React from "react";
import Link from "@material-ui/core/Link";
import { makeStyles } from "@material-ui/core/styles";
import ChevronLeftIcon from "@material-ui/icons/ChevronLeft";
import { useHistory } from "react-router-dom";
import EventForm from "./eventForm";
import { Paper } from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  backButton: {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    width: "100%"
  }
}));

export default function AddEvent(props) {
  const classes = useStyles();
  const history = useHistory();

  return (
    <Paper
      style={{
        height: "100%",
        display: "flex",
        flexDirection: "column"
      }}
    >
      <Link
        className={classes.backButton}
        onClick={() => {
          history.push("/events");
        }}
      >
        <ChevronLeftIcon />
        {`Back to events`}
      </Link>
      <EventForm editable />
    </Paper>
  );
}
