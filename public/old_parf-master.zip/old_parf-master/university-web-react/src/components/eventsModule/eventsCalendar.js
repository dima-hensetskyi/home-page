import React, { useState, useEffect } from "react";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import "react-big-calendar/lib/css/react-big-calendar.css";
import { useHistory } from "react-router-dom";
import AddIcon from "@material-ui/icons/Add";
import Fab from "@material-ui/core/Fab";
import Amplify, { API, Auth } from "aws-amplify";
import Paper from "@material-ui/core/Paper";

const localizer = momentLocalizer(moment);

export default function EventsCalendar(props) {
  const history = useHistory();

  const [events, setEvents] = useState([
    {
      eventId: 1,
      start: new Date(),
      end: new Date(moment().add(1, "days")),
      title: "Some title"
    }
  ]);

  useEffect(() => {
    const fetchEvents = async () => {
      const events = await API.get(`events`, `/events`);
      setEvents(events);
    };

    //fetchEvents();
  }, []);

  const onSelectEvent = event => {
    history.push(`/events/event/${event.eventId}`);
  };

  const handleAddClick = event => {
    history.push("/events/addEvent");
  };

  return (
    <div style={{ height: "100%" }}>
      <Paper style={{ height: "100%" }}>
        <Calendar
          localizer={localizer}
          onSelectEvent={onSelectEvent}
          events={events}
          startAccessor="start"
          endAccessor="end"
          style={{ height: "85%" }}
        />
        <Fab
          color="primary"
          onClick={handleAddClick}
          aria-label="add"
          style={{ float: "right" }}
        >
          <AddIcon />
        </Fab>
      </Paper>
    </div>
  );
}
