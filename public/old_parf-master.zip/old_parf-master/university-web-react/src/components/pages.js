import React from "react";
import { Switch } from "react-router-dom";
import PrivateRoute from "../components/privateRoute";
import Shell from "./shell";
import EventsCalendar from "./eventsModule/eventsCalendar";
import EventsList from "./eventsModule/eventsList";
import AddEvent from "./eventsModule/addEvent";
import EditViewEvent from "./eventsModule/editViewEvent";
import RecruitsList from "./recruitsModule/recruitsList";
import InstitutionDetails from "./institutionsModule/institutionDetails";
import ChatsList from "./chatsModule/chatList";
import ChatMessageList from "./chatsModule/messageList";
import PaymentPage from "./paymentModule/paymentPage";
import AddRecruit from "./recruitsModule/addRecruit";
import RecruitDetails from "./recruitsModule/recruitDetails";
import RecruitContacts from "./recruitsModule/recruitContacts";

const Pages = (props) => {
  //Set the title to the tenantName, if we have it
  const tenantName = localStorage.getItem("institutionName") || "";

  return (
    <Shell pathname={props.location.pathname} titleText={tenantName}>
      <Switch>
        <PrivateRoute path="/events" exact component={EventsCalendar} />
        <PrivateRoute
          path="/events/calendar"
          exact
          component={EventsCalendar}
        />
        <PrivateRoute path="/events/map" exact component={EventsCalendar} />
        <PrivateRoute path="/events/list" exact component={EventsList} />
        <PrivateRoute path="/events/addEvent" exact component={AddEvent} />
        <PrivateRoute path="/events/event/:eventId" component={EditViewEvent} />
        <PrivateRoute path="/recruits" exact component={RecruitsList} />
        <PrivateRoute
          path="/recruits/addRecruit"
          exact
          component={AddRecruit}
        />
        <PrivateRoute
          path="/recruits/recruit/:recruitId"
          exact
          component={RecruitDetails}
        />
        <PrivateRoute
          path="/recruits/recruit/:recruitId/contacts"
          exact
          component={RecruitContacts}
        />
        <PrivateRoute
          path="/recruits/prospects"
          exact
          component={() => <div>Prospects List</div>}
        />
        <PrivateRoute
          path="/institution/"
          exact
          component={InstitutionDetails}
        />
        <PrivateRoute path="/chatsList" exact component={ChatsList} />
        <PrivateRoute
          path="/chats/chat/:chatId"
          exact
          component={ChatMessageList}
        />
        <PrivateRoute path="/upgrade" component={() => <PaymentPage />} />
        <PrivateRoute
          path="/settings"
          component={() => <div>App settings</div>}
        />
      </Switch>
    </Shell>
  );
};

export default Pages;
