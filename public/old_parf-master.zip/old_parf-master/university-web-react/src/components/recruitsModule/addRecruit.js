import React from "react";
import Link from "@material-ui/core/Link";
import { makeStyles } from "@material-ui/core/styles";
import ChevronLeftIcon from "@material-ui/icons/ChevronLeft";
import { useHistory } from "react-router-dom";
import { Paper } from "@material-ui/core";
import RecruitForm from "./recruitForm";
import { Typography } from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  backButton: {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    width: "100%"
  }
}));

export default function AddRecruit(props) {
  const classes = useStyles();
  const history = useHistory();

  return (
    <Paper
      style={{
        height: "100%",
        display: "flex",
        flexDirection: "column"
      }}
    >
      <Link
        className={classes.backButton}
        onClick={() => {
          history.push("/recruits");
        }}
      >
        <ChevronLeftIcon />
        {`Back to recruits`}
      </Link>
      <h2 style={{ width: "100%", textAlign: "center" }}>Invite a recruit</h2>
      <Typography
        variant="body2"
        style={{ width: "100%", textAlign: "center" }}
      >
        They'll get an email to join the app, and you can save their information
        here. If they join, you'll be able to contact them through your recruits
        list.
      </Typography>
      <RecruitForm editable showEmailField />
    </Paper>
  );
}
