import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import MUIDataTable from "mui-datatables";
import { API, graphqlOperation } from "aws-amplify";
import { listRecruits } from "../../graphql/recruits/recruitsQueries";
import { useHistory } from "react-router-dom";
import Dialog from "@material-ui/core/Dialog";
import Typography from "@material-ui/core/Typography";
import AddCircleOutlineIcon from "@material-ui/icons/AddCircleOutline";
import VisibilityIcon from "@material-ui/icons/Visibility";
import { CircularProgress, Button, Link } from "@material-ui/core";
import CloseIcon from "@material-ui/icons/Close";
import { Link as RouterLink } from "react-router-dom";
import LaunchIcon from "@material-ui/icons/Launch";
import { createRecruit } from "../../graphql/recruits/recruitsMutations";

const useStyles = makeStyles((theme) => ({
  card: {
    width: 250,
    margin: "16px 8px",
    padding: "16px 8px",
    border: "1px solid rgb(136, 136, 136)",
    borderRadius: "8px",
    cursor: "pointer",
    "&:hover": {
      color: theme.palette.primary.main,
      borderColor: theme.palette.primary.main,
      backgroundColor: "#1e7ff721",
    },
  },
  title: {
    fontSize: 14,
  },
  pos: {
    marginBottom: 12,
  },
  spinnerContainer: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    width: "200px",
    height: "200px",
  },
}));

export default function RecruitsList(props) {
  const history = useHistory();
  const classes = useStyles();

  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [isLoadingDialogOpen, setIsLoadingDialogOpen] = React.useState(false);
  const [recruitData, setRecruitData] = React.useState(null);
  const [currentHoveredIndex, setCurrentHoveredIndex] = useState();
  const [paginationTokens, setPaginationTokens] = useState([null]);

  const fetchRecruitsPaginated = async (pageNumber) => {
    setIsLoadingDialogOpen(true);
    const result = await API.graphql(
      graphqlOperation(listRecruits, {
        limit: 10,
        nextToken: paginationTokens[pageNumber],
      }),
    );

    setPaginationTokens([
      ...paginationTokens,
      result.data.listRecruits.nextToken,
    ]);

    const recruitObjectArray = result.data.listRecruits.items;
    const recruitTableRows = recruitObjectArray.map((recruit) => {
      return [recruit.name, recruit.status, recruit.id];
    });

    setRecruitData(recruitTableRows);
    setIsLoadingDialogOpen(false);
  };

  useEffect(() => {
    const fetchRecruits = async () => {
      const result = await API.graphql(
        graphqlOperation(listRecruits, {
          limit: 10,
        }),
      );

      console.log(result);

      setPaginationTokens([null, result.data.listRecruits.nextToken]);
      const recruitObjectArray = result.data.listRecruits.items;
      const recruitTableRows = recruitObjectArray.map((recruit) => {
        return [recruit.name, recruit.status, recruit.id];
      });

      setRecruitData(recruitTableRows);
    };
    fetchRecruits();
  }, []);

  const onMouseEnterNameLink = (rowIndex) => (event) => {
    setCurrentHoveredIndex(rowIndex);
  };

  const onMouseLeaveNameLink = (rowIndex) => (event) => {
    setCurrentHoveredIndex(null);
  };

  const showEditLink = true;
  const columns = [
    {
      name: "name",
      label: "Name",
      options: {
        customBodyRender: (value, tableMeta, updateValue) => {
          let showLaunchIcon = false;
          if (tableMeta.rowIndex === currentHoveredIndex) {
            showLaunchIcon = true;
          }

          return showEditLink ? (
            <div style={{ display: "flex" }}>
              <Link
                component={RouterLink}
                to={`/recruits/recruit/${tableMeta.rowData[2]}`}
                onMouseEnter={onMouseEnterNameLink(tableMeta.rowIndex)}
                onMouseLeave={onMouseLeaveNameLink(tableMeta.rowIndex)}
              >
                {value}
              </Link>
              {showLaunchIcon && (
                <LaunchIcon
                  style={{ width: "15px", height: "15px", color: "#3f50b5" }}
                />
              )}
              {!showLaunchIcon && (
                <div style={{ width: "15px", height: "15px" }} />
              )}
            </div>
          ) : (
            <div>{value}</div>
          );
        },
      },
    },
    {
      name: "status",
      label: "Status",
    },
    {
      name: "id",
      options: {
        display: false,
      },
    },
  ];

  const options = {
    serverSide: true,
    sort: false,
    filter: false,
    search: false,
    print: false,
    download: false,
    viewColumns: false,
    count: 30,
    onTableChange: (action, tableState) => {
      switch (action) {
        case "changePage":
          fetchRecruitsPaginated(tableState.page);
          break;
        default:
          break;
      }
    },
  };

  const handleAddClick = () => {
    setIsDialogOpen(true);
  };
  useEffect(() => {
    // handleAddClick();
    // history.push("/recruits/addRecruit");
    const onSubmit = async (data) => {
      const recruit = {
        status: 0,
        familyName: "Family Name",
        givenName: "First Name",
      };

      const result = await API.graphql(
        graphqlOperation(createRecruit, { input: recruit }),
      );
      console.log(result);
    };
    onSubmit();
  }, []);
  const handleDialogClose = () => {
    setIsDialogOpen(false);
  };

  const handleLoadingDialogClose = () => {
    setIsLoadingDialogOpen(false);
  };

  const handleDialogSelection = (field) => (event) => {
    setIsDialogOpen(false);

    switch (field) {
      case "inviteNew":
        history.push("/recruits/addRecruit");
        break;
      case "viewProspects":
        history.push("/recruits/prospects");
        break;
      default:
        throw new Error("Invalid dialog value");
    }
  };

  return (
    <div>
      {!recruitData && (
        <div>
          <Button
            color="primary"
            onClick={handleAddClick}
            aria-label="add"
            variant="text"
            style={{
              marginLeft: "80%",
              marginTop: "10px",
              marginBottom: "10px",
            }}
            endIcon={<AddCircleOutlineIcon />}
          >
            Add Recruit
          </Button>
          {/* <MUIDataTable
            style={{ marginTop: "10px" }}
            title={"Recruits"}
            data={recruitData}
            columns={columns}
            options={options}
          /> */}
        </div>
      )}
      {/* {!recruitData && (
        <div
          style={{
            marginTop: "15%",
            marginLeft: "45%",
          }}
        >
          <CircularProgress size={90} />
          <div>Loading recruits...</div>
        </div>
      )} */}
      <Dialog
        onClose={handleLoadingDialogClose}
        aria-labelledby="simple-dialog-title"
        open={isLoadingDialogOpen}
        // disableBackdropClick
        disableEscapeKeyDown
      >
        <div className={classes.spinnerContainer}>
          <CircularProgress size={90} />
          <div>Loading recruits...</div>
        </div>
      </Dialog>
      <Dialog
        onClose={handleDialogClose}
        aria-labelledby="simple-dialog-title"
        open={isDialogOpen}
      >
        <h3
          id="simple-dialog-title"
          style={{
            fontWeight: "bold",
            display: "flex",
            justifyContent: "space-between",
            margin: "12px 24px",
          }}
        >
          <>Add a Recruit</>
          <CloseIcon
            onClick={handleDialogClose}
            style={{ cursor: "pointer" }}
          />
        </h3>
        <Typography style={{ marginLeft: "24px" }} color="textSecondary">
          Select a recruiting method
        </Typography>
        <div
          style={{
            display: "flex",
            justifyContent: "space-evenly",
            width: "600px",
          }}
        >
          <div
            className={classes.card}
            onClick={handleDialogSelection("viewProspects")}
          >
            <div>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <VisibilityIcon />
                <Typography variant="h6" component="h6">
                  View Prospects...
                </Typography>
              </div>
              <Typography
                variant="body2"
                style={{ color: "rgb(136, 136, 136)" }}
              >
                Search through a list of students who have shown active interest
                in your university
              </Typography>
            </div>
          </div>
          <div
            className={classes.card}
            onClick={handleDialogSelection("inviteNew")}
          >
            <div>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <AddCircleOutlineIcon />
                <Typography variant="h6" component="h6">
                  Invite a student
                </Typography>
              </div>
              <Typography
                variant="body2"
                style={{ color: "rgb(136, 136, 136)" }}
              >
                Let a student know about our app. You can save their information
                here even before they sign up!
              </Typography>
            </div>
          </div>
        </div>
      </Dialog>
    </div>
  );
}
