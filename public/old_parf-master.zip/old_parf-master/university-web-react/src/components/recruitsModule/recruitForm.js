import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { useHistory } from "react-router-dom";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import { API, graphqlOperation } from "aws-amplify";
import { createRecruit } from "../../graphql/recruits/recruitsMutations";
import { CircularProgress } from "@material-ui/core";
import CheckCircleOutlineIcon from "@material-ui/icons/CheckCircleOutline";
import { useForm, Controller } from "react-hook-form";

export default function RecruitForm(props) {
  const { register, handleSubmit, errors, setValue, control } = useForm();

  const classes = useStyles();
  const history = useHistory();

  const [showLoading, setShowLoading] = useState(false);
  const [doneLoading, setDoneLoading] = useState(false);

  console.log(props.recruit.status);
  useEffect(() => {
    if (props.recruit) {
      setValue("firstName", props.recruit.givenName);
      setValue("lastName", props.recruit.familyName);
      setValue("status", props.recruit.status);
    }
  }, [props.recruit, setValue]);

  const onSubmit = async (data) => {
    setShowLoading(true);

    const recruit = {
      status: data.status,
      familyName: "Family Name",
      givenName: "First Name",
    };

    await API.graphql(graphqlOperation(createRecruit, { input: recruit }));

    setDoneLoading(true);
    setTimeout(function () {
      history.push("/recruits");
    }, 1500);
  };

  return (
    <>
      {showLoading && (
        <div className={classes.loadingContainer}>
          {doneLoading && (
            <>
              <CheckCircleOutlineIcon className={classes.loadingCheck} />
              <div>Done!</div>
            </>
          )}
          {!doneLoading && (
            <>
              <CircularProgress size={90} />
              <div>Creating recruit...</div>
            </>
          )}
        </div>
      )}
      {!showLoading && (
        <form className={classes.root} onSubmit={handleSubmit(onSubmit)}>
          <div className={classes.select}>
            <InputLabel>Recruit Status</InputLabel>
            <Controller
              as={
                <Select>
                  <MenuItem value={"Prospect"}>Prospect</MenuItem>
                </Select>
              }
              control={control}
              name="status"
              defaultValue={"Prospect"}
            />
          </div>
          {props.showEmailField && (
            <div className={classes.textFieldRow}>
              <div className={classes.textFieldWithValidationMessage}>
                <TextField
                  name="email"
                  inputRef={register({ required: true })}
                  label="Email *"
                  variant="outlined"
                />
                {errors.email && (
                  <span className={classes.errorMessage}>
                    Email is required.
                  </span>
                )}
              </div>
              <div>{/* Spacer */}</div>
            </div>
          )}
          <div className={classes.textFieldRow}>
            <div className={classes.textFieldWithValidationMessage}>
              <TextField
                name="firstName"
                inputRef={register({ required: true })}
                label="First Name *"
                variant="outlined"
              />
              {errors.firstName && (
                <span className={classes.errorMessage}>
                  First Name is required.
                </span>
              )}
            </div>
            <div
              className={classes.textFieldWithValidationMessage}
              style={{
                marginLeft: "15px",
              }}
            >
              <TextField
                name="lastName"
                inputRef={register({ required: true })}
                label="Last Name *"
                variant="outlined"
              />
              {errors.lastName && (
                <span className={classes.errorMessage}>
                  Last Name is required.
                </span>
              )}
            </div>
          </div>
          <div className={classes.buttonRow}>
            <Button
              variant="outlined"
              color="secondary"
              label="Cancel"
              onClick={() => history.push("/recruits")}
            >
              Cancel
            </Button>
            <Button
              variant="contained"
              color="primary"
              label="Submit"
              type="submit"
            >
              Submit
            </Button>
          </div>
        </form>
      )}
    </>
  );
}

const useStyles = makeStyles((theme) => ({
  backButton: {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    alignSelf: "flex-start",
  },
  loadingContainer: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    alignSelf: "center",
    justifySelf: "center",
    marginTop: "15%",
  },
  loadingCheck: {
    width: "110px",
    height: "110px",
    color: "green",
  },
  root: {
    display: "flex",
    flexDirection: "column",
    height: "100%",
    margin: "30px 40px",
  },
  select: {
    display: "flex",
    flexDirection: "column",
    width: "20%",
    margin: "15px",
  },
  textFieldRow: {
    display: "flex",
    margin: "15px 15px 8px 15px",
  },
  textFieldWithValidationMessage: {
    display: "flex",
    flexDirection: "column",
  },
  errorMessage: { color: "red" },
  buttonRow: {
    display: "flex",
    justifyContent: "space-between",
    width: "50%",
    margin: "15px",
  },
}));
