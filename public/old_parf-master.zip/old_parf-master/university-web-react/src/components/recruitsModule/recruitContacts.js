import React, { useEffect, useState } from "react";
import { getRecruitNameAndContacts } from "../../graphql/recruits/recruitsQueries";
import { graphqlOperation, API } from "aws-amplify";
import { Link, CircularProgress } from "@material-ui/core";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import ChevronLeftIcon from "@material-ui/icons/ChevronLeft";
import MUIDataTable from "mui-datatables";

const getRecruitContactTypeLabel = contactType => {
  switch (contactType) {
    case "EVENT_SCAN":
      return "QR Code Scan";
    default:
      throw new Error("Unknown Recruit Contact type.");
  }
};

export default function RecruitContacts(props) {
  const classes = useStyles();
  const history = useHistory();

  const [isLoading, setIsLoading] = useState(false);
  const [recruitContacts, setRecruitContacts] = useState([]);
  const [recruitName, setRecruitName] = useState("");

  useEffect(() => {
    const fetchRecruitContacts = async () => {
      const result = await API.graphql(
        graphqlOperation(getRecruitNameAndContacts, {
          id: props.match.params.recruitId
        })
      );

      if (!result || !result.data || !result.data.getRecruit) {
        setIsLoading(false);
        return;
      }

      const { givenName } = result.data.getRecruit;
      setRecruitName(givenName);

      const { recruitContacts } = result.data.getRecruit;
      var recruitContactTableRows = recruitContacts.map(recruitContact => {
        var dateOfContact = new Date(recruitContact.createdAt).toString();
        var meansOfContact = getRecruitContactTypeLabel(
          recruitContact.contactType
        );
        var { eventName, note } = recruitContact;

        return [dateOfContact, meansOfContact, eventName, note];
      });

      setRecruitContacts(recruitContactTableRows);
      setIsLoading(false);
    };

    setIsLoading(true);
    fetchRecruitContacts();
  }, [props.match.params]);

  const columns = [
    {
      name: "dateOfContact",
      label: "Date of Contact"
    },
    {
      name: "meansOfContact",
      label: "Means of Contact"
    },
    {
      name: "event",
      label: "Event"
    },
    {
      name: "note",
      label: "Note"
    }
  ];

  const options = {
    rowsPerPage: 5,
    selectableRowsOnClick: true
  };

  return (
    <div>
      <Link
        className={classes.chevronButton}
        onClick={() => {
          history.push(`/recruits/recruit/${props.match.params.recruitId}`);
        }}
      >
        <ChevronLeftIcon />
        {`Back to recruit`}
      </Link>
      {!isLoading && (
        <>
          <h2>Your history with {recruitName}</h2>
          <MUIDataTable
            data={recruitContacts}
            columns={columns}
            options={options}
          />
        </>
      )}
      {isLoading && (
        <div className={classes.spinnerContainer}>
          <CircularProgress size={90} />
          <div>Loading recruit contacts...</div>
        </div>
      )}
    </div>
  );
}

const useStyles = makeStyles(theme => ({
  chevronButton: {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    fontSize: "large"
  },
  spinnerContainer: {
    marginTop: "15%",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center"
  }
}));
