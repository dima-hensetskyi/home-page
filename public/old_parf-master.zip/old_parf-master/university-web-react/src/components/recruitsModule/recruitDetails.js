import React, { useEffect, useState } from "react";
import Link from "@material-ui/core/Link";
import { makeStyles } from "@material-ui/core/styles";
import ChevronLeftIcon from "@material-ui/icons/ChevronLeft";
import ChevronRightIcon from "@material-ui/icons/ChevronRight";
import { useHistory } from "react-router-dom";
import Paper from "@material-ui/core/Paper";
import { CircularProgress } from "@material-ui/core";
import RecruitForm from "./recruitForm";
import { getRecruit } from "../../graphql/recruits/recruitsQueries";
import { graphqlOperation, API } from "aws-amplify";

export default function RecruitDetails(props) {
  const classes = useStyles();
  const history = useHistory();

  const [recruit, setRecruit] = useState();

  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const fetchEvent = async () => {
      const result = await API.graphql(
        graphqlOperation(getRecruit, { id: props.match.params.recruitId })
      );

      setRecruit(result.data.getRecruit);
      setIsLoading(false);
    };

    setIsLoading(true);
    fetchEvent();
  }, [props.match.params]);

  return (
    <Paper
      style={{
        height: "100%",
        display: "flex",
        flexDirection: "column"
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <Link
          className={classes.chevronButton}
          onClick={() => {
            history.push("/recruits");
          }}
        >
          <ChevronLeftIcon />
          {`Back to recruits`}
        </Link>
        <Link
          className={classes.chevronButton}
          onClick={() => {
            history.push(
              `/recruits/recruit/${props.match.params.recruitId}/contacts`
            );
          }}
        >
          {`Recruit history`}
          <ChevronRightIcon />
        </Link>
      </div>
      {isLoading && (
        <div
          style={{
            alignSelf: "center",
            justifySelf: "center",
            marginTop: "10%"
          }}
        >
          <CircularProgress size={90} />
          <div>Loading recruit...</div>
        </div>
      )}
      {!isLoading && <RecruitForm editable recruit={recruit} />}
    </Paper>
  );
}

const useStyles = makeStyles(theme => ({
  chevronButton: {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    fontSize: "large"
  }
}));
