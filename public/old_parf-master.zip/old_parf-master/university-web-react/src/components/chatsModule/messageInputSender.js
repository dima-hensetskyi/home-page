import clsx from "clsx";
import { makeStyles } from "@material-ui/core/styles";
import { Input } from 'react-chat-elements';
import React,  { useEffect, useState, useReducer } from "react";
import { API, graphqlOperation } from "aws-amplify";
import { sendChatMsgMutation } from "../../graphql/chat/chatMessage";
import { CircularProgress, Button } from "@material-ui/core";
import 'react-chat-elements/dist/main.css';

export default function MessageInputSender(props) {

    var inputRef = React.createRef();
    const [inputValue, setInputValue] = useState("");
    const [{ isSendingMsg }, dispatch] = useReducer((state, action) => {
        switch(action.type) {
            case "SENDING_STARTED": {
                return { ...state, isSendingMsg: true }
            }
            case "SENDING_FINISHED_SUCCESSFULLY": {
                return { ...state, isSendingMsg: false}
            }
        }
    }, { isSendingMsg: false })

    const handleSendClick = event => {
        dispatch({ type: "SENDING_STARTED" })
        const newMsg = {
            content: inputValue,
            contentType: "TEXT"
        }
        sendChatMsg(newMsg)
            .then(newMsgResult => {
                dispatch({ type: "SENDING_FINISHED_SUCCESSFULLY" })
            })
            .catch(handleError)
    }

    useEffect(() => {
        //Immediately after finishing sending, clear
        if(!isSendingMsg) {
            inputRef.clear()
        }
    }, [isSendingMsg])

    
    const sendChatMsg = async newMsg => {
        newMsg.chatId = props.chatId
        newMsg.type = "TENANT"
        const result = await API.graphql(
            graphqlOperation(sendChatMsgMutation, {
                input: newMsg
            })
          );
        return result.data.sendChatMessageResult
    }

    const handleError = err => {
        console.log(err)
    }

    return (
        <Input
            ref={el => (inputRef = el)}
            placeholder="Type here..."
            multiline={true}
            onChange={ e => setInputValue(e.target.value)}
            rightButtons={
                <Button
                    variant="contained"
                    color="primary"
                    label="Send"
                    type="Send"
                    onClick={ handleSendClick}
                >
                Send
                {isSendingMsg && 
                    <CircularProgress
                        size={20}/>
                }
                </Button>
            }
    />)
}