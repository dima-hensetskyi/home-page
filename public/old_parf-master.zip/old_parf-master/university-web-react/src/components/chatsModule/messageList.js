import React,  { useEffect, useState, useRef } from "react";  
import { MessageListComponent } from './thirdParty/MessageList.js';
import { CircularProgress } from "@material-ui/core";
import { API, graphqlOperation } from "aws-amplify";
import { getChat, getChatMsgs } from "../../graphql/chat/chat";
import { messageSubscription, updateChatMsg } from "../../graphql/chat/chatMessage";
import MessageInputSender from "./messageInputSender.js";
import 'react-chat-elements/dist/main.css';

export default function ChatMessageList(props) {

    const [chatData, setChat] = useState()
    const [messageListData, setMessageListData] = useState();
    const [nextToken, setNextToken] = useState();
    const [isFetchingNextMsgs, setIsFetchingNextMsgs] = useState(false)

    //TODO--Need to mark messages as read when they become visible
    const markAsRead = async (msg, chat) => {
        return updateStatus(msg, chat, "READ")
    }

    const markAsDelivered = async (msg, chat) => {
        return updateStatus(msg, chat, "DELIVERED")
    }

    const updateStatus = async (msg, chat, newStatus) => {
        const request = {
            id: msg.id,
            chatId: chat.id,
            status: newStatus.toUpperCase()
        }
        const result = await API.graphql(
            graphqlOperation(updateChatMsg, {
                input: request
              })
        )
    }

    const fetchChat = async () => {
        const result = await API.graphql(
            graphqlOperation(getChat, {
              id: props.match.params.chatId
            })
          );
        return result.data.chat
    }

    const getNextMessages = async () => {
        if (!nextToken) return
        const result = await API.graphql(
            graphqlOperation(getChatMsgs, {
              chatId: props.match.params.chatId,
              nextToken: nextToken
            })
          );
        return result.data.nextChatMessages
    }

    const addChatMessages = chat => {
        const nextMsgs = chat.chatMessagesContainer
        addMessages(chat, nextMsgs.items)
    }

    const addMessages = (chat, messages, addToEnd) => {
        const newMessages = messages
            //Reverse because the UI expected them in the opposite order
            .reverse()
            //map messages to view-model 3rd party component expects
            .map(message => mapToVm(message, chat));
        setMessageListData(currentMessages => {
            return currentMessages ? 
                (addToEnd ? [...currentMessages,  ...newMessages] : [...newMessages, ...currentMessages]) : 
                newMessages
        })
    }

    const mapToVm = (message, chat) => {
        return {
            id: message.id,
            position: message.type === 'USER' ? 
                'left' : 'right',
            type: message.contentType === 'TEXT' ?
                'text' : 'unknown',
            text: message.content,
            status: message.status,
            title: message.tenantUser ? 
                message.tenantUser.displayName :
                chat.user.name,
            date: Date.parse(message.createdAt),
        }
    }

    const saveNextChatMsgToken = chat => setNextToken(chat.chatMessagesContainer.nextToken)

    const subscribeToNewMsgs = async chat => {
        const subscription = await API.graphql(
            graphqlOperation(messageSubscription, {
                chatId: chat.id
            })
        ).subscribe({
            next: result => onChangedMessage(chat, result.value.data.changedMessage),
            error: handleError
        });
    }

    const onChangedMessage = (chat, changedMsg) => {
        //TODO--Determine if this is actually just an updated message, by ID
        //If updated, then replace
        setMessageListData(currentMessageList => {
            const existingIndex = currentMessageList.findIndex(msg => {
                return msg.id === changedMsg.id
            })
            if (existingIndex >= 0) {
                currentMessageList[existingIndex] = mapToVm(changedMsg, chat)    
            } else {
                addMessages(chat, [changedMsg], true)
            }
        })
    }

    const onScrollUp = e => {
        //At the top of the list now
        if (e.scrollTop === 0 && !isFetchingNextMsgs) {
            setIsFetchingNextMsgs(true)
            getNextMessages()
                .then(msgCon => {
                    addMessages(chatData, msgCon.items)
                    setNextToken(msgCon.nextToken)
                    setIsFetchingNextMsgs(false)
                })
                .catch(handleError)
        }
    }

    const handleError = err => {
        console.error(err)
    }

    useEffect(() => {
        fetchChat()
            .then(fetchedChat => {
                setChat(fetchedChat)
                addChatMessages(fetchedChat)
                saveNextChatMsgToken(fetchedChat)
                subscribeToNewMsgs(fetchedChat)
            })
            .catch(handleError);
    }, []);

    return (
        <div>
            {!messageListData && (
                <div
                style={{
                    marginTop: "15%",
                    marginLeft: "45%"
                }}
                >
                <CircularProgress size={90} />
                <div>Loading messages...</div>
        </div>
      )}
        {messageListData && (
            <div>
                <MessageListComponent
                    className='message-list'
                    dataSource={messageListData}
                    onScroll={onScrollUp}
                    lockable={true}
                />
                <MessageInputSender
                    chatId = {chatData.id}
                    />
            </div>)}
        </div>);
}