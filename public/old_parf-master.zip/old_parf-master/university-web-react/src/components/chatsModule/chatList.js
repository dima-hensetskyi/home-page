import React,  { useEffect, useState } from "react";  
import { ChatList } from 'react-chat-elements';
import { CircularProgress } from "@material-ui/core";
import { useHistory } from "react-router-dom";
import { API, graphqlOperation, Storage } from "aws-amplify";
import { getChats } from "../../graphql/chat/chat";
import 'react-chat-elements/dist/main.css';

export default function ChatsList(props) {
    const history = useHistory();

    const [chatsListData, setChatsListData] = React.useState(null);

    const fetchImagePath = async chat => {
        const userAvatar = chat.s3ImgInfo
        if (!userAvatar) return
        const result = await Storage.get(userAvatar.key, {bucket: userAvatar.bucket})
        console.log("URL Fetched: " + result)
        return result
    }

    const updateImages = chats => {
        const chatsNeedingImgs = chats.filter(chat => !chat.avatar)
        if (chatsNeedingImgs.length == 0) return
        chats.forEach(chat => {
            if (!chat.avatar) {
                const imgPath = fetchImagePath(chat)
                    .then(imgPath => {
                        chat.avatar = imgPath
                        setChatsListData([...chats])
                    })
            }
        })
    }

    const handleChatClicked = chat => {
        history.push(`/chats/chat/${chat.id}`);
      };


    const fetchChatsList = async () => {
        const result = await API.graphql(
            graphqlOperation(getChats, {
              limit: 10
            })
          );
        return result.data.chatConnection
    }

    const mapResultToChats = result => {
        return result.items.map(chat => {
            return { 
                id: chat.id, 
                title: chat.user.name,
                // avatar: "https://parfait-files-dev.s3.us-east-2.amazonaws.com/public/users/user-3c31cdec38f44e2fa0f0d55025c62502/5421c283d201b.image.jpg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=ASIAQUQCX4R3QHOOXMX5%2F20201105%2Fus-east-2%2Fs3%2Faws4_request&X-Amz-Date=20201105T020924Z&X-Amz-Expires=900&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEIr%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLWVhc3QtMiJIMEYCIQCNLZ5B7tjYJgcUWLq2oZx6zh5kpfCfWK1J%2FLLwBtq5awIhAIMZ4g8hEjo579SrPeqgyXOSvd1UpBc0wBPAOJ1btqR7Ks0ECOP%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEQARoMMDQ0MDI5MTc0OTAzIgy8u0a%2BmwKWI4OwhSwqoQTuLGn5wVnULQMORxdZywwxxqvZnAyDKMcyS0aTNPAEKRfEa3WqTOrMKa0dT6YpNIiNJVpsmxI%2FGHmXax4BXb3u3wCmfoFjB%2FWsn5uzgZ%2BfSN2yuaMRLYYWkFFMhWkM%2BDVoR5SbNlPQUhHAqKb5t7DXPk04Rj9AKKQJfs0IschHQaQMzlqUFWa%2BIfIcT336YpLw1gCIJyUofOPeZF%2BMHJGJy8GLBOayJlVnQ8B6CzaEBSnAGL5BJo%2BTrq2AJyzRVciAFmOyx63pG6ntmAAG8VgZ8qd6yFcI433r5zvdI49BMAkCE4R5K6yQEDVRS%2F12kytlriBIWo67R32mE6wJrXbAa3XdOQfglq1KAlSKdsyDzV8NzptN7CNFjQE8hoQyypMGq1xrtg5vveZpcyLW6NOBfM99z5sdaTrarzBqhsNYu7ex78nYaU3uhS%2B3LdIDDz6G5Dsb3E99xnhHAL3of8uSDHtOvel7fQs5AlMzHTVNT3VTWGRXaZ7hVAdPuME6Eh4Cr6Cg%2BndzJVyQKeLNC1potHBN%2FvXH1t2BWQ6A6eSCczTMXLpwdbaPXaZ7zWtjfwur9ZnSf2J7RjtCrkYHOjEvtxNpllhbIoF59vk4%2FRDLb9B34DYsSarB1NIuQP4JfNuN8cZcmZ5QegfJ4GIl18j2U%2BX8BoamWCVdx6u5pN5NsaofIE82xD6qRvGeh4gI1%2B6uGiRgTh5UKQ8boZMqmFj8gzDJvY39BTqEAoEy%2BoT0BIAfoMzLtqzQEbNwFt9S4jpfYiq9C8biDayvkXKyJsqawFi%2FH3I6vJMkSDK6cqFbPWcEjodcBNma9hqSdGPU1S5dobfSbWOeDqqrsIptFlL9xaKCb7lP9TXTE151%2BhiKx8XVy6VxiopI1p34xAgVSVhBpWT7NWBt7EZ2s3cGsRQyN7fi%2F8sJBpOrLCIC%2Bb6tIPDtn9kc7Rm6T9lnxwIxkf4cvw5vcTHG2HKAfc1UWdgSTTMyh%2BafTAjH%2BU1RETMHna2P78TYdYDMG9ZVzuXwZg%2B2rsp7jPyW0hEDBTuhUlrndVqozmMpzO0ft4HEbzJjiAGTFxzIsbaA%2BYQq4Se6&X-Amz-Signature=532b43ee26246d8ea7c31a5e55256a48799317c6b5fb4ebd0fe7bb01d7b16f8d&X-Amz-SignedHeaders=host",
                subtitle: chat.chatMessagesContainer.items[0].content,
                unread: chat.unreadMessageCount,
                date: Date.parse(chat.updatedAt),
                s3ImgInfo: chat.user.avatar
            }
        })
    }
    
    const handleError = err => {
        console.log(err)
    }

    useEffect(() => {
        fetchChatsList()
            .then(mapResultToChats)
            //TODO--Handle Paging
            .then(chats => {
                setChatsListData(chats)
                return chats
            })
            //Set the chats, and then get the image urls and set them
            .then(updateImages)
            .catch(handleError);
    }, []);

    return (
        <div>
            {!chatsListData && (
                <div
                style={{
                    marginTop: "15%",
                    marginLeft: "45%"
                }}
                >
                <CircularProgress size={90} />
                <div>Loading chats...</div>
        </div>
      )}
        {chatsListData && (
            <ChatList
                className='chat-list'
                onClick={handleChatClicked}
                dataSource={chatsListData} 
            />)}
        </div>);
}
