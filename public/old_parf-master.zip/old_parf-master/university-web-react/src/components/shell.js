import React, { useState, useEffect, useCallback } from "react";
import clsx from "clsx";
import { makeStyles } from "@material-ui/core/styles";
import CssBaseline from "@material-ui/core/CssBaseline";
import Copyright from "./copyright";
import { useHistory } from "react-router-dom";
import Divider from "@material-ui/core/Divider";
import IconButton from "@material-ui/core/IconButton";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Drawer from "@material-ui/core/Drawer";
import List from "@material-ui/core/List";
import EmojiPeopleIcon from "@material-ui/icons/EmojiPeople";
import HeightIcon from "@material-ui/icons/Height";
import SettingsIcon from "@material-ui/icons/Settings";
import EventIcon from "@material-ui/icons/Event";
import MenuItem from "@material-ui/core/MenuItem";
import { Menu } from "@material-ui/core";
import KeyboardArrowDownIcon from "@material-ui/icons/KeyboardArrowDown";
import CloseIcon from "@material-ui/icons/Close";
import Collapse from "@material-ui/core/Collapse";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";
import ListIcon from "@material-ui/icons/List";
import SchoolIcon from "@material-ui/icons/School";
import MapIcon from "@material-ui/icons/Map";
import ParfaitAppBar from "./parfaitAppBar";

export default function Shell(props) {
  const classes = useStyles();
  const history = useHistory();

  const paths = {
    events: "/events",
    payment: "/upgrade",
    recruits: "/recruits",
    chats: "/chatsList",
    institution: "/institution",
    settings: "/settings"
  };

  const CALENDAR_SELECTED = "CALENDAR";
  const LIST_SELECTED = "LIST";
  const MAP_SELECTED = "MAP";
  const MANAGE_RECRUITS_SELECTED = "MANAGE_RECRUITS";
  const UPGRADE_SELECTED = "UPGRADE";
  const CHATS_SELECTED = "CHATS_LIST";
  const INSTITUTION_SELECTED = "INSTITUTION";

  const MODULE_EVENTS = "events";
  const MODULE_PAYMENT = "payment";
  const MODULE_RECRUITS = "recruits";
  const MODULE_CHATS = "chats";
  const MODULE_INSTITUTION = "instutution"

  const MODULE_EVENTS_DISPLAY_NAME = "Events";
  const MODULE_PAYMENT_DISPLAY_NAME = "Payment";
  const MODULE_RECRUITS_DISPLAY_NAME = "Recruits";
  const MODULE_CHATS_DISPLAY_NAME = "Chats";
  const MODULE_INSTITUTION_DISPLAY_NAME = "Institution";

  const modules = [
    {
      key: MODULE_EVENTS,
      displayName: MODULE_EVENTS_DISPLAY_NAME,
      path: paths.events
    },
    {
      key: MODULE_CHATS,
      displayName: MODULE_CHATS_DISPLAY_NAME,
      path: paths.chats
    },
    {
      key: MODULE_INSTITUTION,
      displayName: MODULE_INSTITUTION_DISPLAY_NAME,
      path: paths.institution
    },
    {
      key: MODULE_PAYMENT,
      displayName: MODULE_PAYMENT_DISPLAY_NAME,
      path: paths.payment
    },
    {
      key: MODULE_RECRUITS,
      displayName: MODULE_RECRUITS_DISPLAY_NAME,
      path: paths.recruits
    }
  ];

  const [isDrawerOpen, setIsDrawerOpen] = useState(true);
  const [currentModule, setCurrentModule] = useState(MODULE_EVENTS);
  const [moduleDisplayName, setModuleDisplayName] = useState(
    MODULE_EVENTS_DISPLAY_NAME
  );
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedModuleIndex, setSelectedModuleIndex] = useState(0);
  const [selectedListItem, setSelectedListItem] = useState(CALENDAR_SELECTED);
  const [manageEventsOpen, setManageEventsOpen] = React.useState(true);

  const getModuleMenuIndexByKey = useCallback(
    key => {
      let menuIndex = null;
      modules.forEach((item, index) => {
        if (item.key === key) {
          menuIndex = index;
        }
      });

      if (menuIndex === null) {
        throw new Error("No module exists for the given key.");
      }

      return menuIndex;
    },
    [modules]
  );

  useEffect(() => {
    let moduleIndex;
    switch (props.pathname) {
      case paths.events:
        moduleIndex = getModuleMenuIndexByKey(MODULE_EVENTS);
        setCurrentModule(MODULE_EVENTS);
        setModuleDisplayName(MODULE_EVENTS_DISPLAY_NAME);
        setSelectedModuleIndex(moduleIndex);
        setManageEventsOpen(true);
        setSelectedListItem(CALENDAR_SELECTED);
        break;
      case paths.events+"/list":
        moduleIndex = getModuleMenuIndexByKey(MODULE_EVENTS);
        setCurrentModule(MODULE_EVENTS);
        setModuleDisplayName(MODULE_EVENTS_DISPLAY_NAME);
        setSelectedModuleIndex(moduleIndex);
        setManageEventsOpen(true);
        setSelectedListItem(LIST_SELECTED);
        break;
      case paths.events+"/map":
        moduleIndex = getModuleMenuIndexByKey(MODULE_EVENTS);
        setCurrentModule(MODULE_EVENTS);
        setModuleDisplayName(MODULE_EVENTS_DISPLAY_NAME);
        setSelectedModuleIndex(moduleIndex);
        setManageEventsOpen(true);
        setSelectedListItem(MAP_SELECTED);
        break;
      case paths.events+"/calendar":
        moduleIndex = getModuleMenuIndexByKey(MODULE_EVENTS);
        setCurrentModule(MODULE_EVENTS);
        setModuleDisplayName(MODULE_EVENTS_DISPLAY_NAME);
        setSelectedModuleIndex(moduleIndex);
        setManageEventsOpen(true);
        setSelectedListItem(CALENDAR_SELECTED);
        break;
      case paths.upgrade:
        moduleIndex = getModuleMenuIndexByKey(MODULE_PAYMENT);
        setModuleDisplayName(MODULE_PAYMENT_DISPLAY_NAME);
        setCurrentModule(MODULE_PAYMENT);
        setSelectedModuleIndex(moduleIndex);
        setSelectedListItem(UPGRADE_SELECTED);
        break;
      case paths.chats:
        moduleIndex = getModuleMenuIndexByKey(MODULE_CHATS);
        setModuleDisplayName(MODULE_CHATS_DISPLAY_NAME);
        setCurrentModule(MODULE_CHATS);
        setSelectedModuleIndex(moduleIndex);
        setSelectedListItem(CHATS_SELECTED);
        break;
      case paths.recruits:
        moduleIndex = getModuleMenuIndexByKey(MODULE_RECRUITS);
        setModuleDisplayName(MODULE_RECRUITS_DISPLAY_NAME);
        setSelectedModuleIndex(moduleIndex);
        setCurrentModule(MODULE_RECRUITS);
        setSelectedListItem(MANAGE_RECRUITS_SELECTED);
        break;
      case paths.institution:
        moduleIndex = getModuleMenuIndexByKey(MODULE_INSTITUTION);
        setModuleDisplayName(MODULE_INSTITUTION_DISPLAY_NAME);
        setSelectedModuleIndex(moduleIndex);
        setCurrentModule(MODULE_INSTITUTION);
        setSelectedListItem(INSTITUTION_SELECTED);
        break;
      case paths.settings:
        setManageEventsOpen(false);
        setSelectedListItem(null);
        break;
      default:
        break;
    }
  }, [props.pathname, modules, getModuleMenuIndexByKey]);

  const handleDrawerOpen = () => {
    setIsDrawerOpen(true);
  };

  const handleDrawerClose = () => {
    setIsDrawerOpen(false);
  };

  const handleClickModuleMenu = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleModuleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleModuleItemClick = (event, index) => {
    setSelectedModuleIndex(index);
    setCurrentModule(modules[index].key);
    setModuleDisplayName(modules[index].displayName);
    setAnchorEl(null);
    history.push(modules[index].path);
  };

  const handleManageEventsClick = () => {
    setManageEventsOpen(!manageEventsOpen);
  };

  const handleCalendarClick = () => {
    setSelectedListItem(CALENDAR_SELECTED);
    history.push(`${paths.events}/calendar`);
  };

  const handleListClick = () => {
    setSelectedListItem(LIST_SELECTED);
    history.push(`${paths.events}/list`);
  };

  const handleMapClick = () => {
    setSelectedListItem(MAP_SELECTED);
    history.push(`${paths.events}/map`);
  };

  return (
    <div className={classes.root}>
      <CssBaseline />
      <ParfaitAppBar
        handleDrawerOpen={handleDrawerOpen}
        titleText={props.titleText}
        isDrawerOpen={isDrawerOpen}
      />
      <Drawer
        className={classes.drawer}
        variant="persistent"
        anchor="left"
        open={isDrawerOpen}
        classes={{
          paper: classes.drawerPaper
        }}
      >
        <div className={classes.drawerHeader}>
          <List component="nav" aria-label="Module selection">
            <ListItem
              button
              aria-haspopup="true"
              aria-controls="module-menu"
              aria-label="select a module"
              onClick={handleClickModuleMenu}
            >
              <ListItemText primary={moduleDisplayName} />
              <ListItemIcon>
                <KeyboardArrowDownIcon fontSize="small" />
              </ListItemIcon>
            </ListItem>
          </List>
          <Menu
            id="module-menu"
            anchorEl={anchorEl}
            keepMounted
            open={Boolean(anchorEl)}
            onClose={handleModuleMenuClose}
          >
            {modules.map((option, index) => (
              <MenuItem
                key={option.key}
                selected={index === selectedModuleIndex}
                onClick={event => handleModuleItemClick(event, index)}
              >
                {option.displayName}
              </MenuItem>
            ))}
          </Menu>
          <IconButton onClick={handleDrawerClose}>
            <CloseIcon />
          </IconButton>
        </div>
        <Divider />
        <div className={classes.drawerContent}>
          {currentModule === MODULE_EVENTS && (
            <List>
              <ListItem button onClick={handleManageEventsClick}>
                <ListItemIcon>
                  <SchoolIcon />
                </ListItemIcon>
                <ListItemText primary="Manage Events" />
                {manageEventsOpen ? <ExpandLess /> : <ExpandMore />}
              </ListItem>
              <Collapse in={manageEventsOpen} timeout="auto" unmountOnExit>
                <List component="div" disablePadding>
                  <ListItem
                    selected={selectedListItem === CALENDAR_SELECTED}
                    button
                    onClick={handleCalendarClick}
                    style={{ paddingLeft: "64px" }}
                  >
                    <ListItemIcon>
                      <EventIcon />
                    </ListItemIcon>
                    <ListItemText primary="Calendar" />
                  </ListItem>
                  <ListItem
                    selected={selectedListItem === LIST_SELECTED}
                    onClick={handleListClick}
                    button
                    style={{ paddingLeft: "64px" }}
                  >
                    <ListItemIcon>
                      <ListIcon />
                    </ListItemIcon>
                    <ListItemText primary="List" />
                  </ListItem>
                  <ListItem
                    selected={selectedListItem === MAP_SELECTED}
                    onClick={handleMapClick}
                    button
                    style={{ paddingLeft: "64px" }}
                  >
                    <ListItemIcon>
                      <MapIcon />
                    </ListItemIcon>
                    <ListItemText primary="Map" />
                  </ListItem>
                </List>
              </Collapse>
            </List>
          )}
          {currentModule === MODULE_PAYMENT && (
            <List>
              <ListItem
                onClick={() => history.push(paths.upgrade)}
                selected={selectedListItem === UPGRADE_SELECTED}
                button
              >
                <ListItemIcon>
                  <HeightIcon />
                </ListItemIcon>
                <ListItemText primary={"Upgrade"} />
              </ListItem>
            </List>
          )}
          {currentModule === MODULE_RECRUITS && (
            <List>
              <ListItem
                onClick={() => history.push(paths.recruits)}
                selected={selectedListItem === MANAGE_RECRUITS_SELECTED}
                button
              >
                <ListItemIcon>
                  <EmojiPeopleIcon />
                </ListItemIcon>
                <ListItemText primary={"Manage Recruits"} />
              </ListItem>
            </List>
          )}
          <List>
            <ListItem onClick={() => history.push(paths.settings)} button>
              <ListItemIcon>
                <SettingsIcon />
              </ListItemIcon>
              <ListItemText primary={"Settings"} />
            </ListItem>
          </List>
        </div>
      </Drawer>
      <main
        className={clsx(classes.content, {
          [classes.contentShift]: isDrawerOpen
        })}
      >
        <div className={classes.drawerHeader} />
        <div
          style={{
            height: "80vh",
          }}
        >
          {props.children}
        </div>
        <Copyright style={{ marginTop: "10px" }} />
      </main>
    </div>
  );
}

const drawerWidth = 240;
const useStyles = makeStyles(theme => ({
  root: {
    display: "flex"
  },
  drawer: {
    width: drawerWidth,
    flexShrink: 0
  },
  drawerPaper: {
    width: drawerWidth
  },
  drawerHeader: {
    display: "flex",
    alignItems: "center",
    padding: theme.spacing(0, 1),
    ...theme.mixins.toolbar,
    justifyContent: "space-between"
  },
  drawerContent: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
    height: "100%"
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
    transition: theme.transitions.create("margin", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    marginLeft: -drawerWidth
  },
  contentShift: {
    transition: theme.transitions.create("margin", {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen
    }),
    marginLeft: 0
  },
  moduleSelect: {
    width: "auto"
  }
}));
