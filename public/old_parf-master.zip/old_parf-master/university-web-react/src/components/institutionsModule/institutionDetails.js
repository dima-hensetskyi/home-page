import React, { useEffect, useState } from "react";
import { CircularProgress } from "@material-ui/core";
import InstitutionImagesDisplay from "./images/institutionImagesDisplay"
import { getTenantForAuthedUser } from "../../graphql/institution/InstitutionDetailsQuery";
import { graphqlOperation, API } from "aws-amplify";

export default function InstitutionDetails(props) {
  const [institution, setInstitution] = useState(null);

    useEffect(() => {
        fetchInstitution()
            .then(setInstitution)
            .catch(handleError);
    }, []);

    const fetchInstitution =  async () => {
        const result = await API.graphql(
            graphqlOperation(getTenantForAuthedUser)
        );
        return result.data.tenant.institution
    }

    const handleError = err => {
        console.log(err)
    }

    return (
        <div>
            {!institution && (
                <div
                style={{
                    marginTop: "15%",
                    marginLeft: "45%"
                }}
                >
                <CircularProgress size={90} />
                <div>Loading Institution...</div>
        </div>
    )}
        {institution && (
            <InstitutionImagesDisplay
                className='images-display'
                institution={institution} 
            />)}
        </div>);
}
