import React, { useEffect, useState } from "react";
import { CircularProgress } from "@material-ui/core";
import InstitutionImageDisplay from "./institutionImageDisplay"
import { Carousel } from 'react-responsive-carousel';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Storage } from "aws-amplify";

export default function InstitutionImagesDisplay(props) {

    const [institutionImages, setInstitutionImages] = React.useState(null);

    const loadImages = async institution => {
        const institutionPrimaryImage = {
            image: institution.primaryImage,
            message: institution.name,
            isPrimaryImage: true
        }
        const institutionImages = [institutionPrimaryImage, ...institution.institutionImages.items]
        console.log(institutionImages)
        const needingImgs = institutionImages.filter(institutionImage => !institutionImage.resolvedImageUrl)
        if (needingImgs.length == 0) return
        institutionImages.forEach(institutionImage => {
            if (!institutionImage.resolvedImageUrl) {
                const imgPath = fetchImagePath(institutionImage)
                    .then(imgPath => {
                        institutionImage.resolvedImageUrl = imgPath
                        setInstitutionImages([...institutionImages])
                    })
            }
        })
    }

    const fetchImagePath = async institutionImage => {
        const image = institutionImage.image
        if (!image) return
        const result = await Storage.get(image.key, {bucket: image.bucket})
        return result
    }

    const handleError = err => {
        console.log(err)
    }

    useEffect(() => {
        console.log(props.institution)
        loadImages(props.institution)
            .catch(handleError);
    }, [props.institution]);

    const thumbNailDisplay = () => institutionImages.map(image => (<img src={image.resolvedImageUrl}/>))

    return (
        <div>
            {!institutionImages && (
                <div
                style={{
                    marginTop: "15%",
                    marginLeft: "45%"
                }}>
                    <CircularProgress size={90} />
                    <div>Loading Institution...</div>
                </div>
            )}
            {institutionImages && (
                <Carousel
                renderThumbs={thumbNailDisplay}
                >
                    {institutionImages.map((institutionImage, index) => 
                        (<InstitutionImageDisplay 
                            uniqueKey={index}
                            institutionImage={institutionImage}/>)
                    )}  
                </Carousel>  
            )}
        </div>);
}
