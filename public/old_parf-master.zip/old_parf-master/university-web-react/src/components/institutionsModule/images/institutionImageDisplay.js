import React, { useEffect, useState } from "react";
import { CircularProgress } from "@material-ui/core";
import { Storage } from "aws-amplify";

export default function InstitutionImageDisplay(props) {

    return (
        <div key={props.uniqueKey}>
            <img src={props.institutionImage.resolvedImageUrl} />
            <p class="legend">{props.institutionImage.message}</p>
        </div>
    );
}
