import React, { useEffect, useState } from "react";
import { CircularProgress } from "@material-ui/core";
import { Storage } from "aws-amplify";
import config from "../../config";

export default function InstitutionImageUpload(props) {

    const [isLoading, setIsLoading] = useState(false)
    const [fileToUpload, setFileToUpload] = useState(null)
    const [messageToUpload, setMessageToUpload] = useState(null)

    const onMessageChanged = (event) => {
        const message = event.target.value
        setMessageToUpload(message)
    }

    const onFileChanged = (event) => {
        const file = event.target.files[0]
        setFileToUpload(file)
    }

    const upload = (event) => {
        const file = fileToUpload
        if (!props.tenantPoolId) throw "Please set tenant Pool Id property on this component."
        const key = `institutions/${props.tenantPoolId}/${file.name}`

        setIsLoading(true)
        uploadToS3(key, file)
            .then(result => console.log("Uploaded to S3 " + result))
            .then(addImageToInstitutionRecord)
            .catch(handleError)
            .finally(result => setIsLoading(false));
    }

    const uploadToS3 = (key, file) => {
        return Storage.put(key, file, {
            contentType: 'image/png'
        })
    }

    const addImageToInstitutionRecord = (imageUploadResult, message) => {
        const s3Model = {
            bucket: config.s3.BUCKET,
            region: config.s3.REGION,
            key: imageUploadResult.key
        }
        const institutionImage = {
            message: message,
            image: s3Model
        }
    }

    const handleError = err => {
        console.log(err)
    }

    return (
        <div>
            <Input id="image" type="file" accept='image/png' onChange={onFileChanged}/>
            <Input id="message" type="text" onChange onChange={onMessageChanged}/>
            <Button onClick={upload} >Upload</Button> 
        </div>
    )
}
